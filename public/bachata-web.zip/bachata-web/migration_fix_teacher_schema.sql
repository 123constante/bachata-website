-- Migration to add missing columns to teacher_profiles

ALTER TABLE teacher_profiles 
ADD COLUMN IF NOT EXISTS travel_willingness TEXT DEFAULT 'UK & Europe',
ADD COLUMN IF NOT EXISTS years_teaching INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS offers_private BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS offers_group BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS email TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT,
ADD COLUMN IF NOT EXISTS facebook TEXT;

-- Verify if other tables need columns based on visual inspection of Profile.tsx code
