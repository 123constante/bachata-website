export const AdminTeachers = () => <div style={{ color: 'white', padding: '2rem' }}><h2>Teachers List</h2><p>Feature coming soon.</p></div>;
