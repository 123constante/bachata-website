export const AdminHome = () => {
    return (
        <div>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem' }}>Dashboard Overview</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem' }}>
                {/* Stats Cards */}
                {[
                    { label: 'Pending Claims', value: '0', color: '#ff9500' },
                    { label: 'Active Events', value: '0', color: '#4ade80' },
                    { label: 'Total Users', value: '0', color: '#60a5fa' },
                    { label: 'System Status', value: 'Stable', color: '#a78bfa' }
                ].map((stat, i) => (
                    <div key={i} className="admin-card">
                        <p style={{ color: '#888', fontSize: '0.85rem', marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '1px' }}>{stat.label}</p>
                        <p style={{ color: stat.color, fontSize: '2rem', fontWeight: 'bold', margin: 0 }}>{stat.value}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};
