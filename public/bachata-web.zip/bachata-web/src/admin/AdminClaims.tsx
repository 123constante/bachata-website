import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Loader2 } from 'lucide-react';
import type { Database } from '../lib/database.types';

type Claim = Database['public']['Tables']['profile_claims']['Row'];

export const AdminClaims = () => {
    const [claims, setClaims] = useState<Claim[]>([]);
    const [targetNames, setTargetNames] = useState<Record<string, string>>({}); // claimId -> targetName
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchClaims();
    }, []);

    const fetchClaims = async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('profile_claims')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching claims:', error);
        } else if (data && data.length > 0) {
            setClaims(data);
            await fetchTargetNames(data);
        } else {
            setClaims([]);
        }
        setLoading(false);
    };

    const fetchTargetNames = async (claims: Claim[]) => {
        const names: Record<string, string> = {};

        // Parallel fetch for associated profile names
        await Promise.all(claims.map(async (claim) => {
            let table: any = '';
            let nameCol = '';

            // Determine target table based on profile_type
            if (claim.profile_type === 'teacher') { table = 'teacher_profiles'; nameCol = 'full_name'; }
            else if (claim.profile_type === 'dj') { table = 'dj_profiles'; nameCol = 'dj_name'; }
            else if (claim.profile_type === 'organiser') { table = 'organisers'; nameCol = 'name'; }
            else if (claim.profile_type === 'dancer') { table = 'dancers'; nameCol = 'full_name'; }

            if (table) {
                const { data } = await supabase
                    .from(table)
                    .select(nameCol)
                    .eq('id', claim.profile_id)
                    .single();

                if (data) {
                    names[claim.id] = (data as any)[nameCol];
                }
            }
        }));

        setTargetNames(names);
    };

    if (loading) return <div className="flex justify-center p-12"><Loader2 className="animate-spin text-orange-500" /></div>;

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">Claims History (Read Only)</h1>

            {claims.length === 0 ? (
                <div className="text-center text-gray-500 py-12 border border-dashed border-gray-800 rounded-lg">
                    No claims found.
                </div>
            ) : (
                <div className="grid gap-4">
                    {claims.map(claim => (
                        <div key={claim.id} className="bg-[#111] border border-white/10 p-4 rounded-lg flex flex-col md:flex-row justify-between gap-4">
                            <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                    <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${claim.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                                            claim.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                                                'bg-yellow-500/20 text-yellow-400'
                                        }`}>
                                        {claim.status}
                                    </span>
                                    <span className="text-gray-500 text-xs">
                                        {new Date(claim.created_at).toLocaleDateString()}
                                    </span>
                                    <span className="text-orange-400 text-xs font-mono uppercase border border-orange-500/30 px-1 rounded">
                                        {claim.profile_type}
                                    </span>
                                </div>

                                <div className="flex flex-col gap-1">
                                    <div className="text-white font-semibold">
                                        Claimant: {claim.claim_name}
                                        <span className="text-gray-500 font-normal text-sm ml-2">({claim.claim_email})</span>
                                    </div>

                                    <div className="flex items-center gap-2 text-sm text-gray-400">
                                        <span className="text-gray-600">Target Profile:</span>
                                        {targetNames[claim.id] ? (
                                            <span className="text-blue-300">{targetNames[claim.id]}</span>
                                        ) : (
                                            <span className="font-mono text-xs">{claim.profile_id}</span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="md:w-1/3 bg-black/50 p-3 rounded border border-white/5 text-xs text-gray-400">
                                <div className="grid grid-cols-[auto_1fr] gap-x-2 gap-y-1">
                                    <span className="text-gray-600">Phone:</span>
                                    <span>{claim.claim_phone}</span>

                                    <span className="text-gray-600">User ID:</span>
                                    <span className="font-mono truncate" title={claim.user_id}>{claim.user_id.substring(0, 8)}...</span>

                                    {claim.admin_notes && (
                                        <>
                                            <span className="text-gray-600">Notes:</span>
                                            <span className="italic text-gray-300">{claim.admin_notes}</span>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};
