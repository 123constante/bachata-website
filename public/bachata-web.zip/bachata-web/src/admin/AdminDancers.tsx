export const AdminDancers = () => <div style={{ color: 'white', padding: '2rem' }}><h2>Dancers List</h2><p>Feature coming soon.</p></div>;
