import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Loader2, User, ExternalLink } from 'lucide-react';
import type { Database } from '../../lib/database.types';

type TableName = keyof Database['public']['Tables'];

interface AdminEntityDetailProps {
    tableName: TableName;
    title: string;
}

export const AdminEntityDetail = ({ tableName, title }: AdminEntityDetailProps) => {
    const { id } = useParams<{ id: string }>();
    const [entity, setEntity] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [linkedProfile, setLinkedProfile] = useState<{ full_name: string | null, avatar_url: string | null } | null>(null);
    const [otherRoles, setOtherRoles] = useState<{ type: string; id: string }[]>([]);

    useEffect(() => {
        if (id) fetchEntity();
    }, [id, tableName]);

    const fetchEntity = async () => {
        setLoading(true);
        // 1. Fetch Entity
        const { data: row, error } = await supabase
            .from(tableName)
            .select('*')
            .eq('id', id!)
            .single();

        if (error) {
            console.error('Error fetching entity:', error);
            setLoading(false);
            return;
        }

        setEntity(row);

        // 2. If Linked user, fetch profile + check other roles
        if (row.user_id) {
            // A. Fetch Profile (Name + Avatar only)
            const { data: profile } = await supabase
                .from('profiles')
                .select('full_name, avatar_url')
                .eq('id', row.user_id)
                .single();

            setLinkedProfile(profile);

            // B. Check Other Roles (Parallel)
            const roleChecks = [
                { table: 'teacher_profiles', label: 'Teacher' },
                { table: 'dj_profiles', label: 'DJ' },
                { table: 'organisers', label: 'Organiser' },
                { table: 'dancers', label: 'Dancer' }
            ] as const;

            const rolesFound: { type: string; id: string }[] = [];

            await Promise.all(roleChecks.map(async (rc) => {
                // Don't check self table
                if (rc.table === tableName) return;

                const { data: roleData } = await (supabase
                    .from(rc.table)
                    .select('id')
                    .eq('user_id', row.user_id) as any); // Type assertion needed for loose table matching in loop mainly

                // If query matched multiple, we generally just take first or list them. 
                // Usually 1 role per type per user.
                if (roleData && roleData.length > 0) {
                    rolesFound.push({ type: rc.label, id: roleData[0].id });
                }
            }));

            setOtherRoles(rolesFound);
        }

        setLoading(false);
    };

    if (loading) return <div className="flex justify-center p-12"><Loader2 className="animate-spin text-orange-500" /></div>;
    if (!entity) return <div className="p-8 text-white">Entity not found.</div>;

    // Helper to format keys
    const formatKey = (key: string) => key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <Link to=".." className="inline-flex items-center text-gray-400 hover:text-white mb-6 transition-colors">
                <ArrowLeft size={16} className="mr-2" /> Back to List
            </Link>

            <h1 className="text-3xl font-bold text-white mb-8">{title} Details</h1>

            <div className="grid gap-6">
                {/* ID & Linked User Status */}
                <div className="bg-[#111] border border-white/10 p-6 rounded-lg">
                    <h2 className="text-xl font-semibold text-orange-500 mb-4">Account Status</h2>
                    <div className="flex flex-col md:flex-row gap-8">
                        <div>
                            <span className="block text-gray-500 text-sm mb-1">Entity ID</span>
                            <code className="bg-black px-2 py-1 rounded text-red-300">{entity.id}</code>
                        </div>

                        <div>
                            <span className="block text-gray-500 text-sm mb-1">Linked User</span>
                            {entity.user_id ? (
                                <div className="flex items-center gap-3">
                                    {linkedProfile?.avatar_url ? (
                                        <img src={linkedProfile.avatar_url} alt="User" className="w-10 h-10 rounded-full object-cover border border-white/20" />
                                    ) : (
                                        <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center border border-white/10">
                                            <User size={20} className="text-gray-400" />
                                        </div>
                                    )}
                                    <div>
                                        <div className="text-white font-medium">{linkedProfile?.full_name || 'Unknown Name'}</div>
                                        <div className="text-xs text-green-400 font-mono">LINKED</div>
                                    </div>
                                </div>
                            ) : (
                                <span className="text-gray-500 italic">No linked user account</span>
                            )}
                        </div>
                    </div>

                    {/* Cross Links */}
                    {otherRoles.length > 0 && (
                        <div className="mt-6 pt-6 border-t border-white/10">
                            <span className="block text-gray-500 text-sm mb-2">Other Roles for this User</span>
                            <div className="flex gap-3">
                                {otherRoles.map(role => {
                                    // simple mapping back to route path
                                    const pathMap: Record<string, string> = {
                                        'Teacher': 'teachers',
                                        'DJ': 'djs',
                                        'Organiser': 'organisers',
                                        'Dancer': 'dancers'
                                    };
                                    return (
                                        <Link
                                            key={role.type}
                                            to={`/admin/${pathMap[role.type]}/${role.id}`}
                                            className="inline-flex items-center gap-2 px-3 py-2 bg-[#222] hover:bg-[#333] rounded border border-white/10 text-sm text-white transition-colors"
                                        >
                                            {role.type} <ExternalLink size={12} />
                                        </Link>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* Raw Data View */}
                <div className="bg-[#111] border border-white/10 p-6 rounded-lg">
                    <h2 className="text-xl font-semibold text-white mb-4">Record Data</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                        {Object.entries(entity).map(([key, value]) => {
                            if (key === 'id') return null; // Already shown

                            let displayValue: string | JSX.Element = String(value);

                            // Simple array/obj formatting
                            if (typeof value === 'object' && value !== null) {
                                displayValue = <pre className="text-xs bg-black p-2 rounded overflow-x-auto max-w-[200px] md:max-w-xs">{JSON.stringify(value, null, 2)}</pre>;
                            }
                            if (value === null) displayValue = <span className="text-gray-600 italic">null</span>;
                            if (typeof value === 'boolean') displayValue = <span className={value ? 'text-green-400' : 'text-red-400'}>{String(value).toUpperCase()}</span>;

                            return (
                                <div key={key} className="border-b border-white/5 pb-2">
                                    <span className="block text-gray-500 text-xs uppercase tracking-wider mb-1">{formatKey(key)}</span>
                                    <div className="text-gray-200 text-sm break-words">{displayValue}</div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};
