import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Link } from 'react-router-dom';
import { Loader2, Link as LinkIcon, Unlink } from 'lucide-react';
import type { Database } from '../../lib/database.types';

type TableName = keyof Database['public']['Tables'];

interface AdminEntityListProps {
    tableName: TableName;
    nameColumn: string; // The column key to display as the name
    basePath: string; // e.g. '/admin/teachers'
    title: string;
}

export const AdminEntityList = ({ tableName, nameColumn, basePath, title }: AdminEntityListProps) => {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchData();
    }, [tableName]);

    const fetchData = async () => {
        // Read-only select
        const { data: rows, error } = await supabase
            .from(tableName)
            .select('*')
            .order('created_at', { ascending: false });

        if (error) {
            console.error(`Error fetching ${tableName}:`, error);
        } else {
            setData(rows || []);
        }
        setLoading(false);
    };

    if (loading) return <div className="flex justify-center p-8"><Loader2 className="animate-spin text-orange-500" /></div>;

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">{title}</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {data.map((item) => {
                    const isLinked = !!item.user_id; // Check if user_id is not null

                    return (
                        <Link
                            key={item.id}
                            to={`${basePath}/${item.id}`}
                            className="block p-4 bg-[#111] border border-white/10 rounded-lg hover:border-orange-500/50 transition-colors group"
                        >
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-semibold text-lg text-white group-hover:text-orange-500 transition-colors">
                                        {item[nameColumn] || 'Unnamed'}
                                    </h3>
                                    <div className="mt-2">
                                        {isLinked ? (
                                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-green-500/10 text-green-400 border border-green-500/20">
                                                <LinkIcon size={12} />
                                                LINKED
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/20">
                                                <Unlink size={12} />
                                                UNLINKED
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </Link>
                    );
                })}
            </div>

            {data.length === 0 && (
                <div className="text-center text-gray-500 py-12">
                    No records found.
                </div>
            )}
        </div>
    );
};
