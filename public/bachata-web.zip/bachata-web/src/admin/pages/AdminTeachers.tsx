import { AdminEntityList } from '../components/AdminEntityList';
import { AdminEntityDetail } from '../components/AdminEntityDetail';

// --- Teachers ---
export const AdminTeachers = () => (
    <AdminEntityList
        tableName="teacher_profiles"
        nameColumn="full_name"
        basePath="/admin/teachers"
        title="Teachers"
    />
);

export const AdminTeacherDetail = () => (
    <AdminEntityDetail
        tableName="teacher_profiles"
        title="Teacher"
    />
);
