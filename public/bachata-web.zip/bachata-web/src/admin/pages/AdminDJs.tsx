import { AdminEntityList } from '../components/AdminEntityList';
import { AdminEntityDetail } from '../components/AdminEntityDetail';

// --- DJs ---
export const AdminDJs = () => (
    <AdminEntityList
        tableName="dj_profiles"
        nameColumn="dj_name"
        basePath="/admin/djs"
        title="DJs"
    />
);

export const AdminDJDetail = () => (
    <AdminEntityDetail
        tableName="dj_profiles"
        title="DJ"
    />
);
