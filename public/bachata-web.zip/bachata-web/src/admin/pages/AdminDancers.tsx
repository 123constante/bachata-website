import { AdminEntityList } from '../components/AdminEntityList';
import { AdminEntityDetail } from '../components/AdminEntityDetail';

// --- Dancers ---
export const AdminDancers = () => (
    <AdminEntityList
        tableName="dancers"
        nameColumn="full_name"
        basePath="/admin/dancers"
        title="Dancers"
    />
);

export const AdminDancerDetail = () => (
    <AdminEntityDetail
        tableName="dancers"
        title="Dancer"
    />
);
