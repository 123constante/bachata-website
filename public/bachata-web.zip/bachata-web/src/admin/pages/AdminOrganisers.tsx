import { AdminEntityList } from '../components/AdminEntityList';
import { AdminEntityDetail } from '../components/AdminEntityDetail';

// --- Organisers ---
export const AdminOrganisers = () => (
    <AdminEntityList
        tableName="organisers"
        nameColumn="name"
        basePath="/admin/organisers"
        title="Organisers"
    />
);

export const AdminOrganiserDetail = () => (
    <AdminEntityDetail
        tableName="organisers"
        title="Organiser"
    />
);
