import { Routes, Route, Navigate } from 'react-router-dom';
import { AdminHome } from './AdminHome';
import { AdminClaims } from './AdminClaims';
import { AdminTeachers, AdminTeacherDetail } from './pages/AdminTeachers';
import { AdminDJs, AdminDJDetail } from './pages/AdminDJs';
import { AdminOrganisers, AdminOrganiserDetail } from './pages/AdminOrganisers';
import { AdminDancers, AdminDancerDetail } from './pages/AdminDancers';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

// Placeholders for now
const Placeholder = ({ title }: { title: string }) => (
    <div style={{
        padding: '2rem',
        border: '1px dashed #333',
        borderRadius: '8px',
        textAlign: 'center',
        color: '#666'
    }}>
        <h2>{title} System</h2>
        <p>Coming Soon</p>
    </div>
);

import { useLocation } from 'react-router-dom';

export const AdminRoutes = () => {
    const location = useLocation();
    const { session, isAdmin, loading } = useAuth();

    if (loading) {
        return (
            <div style={{
                height: '80vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#d4af37'
            }}>
                <Loader2 className="animate-spin" size={32} />
            </div>
        );
    }

    if (!session) {
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    if (!isAdmin) {
        return <Navigate to="/login" replace />;
    }

    return (
        <div key={location.pathname} className="admin-page-container">
            <Routes>
                <Route path="" element={<Navigate to="home" replace />} />
                <Route path="home" element={<AdminHome />} />

                <Route path="claims" element={<AdminClaims />} />

                <Route path="teachers" element={<AdminTeachers />} />
                <Route path="teachers/:id" element={<AdminTeacherDetail />} />

                <Route path="djs" element={<AdminDJs />} />
                <Route path="djs/:id" element={<AdminDJDetail />} />

                <Route path="organisers" element={<AdminOrganisers />} />
                <Route path="organisers/:id" element={<AdminOrganiserDetail />} />

                <Route path="dancers" element={<AdminDancers />} />
                <Route path="dancers/:id" element={<AdminDancerDetail />} />

                <Route path="events" element={<Placeholder title="Event Management" />} />
                <Route path="conflicts" element={<Placeholder title="Conflict Manager" />} />
                <Route path="*" element={<Navigate to="home" replace />} />
            </Routes>
        </div>
    );
};
