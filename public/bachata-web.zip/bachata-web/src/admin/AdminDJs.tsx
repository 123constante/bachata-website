export const AdminDJs = () => <div style={{ color: 'white', padding: '2rem' }}><h2>DJs List</h2><p>Feature coming soon.</p></div>;
