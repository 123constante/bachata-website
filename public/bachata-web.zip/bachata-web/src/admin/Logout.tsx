import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export const Logout = () => {
    const { signOut } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        const performLogout = async () => {
            await signOut();
            navigate('/login', { replace: true });
        };
        performLogout();
    }, [signOut, navigate]);

    return (
        <div className="min-h-screen bg-black flex items-center justify-center text-white">
            <p>Signing out...</p>
        </div>
    );
};
