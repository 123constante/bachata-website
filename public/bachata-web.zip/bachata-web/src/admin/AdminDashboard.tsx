import { AdminSidebar } from './AdminSidebar';
import { AdminTopBar } from './AdminTopBar';
import { AdminRoutes } from './adminRoutes';
import './styles/admin.css';

const AdminDashboard = () => {
    return (
        <div className="admin-layout">
            <AdminSidebar />

            <div className="admin-main-content">
                <AdminTopBar />

                <main style={{
                    flex: 1,
                    padding: '2rem',
                    overflowY: 'auto'
                }}>
                    <AdminRoutes />
                </main>
            </div>
        </div>
    );
};

export default AdminDashboard;
