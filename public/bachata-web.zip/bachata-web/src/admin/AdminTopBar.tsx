import { useLocation } from 'react-router-dom';

export const AdminTopBar = () => {
    const location = useLocation();

    // Simple breadcrumb logic
    const pathSegments = location.pathname.replace('/admin', '').split('/').filter(Boolean);
    const currentPage = pathSegments.length > 0
        ? pathSegments[0].charAt(0).toUpperCase() + pathSegments[0].slice(1)
        : 'Home';

    return (
        <header style={{
            height: '64px',
            padding: '0 2rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%'
        }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <span style={{ color: '#888', fontSize: '0.9rem' }}>Admin</span>
                <span style={{ color: '#444' }}>/</span>
                <span style={{ color: 'white', fontWeight: 600, letterSpacing: '0.5px' }}>{currentPage}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: '#4ade80',
                    boxShadow: '0 0 10px rgba(74, 222, 128, 0.5)'
                }} title="System Online" />
            </div>
        </header>
    );
};
