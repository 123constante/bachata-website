export const AdminEvents = () => <div style={{ color: 'white', padding: '2rem' }}><h2>Events List</h2><p>Feature coming soon.</p></div>;
