export const AdminConflicts = () => <div style={{ color: 'white', padding: '2rem' }}><h2>Conflict Manager</h2><p>Feature coming soon.</p></div>;
