import { Link, useLocation } from 'react-router-dom';
import {
    LayoutDashboard,
    FileCheck,
    Users,
    Music,
    Building2,
    VenetianMask,
    Calendar,
    AlertTriangle,
    LogOut
} from 'lucide-react';

const MENU_ITEMS = [
    { label: 'Overview', path: '/admin/home', icon: LayoutDashboard },
    { label: 'Claims Console', path: '/admin/claims', icon: FileCheck },
    { label: 'Teachers', path: '/admin/teachers', icon: Users },
    { label: 'DJs', path: '/admin/djs', icon: Music },
    { label: 'Organisers', path: '/admin/organisers', icon: Building2 },
    { label: 'Dancers', path: '/admin/dancers', icon: VenetianMask },
    { label: 'Events', path: '/admin/events', icon: Calendar },
    { label: 'Conflicts', path: '/admin/conflicts', icon: AlertTriangle },
];

export const AdminSidebar = () => {
    const location = useLocation();

    return (
        <aside className="admin-sidebar">
            <div style={{ padding: '1.5rem', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <h1 style={{
                    color: '#ff9500',
                    fontSize: '1.25rem',
                    fontWeight: 'bold',
                    margin: 0,
                    letterSpacing: '-0.5px'
                }}>
                    ADMIN <span style={{ color: 'white' }}>CORE</span>
                </h1>
            </div>

            <nav style={{ flex: 1, padding: '1rem 0' }}>
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    {MENU_ITEMS.map((item) => {
                        const isActive = location.pathname.startsWith(item.path);
                        const Icon = item.icon;

                        return (
                            <li key={item.path}>
                                <Link
                                    to={item.path}
                                    className={`admin-nav-item ${isActive ? 'active' : ''}`}
                                >
                                    <Icon size={18} />
                                    <span>{item.label}</span>
                                </Link>
                            </li>
                        );
                    })}
                </ul>
            </nav>

            <div style={{ padding: '1rem', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                <Link
                    to="/logout"
                    className="admin-nav-item"
                    style={{ color: '#f87171' }}
                >
                    <LogOut size={18} />
                    <span>Logout</span>
                </Link>
            </div>
        </aside>
    );
};
