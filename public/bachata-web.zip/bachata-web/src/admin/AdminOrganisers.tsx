export const AdminOrganisers = () => <div style={{ color: 'white', padding: '2rem' }}><h2>Organisers List</h2><p>Feature coming soon.</p></div>;
