import React, { useEffect } from 'react';
import { AdminHamburger } from './AdminHamburger';
import { GlobalHeader } from './GlobalHeader';
import { executePendingAttendance } from '../lib/attendance';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  useEffect(() => {
    executePendingAttendance();
  }, []);

  return (
    <div className="layout-root">
      <GlobalHeader />

      <div className="layout-content">
        <main
          className="container"
          style={{ minHeight: '80vh', paddingBottom: '4rem' }}
        >
          {children}
        </main>

        <footer
          style={{
            textAlign: 'center',
            padding: 'var(--spacing-xl)',
            color: 'var(--color-text-muted)',
            opacity: 0.5
          }}
        >
          &copy; {new Date().getFullYear()} Bachata Community
        </footer>
      </div>

      <AdminHamburger />
    </div>
  );
};
