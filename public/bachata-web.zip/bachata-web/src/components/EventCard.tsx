import React from 'react';
import { MapPin } from 'lucide-react';

interface EventCardProps {
    dateDisplay: string;
    title: string;
    location: string;
    classTime?: string;
    socialTime?: string;
    imageUrl?: string;
    onClick?: () => void;
}

export const EventCard: React.FC<EventCardProps> = ({
    dateDisplay, title, location, classTime, socialTime, onClick
}) => {
    return (
        <div style={{
            background: 'var(--color-surface)',
            borderRadius: 'var(--radius-md)',
            overflow: 'hidden',
            transition: 'transform 0.2s',
            cursor: 'pointer'
        }}
            onClick={onClick}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
        >
            <div style={{ padding: 'var(--spacing-md)' }}>
                {/* Date Badge */}
                <div style={{
                    color: 'var(--color-accent)',
                    fontWeight: 'bold',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    marginBottom: 'var(--spacing-xs)'
                }}>
                    {dateDisplay}
                </div>

                {/* Title */}
                <h3 style={{ margin: 0, fontSize: '1.25rem', marginBottom: 'var(--spacing-sm)' }}>{title}</h3>

                {/* Location */}
                <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    style={{
                        display: 'flex', alignItems: 'center', gap: '6px',
                        color: 'var(--color-primary-light)',
                        fontSize: '0.9rem', marginBottom: 'var(--spacing-md)',
                        textDecoration: 'underline'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.textDecoration = 'underline'}
                    onMouseLeave={(e) => e.currentTarget.style.textDecoration = 'underline'}
                >
                    <MapPin size={14} />
                    <span>{location}</span>
                </a>

                {/* Times Pills - Simplified text only */}
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: 'var(--spacing-md)' }}>
                    {classTime && (
                        <div style={{
                            color: 'var(--color-text-muted)',
                            fontSize: '0.85rem',
                            display: 'flex', alignItems: 'center', gap: '4px'
                        }}>
                            Class: {classTime}
                        </div>
                    )}
                    {socialTime && (
                        <div style={{
                            color: 'white', /* Plain white text for importance but no bg */
                            fontSize: '0.9rem',
                            fontWeight: 600,
                            display: 'flex', alignItems: 'center', gap: '4px'
                        }}>
                            Social: {socialTime}
                        </div>
                    )}
                </div>

                {/* View Event Button */}
                <div style={{ textAlign: 'right', marginTop: 'var(--spacing-md)' }}>
                    <button style={{
                        background: 'var(--color-primary)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        padding: '8px 24px',
                        fontSize: '0.9rem',
                        fontWeight: 600,
                        cursor: 'pointer',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px'
                    }}
                        onMouseEnter={(e) => e.currentTarget.style.background = 'var(--color-primary-light)'}
                        onMouseLeave={(e) => e.currentTarget.style.background = 'var(--color-primary)'}
                    >
                        View event
                    </button>
                </div>
            </div>
        </div>
    );
};
