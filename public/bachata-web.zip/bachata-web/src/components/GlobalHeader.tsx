import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User as UserIcon, LogIn, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const GlobalHeader = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const { session, isAdmin, profile } = useAuth();
    const location = useLocation();

    // Close menu on route change
    useEffect(() => {
        // eslint-disable-next-line
        setIsMenuOpen(false);
    }, [location.pathname]);

    const navLinks = [
        { path: '/', label: 'Events' },
        { path: '/teachers', label: 'Teachers' },
        { path: '/djs', label: 'DJs' },
        { path: '/organisers', label: 'Organisers' },
        { path: '/dancers', label: 'Dancers' },
    ];

    return (
        <header style={{
            position: 'sticky',
            top: 0,
            zIndex: 50,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            backdropFilter: 'blur(10px)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
            <div className="container" style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                height: '70px',
                padding: '0 1rem'
            }}>
                {/* 1. Logo */}
                <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{
                        background: 'linear-gradient(135deg, #ff9500, #ff5e00)',
                        width: '32px',
                        height: '32px',
                        borderRadius: '8px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold',
                        color: 'white'
                    }}>
                        B
                    </div>
                    <span style={{
                        fontWeight: 'bold',
                        fontSize: '1.2rem',
                        color: 'white',
                        background: 'linear-gradient(90deg, #fff, #ccc)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent'
                    }}>
                        Bachata<span style={{ fontWeight: 'normal', opacity: 0.7 }}>Com</span>
                    </span>
                </Link>

                {/* 2. Desktop Navigation */}
                <nav className="desktop-nav" style={{
                    display: 'flex',
                    gap: '2rem',
                    position: 'absolute',
                    left: '50%',
                    transform: 'translateX(-50%)'
                }}>
                    {navLinks.map(link => (
                        <Link
                            key={link.path}
                            to={link.path}
                            style={{
                                color: location.pathname === link.path ? '#ff9500' : '#aaa',
                                textDecoration: 'none',
                                fontWeight: location.pathname === link.path ? 600 : 400,
                                fontSize: '0.95rem',
                                transition: 'color 0.2s'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.color = '#fff'}
                            onMouseLeave={(e) => e.currentTarget.style.color = location.pathname === link.path ? '#ff9500' : '#aaa'}
                        >
                            {link.label}
                        </Link>
                    ))}
                </nav>

                {/* 3. Actions (Avatar + Mobile Toggle) */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>

                    {/* Auth/Avatar */}
                    {session ? (
                        <div style={{ display: 'flex', gap: '0.8rem', alignItems: 'center' }}>
                            {isAdmin && (
                                <Link to="/admin" title="Admin Dashboard" style={{
                                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                                    width: '36px', height: '36px',
                                    background: '#222',
                                    borderRadius: '8px',
                                    color: '#ff9500',
                                    border: '1px solid #333',
                                    transition: 'all 0.2s',
                                    textDecoration: 'none'
                                }}>
                                    <LayoutDashboard size={18} />
                                </Link>
                            )}
                            <Link to="/profile" title="My Profile" style={{
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                width: '36px', height: '36px',
                                background: '#222',
                                borderRadius: '50%',
                                color: '#ff9500',
                                border: '1px solid #333',
                                transition: 'all 0.2s',
                                overflow: 'hidden'
                            }}>
                                {profile?.avatar_url ? (
                                    <img
                                        src={profile.avatar_url}
                                        alt="Avatar"
                                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                    />
                                ) : (
                                    <UserIcon size={18} />
                                )}
                            </Link>
                        </div>
                    ) : (
                        <Link to="/login" style={{
                            background: '#ff9500',
                            color: 'black',
                            padding: '6px 16px',
                            borderRadius: '20px',
                            textDecoration: 'none',
                            fontSize: '0.9rem',
                            fontWeight: 600,
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px'
                        }}>
                            <LogIn size={16} />
                            <span className="mobile-hidden">Login</span>
                        </Link>
                    )}

                    {/* Mobile Hamburger Toggle - Controlled by CSS classes */}
                    <button
                        className="mobile-toggle"
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        style={{
                            background: 'transparent',
                            border: 'none',
                            color: 'white',
                            cursor: 'pointer',
                            padding: '4px',
                            // Removed display: none, now handled by CSS
                        }}
                    >
                        {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* 4. Mobile Menu Drawer */}
            {isMenuOpen && (
                <div style={{
                    position: 'absolute',
                    top: '70px',
                    left: 0,
                    width: '100%',
                    backgroundColor: '#000',
                    borderBottom: '1px solid #333',
                    padding: '1rem',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1rem',
                    animation: 'slideDown 0.3s ease-out'
                }}>
                    {navLinks.map(link => (
                        <Link
                            key={link.path}
                            to={link.path}
                            style={{
                                color: location.pathname === link.path ? '#ff9500' : 'white',
                                textDecoration: 'none',
                                fontSize: '1.1rem',
                                padding: '8px 0',
                                borderBottom: '1px solid #111'
                            }}
                        >
                            {link.label}
                        </Link>
                    ))}
                </div>
            )}

            {/* Responsive Styles Injection */}
            <style>{`
                .mobile-toggle { display: none; }
                
                @media (max-width: 768px) {
                    .desktop-nav { display: none !important; }
                    .mobile-toggle { display: block !important; }
                    .mobile-hidden { display: none !important; }
                }
                @keyframes slideDown {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </header>
    );
};
