import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ShieldAlert } from 'lucide-react';
import '../admin/styles/admin.css';

export const AdminHamburger = () => {
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        const checkAdmin = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) return;

            // Check if user is admin in profiles table
            const { data } = await supabase
                .from('profiles')
                .select('is_admin')
                .eq('id', session.user.id)
                .single();

            if (data && (data as any).is_admin) {
                setIsAdmin(true);
            }
        };

        checkAdmin();
    }, []);

    if (!isAdmin) return null;

    return (
        <Link
            to="/admin/home"
            title="Admin Dashboard"
            className="admin-hamburger"
        >
            <ShieldAlert size={20} className="icon-pulse" />
            <span>Go to Admin Dashboard</span>
        </Link>
    );
};
