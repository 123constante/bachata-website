import { useState } from 'react';
import { submitProfileClaim, type ProfileType } from '../lib/profileClaim';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

interface ClaimFormProps {
    type: ProfileType;
    id: string;
    targetName: string; // The name of the entity being claimed (e.g. "John Doe")
    onSuccess?: () => void;
    className?: string;
}

export const ClaimForm = ({ type, id, targetName, onSuccess, className = '' }: ClaimFormProps) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
    const [errorMessage, setErrorMessage] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('submitting');
        setErrorMessage('');

        try {
            await submitProfileClaim(type, id, name.trim(), email.trim(), phone.trim(), targetName);
            setStatus('success');
            if (onSuccess) onSuccess();
        } catch (err: any) {
            console.error(err);
            setStatus('error');
            setErrorMessage(err.message || 'Failed to submit claim. Please try again.');
        }
    };

    if (status === 'success') {
        return (
            <div className={`text-center p-8 bg-green-500/10 border border-green-500/20 rounded-2xl animate-fade-in ${className}`}>
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 mb-6 animate-bounce">
                    <CheckCircle className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Claim Request Saved!</h3>
                <p className="text-gray-300 mb-6 leading-relaxed">
                    We've securely received your request to claim <span className="text-white font-semibold">{targetName}</span>.
                </p>
                <div className="bg-white/5 rounded-xl p-4 border border-white/10 text-sm text-gray-300">
                    <p className="mb-2 font-medium text-white">What happens next?</p>
                    <p>Our admin team has been notified via the dashboard. We will review your details and activate your access shortly.</p>
                </div>
            </div>
        );
    }

    return (
        <div className={className}>
            <h3 className="text-xl font-bold text-white mb-2">Claim this Profile</h3>
            <p className="text-gray-400 text-sm mb-6">
                Are you <span className="text-white font-semibold">{targetName}</span>? Verify your identity to gain access.
            </p>

            {status === 'error' && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3 animate-shake">
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                        <h4 className="text-white font-medium text-sm">Submission Failed</h4>
                        <p className="text-red-400 text-sm mt-1">{errorMessage}</p>
                    </div>
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 ml-1">
                        Your Full Name
                    </label>
                    <input
                        required
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 transition-all hover:bg-white/10"
                        placeholder="e.g. John Doe"
                    />
                </div>

                <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 ml-1">
                        Email Address
                    </label>
                    <input
                        required
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 transition-all hover:bg-white/10"
                        placeholder="john@example.com"
                    />
                </div>

                <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 ml-1">
                        Phone / WhatsApp
                    </label>
                    <input
                        required
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 transition-all hover:bg-white/10"
                        placeholder="+1 234 567 890"
                    />
                </div>

                <div className="pt-4">
                    <button
                        type="submit"
                        disabled={status === 'submitting'}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold py-4 px-6 rounded-xl transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-purple-900/20"
                    >
                        {status === 'submitting' ? (
                            <>
                                <Loader2 className="w-5 h-5 animate-spin" />
                                Sending Request...
                            </>
                        ) : (
                            'Submit Claim Request'
                        )}
                    </button>
                    <p className="text-center text-xs text-gray-500 mt-4">
                        By submitting, you confirm you are the owner of this profile.
                    </p>
                </div>
            </form>
        </div>
    );
};
