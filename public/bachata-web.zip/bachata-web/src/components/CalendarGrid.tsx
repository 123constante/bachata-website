import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarGridProps {
    currentDate: Date;
    onDateChange: (date: Date) => void;
    events: { start_time: string }[];
    selectedDate: Date;
    onSelectDate: (date: Date) => void;
}

export const CalendarGrid: React.FC<CalendarGridProps> = ({
    currentDate, onDateChange, events, selectedDate, onSelectDate
}) => {
    // Helpers
    const getDaysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    const getFirstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay(); // 0 = Sun

    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    // Adjust for Monday start if needed (Sunday = 0)
    const startOffset = firstDay === 0 ? 6 : firstDay - 1;

    // Check if a day has events
    const hasEvents = (day: number) => {
        return events.some(e => {
            const d = new Date(e.start_time);
            return d.getDate() === day &&
                d.getMonth() === currentDate.getMonth() &&
                d.getFullYear() === currentDate.getFullYear();
        });
    };

    const isSelected = (day: number) => {
        return selectedDate.getDate() === day &&
            selectedDate.getMonth() === currentDate.getMonth() &&
            selectedDate.getFullYear() === currentDate.getFullYear();
    };

    const isToday = (day: number) => {
        const today = new Date();
        return today.getDate() === day &&
            today.getMonth() === currentDate.getMonth() &&
            today.getFullYear() === currentDate.getFullYear();
    };

    const handlePrevMonth = () => {
        const newDate = new Date(currentDate);
        newDate.setMonth(newDate.getMonth() - 1);
        onDateChange(newDate);
    };

    const handleNextMonth = () => {
        const newDate = new Date(currentDate);
        newDate.setMonth(newDate.getMonth() + 1);
        onDateChange(newDate);
    };

    return (
        <div style={{ background: 'var(--color-surface)', borderRadius: 'var(--radius-md)', padding: '1rem', marginBottom: '2rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <button onClick={handlePrevMonth} className="btn" style={{ padding: '4px' }}><ChevronLeft /></button>
                <h3 style={{ margin: 0 }}>
                    {currentDate.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}
                </h3>
                <button onClick={handleNextMonth} className="btn" style={{ padding: '4px' }}><ChevronRight /></button>
            </div>

            {/* Days Header */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', textAlign: 'center', marginBottom: '0.5rem', fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => <div key={d}>{d}</div>)}
            </div>

            {/* Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '4px' }}>
                {Array.from({ length: startOffset }).map((_, i) => (
                    <div key={`empty-${i}`} />
                ))}

                {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const selected = isSelected(day);
                    const eventDot = hasEvents(day);

                    return (
                        <button
                            key={day}
                            onClick={() => {
                                console.log('Clicked day:', day);
                                const newDate = new Date(currentDate);
                                newDate.setDate(day);
                                onSelectDate(newDate);
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = selected ? 'var(--color-primary)' : 'var(--color-surface-hover)'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = selected ? 'var(--color-primary)' : 'transparent'}
                            style={{
                                aspectRatio: '1/1',
                                background: selected ? 'var(--color-primary)' : 'transparent',
                                color: selected ? 'white' : 'var(--color-text)',
                                borderRadius: '50%',
                                cursor: 'pointer',
                                position: 'relative',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '0.9rem',
                                transition: 'background-color 0.2s',
                                border: isToday(day) && !selected ? '1px solid var(--color-primary)' : 'none'
                            }}
                        >
                            {day}
                            {eventDot && (
                                <div style={{
                                    position: 'absolute',
                                    bottom: '4px',
                                    width: '4px', height: '4px',
                                    borderRadius: '50%',
                                    background: selected ? 'white' : 'var(--color-accent)'
                                }} />
                            )}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};
