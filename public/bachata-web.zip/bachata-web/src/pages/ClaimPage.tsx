import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Layout } from '../components/Layout';
import { ClaimForm } from '../components/ClaimForm';
import { Loader2, ArrowLeft, Sparkles } from 'lucide-react';
import type { ProfileType } from '../lib/profileClaim';

// Abstracted background component for clearer code
const AnimatedBackground = () => {
    // Array of placeholder images for the dynamic background
    const images = [
        "https://images.unsplash.com/photo-1547153760-18fc86324498?q=80&w=2574&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=2528&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1533174072545-e8d98597f47f?q=80&w=2544&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?q=80&w=2670&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1518834107812-67b0b7c58434?q=80&w=2535&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=2669&auto=format&fit=crop",
    ];

    return (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
            <div className="absolute inset-0 bg-black/80 z-10" /> {/* Overlay to darken images */}

            {/* Animated Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 opacity-40 animate-pulse-slow p-4 transform scale-105">
                {[...Array(4)].map((_, colIndex) => (
                    <div key={colIndex} className="space-y-4">
                        {images.map((src, imgIndex) => (
                            <div key={`${colIndex}-${imgIndex}`} className="rounded-xl overflow-hidden aspect-[3/4]">
                                <img src={src} alt="" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" />
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export const ClaimPage = () => {
    const { type, id } = useParams<{ type: ProfileType; id: string }>();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [profileData, setProfileData] = useState<any>(null);
    const [error, setError] = useState('');

    useEffect(() => {
        if (type && id) {
            fetchProfile();
        }
    }, [type, id]);

    const fetchProfile = async () => {
        try {
            let tableName = '';
            let selectQuery = '*';

            if (type === 'teacher') tableName = 'teacher_profiles';
            else if (type === 'organiser') tableName = 'organisers';
            else if (type === 'dj') tableName = 'dj_profiles';
            else throw new Error('Invalid profile type');

            const { data, error } = await supabase
                .from(tableName)
                .select(selectQuery)
                .eq('id', id!)
                .single();

            if (error) throw error;
            if (!data) throw new Error('Profile not found');

            setProfileData(data);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)] bg-black">
                <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </div>
        </Layout>
    );

    if (error || !profileData) return (
        <Layout>
            <div className="min-h-screen flex items-center justify-center relative bg-black">
                <AnimatedBackground />
                <div className="max-w-md mx-auto px-4 py-8 text-center relative z-20 backdrop-blur-xl bg-black/60 rounded-3xl border border-white/10 shadow-2xl">
                    <div className="inline-block p-4 rounded-full bg-red-500/20 mb-4 animate-bounce">
                        <ArrowLeft className="w-8 h-8 text-red-500" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Profile Not Found</h2>
                    <p className="text-gray-300 mb-6">{error || "We couldn't find the profile you're looking for."}</p>
                    <button
                        onClick={() => navigate('/')}
                        className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all border border-white/10 font-medium"
                    >
                        Return Home
                    </button>
                </div>
            </div>
        </Layout>
    );

    const getName = () => {
        if (type === 'teacher') return profileData.full_name;
        if (type === 'organiser') return profileData.name;
        if (type === 'dj') return profileData.dj_name;
        return 'Unknown';
    };

    const getPhoto = () => {
        return profileData.photo_url;
    };

    return (
        <Layout>
            <div className="min-h-[calc(100vh-64px)] relative flex flex-col items-center justify-center overflow-hidden">
                <AnimatedBackground />

                <div className="w-full max-w-lg relative z-20 p-4 animate-fade-in-up">
                    <button
                        onClick={() => navigate(-1)}
                        className="flex items-center gap-2 text-white/50 hover:text-white mb-8 transition-colors text-sm font-medium backdrop-blur-sm px-4 py-2 rounded-full bg-black/20 hover:bg-black/40 w-fit"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Profile
                    </button>

                    <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl p-8 shadow-2xl ring-1 ring-white/10">
                        <div className="text-center mb-8">
                            <div className="relative w-32 h-32 mx-auto mb-4 group">
                                <div className="absolute inset-0 bg-gradient-to-tr from-purple-500 to-blue-500 rounded-full blur-lg opacity-50 group-hover:opacity-100 transition-opacity duration-500" />
                                <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-white/10 shadow-xl bg-gray-800">
                                    {getPhoto() ? (
                                        <img src={getPhoto()} alt={getName()} className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center text-white/50 font-bold text-3xl">
                                            {getName().charAt(0)}
                                        </div>
                                    )}
                                </div>
                                <div className="absolute -bottom-2 -right-2 bg-purple-600 text-white p-2 rounded-full shadow-lg border-4 border-[#1a1a1a]">
                                    <Sparkles className="w-4 h-4" />
                                </div>
                            </div>

                            <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">{getName()}</h1>
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider
                                ${type === 'teacher' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                                    type === 'dj' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' :
                                        'bg-orange-500/20 text-orange-300 border border-orange-500/30'}`}>
                                {type} Profile
                            </span>
                        </div>

                        <ClaimForm
                            type={type as ProfileType}
                            id={id!}
                            targetName={getName()}
                            className="bg-transparent border-0 p-0 shadow-none"
                        />
                    </div>
                </div>
            </div>
        </Layout>
    );
};
