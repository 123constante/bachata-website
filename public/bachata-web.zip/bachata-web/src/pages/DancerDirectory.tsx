import { useEffect, useState } from 'react';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, User, MapPin, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Database } from '../lib/database.types';

type DancerRow = Database['public']['Tables']['dancers']['Row'];

export const DancerDirectory = () => {
    const [dancers, setDancers] = useState<DancerRow[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchDancers();
    }, []);

    const fetchDancers = async () => {
        const { data, error } = await supabase
            .from('dancers')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching dancers:', error);
        } else {
            setDancers(data || []);
        }
        setLoading(false);
    };

    return (
        <Layout>
            <div className="container animate-fade-in" style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem' }}>
                <h1 style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span className="animate-scale-in">💃</span> Dancers Directory
                </h1>

                {loading ? (
                    <div style={{ textAlign: 'center', padding: '4rem' }}>
                        <Loader2 className="animate-spin" />
                    </div>
                ) : (
                    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
                        {dancers.map((dancer) => (
                            <Link to={`/dancers/${dancer.id}`} key={dancer.id} className="card hover-scale" style={{ background: '#1a1a1a', borderRadius: '12px', overflow: 'hidden', border: '1px solid #333', display: 'block', textDecoration: 'none' }}>
                                <div style={{ height: '280px', overflow: 'hidden', background: '#222', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    {dancer.photo_url ? (
                                        <img src={dancer.photo_url} alt={dancer.full_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                    ) : (
                                        <User size={64} color="#444" />
                                    )}
                                </div>
                                <div style={{ padding: '1.5rem' }}>
                                    <h3 style={{ marginTop: 0, marginBottom: '0.5rem', fontSize: '1.2rem', color: 'white' }}>{dancer.full_name}</h3>

                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#888', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                                        <MapPin size={14} />
                                        <span>{dancer.city || 'Unknown Location'}</span>
                                        {dancer.nationality && <span>• {dancer.nationality}</span>}
                                    </div>

                                    <div style={{ marginBottom: '1rem' }}>
                                        <span style={{
                                            background: 'rgba(255, 165, 0, 0.15)', color: 'var(--color-primary)',
                                            padding: '4px 10px', borderRadius: '20px', fontSize: '0.8rem', fontWeight: 600
                                        }}>
                                            {dancer.partner_role}
                                        </span>
                                    </div>

                                    {dancer.instagram && (
                                        <div
                                            onClick={(e) => { e.preventDefault(); window.open(`https://instagram.com/${dancer.instagram!.replace('@', '')}`, '_blank') }}
                                            className="hover-text-glow" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#ccc', textDecoration: 'none', fontSize: '0.9rem', cursor: 'pointer' }}>
                                            <Instagram size={14} />
                                            {dancer.instagram}
                                        </div>
                                    )}
                                </div>
                            </Link>
                        ))}
                        {dancers.length === 0 && (
                            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '4rem', color: '#666' }}>
                                <p>No dancers found yet. Be the first to join!</p>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </Layout>
    );
};
