import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, MapPin, Instagram, Globe, Building2, Disc, GraduationCap, Phone, Mail, CheckCircle, Video, Image as ImageIcon } from 'lucide-react';
import type { Database } from '../lib/database.types';

type OrganiserRow = Database['public']['Tables']['organisers']['Row'];
type TeacherRow = Database['public']['Tables']['teacher_profiles']['Row'];
type DJRow = Database['public']['Tables']['dj_profiles']['Row'];

export const OrganiserProfile = () => {
    const { id } = useParams<{ id: string }>();
    const [organiser, setOrganiser] = useState<OrganiserRow | null>(null);
    const [teacherProfile, setTeacherProfile] = useState<TeacherRow | null>(null);
    const [djProfile, setDjProfile] = useState<DJRow | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (id) fetchProfile();
    }, [id]);

    const fetchProfile = async () => {
        try {
            const { data: orgData, error: orgError } = await supabase
                .from('organisers')
                .select('*')
                .eq('id', id!)
                .single();

            if (orgError) throw orgError;
            const organiser = orgData as OrganiserRow;
            setOrganiser(organiser);

            if (organiser.user_id) {
                const [teacherReq, djReq] = await Promise.all([
                    supabase.from('teacher_profiles').select('*').eq('user_id', organiser.user_id).single(),
                    supabase.from('dj_profiles').select('*').eq('user_id', organiser.user_id).single()
                ]) as any;

                if (teacherReq.data) setTeacherProfile(teacherReq.data as TeacherRow);
                if (djReq.data) setDjProfile(djReq.data as DJRow);
            }
        } catch (error) {
            console.error('Error fetching organiser:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)]">
                <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
            </div>
        </Layout>
    );

    if (!organiser) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)] text-gray-400">
                Organiser not found
            </div>
        </Layout>
    );

    return (
        <Layout>
            <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in">
                {/* Header */}
                <div className="flex flex-col md:flex-row gap-8 mb-12">
                    <div className="w-full md:w-1/3">
                        <div className="aspect-square rounded-2xl overflow-hidden bg-gray-800 shadow-xl border border-gray-700">
                            {organiser.photo_url ? (
                                <img src={organiser.photo_url} alt={organiser.name} className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                    <Building2 className="w-20 h-20 text-gray-600" />
                                </div>
                            )}
                        </div>

                        {/* Cross-Linking Buttons */}
                        <div className="mt-4 flex flex-col gap-2">
                            {teacherProfile && (
                                <Link to={`/teachers/${teacherProfile.id}`} className="flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-purple-400 rounded-lg transition-colors text-sm font-medium border border-gray-700">
                                    <GraduationCap className="w-4 h-4" />
                                    View Teacher Profile
                                </Link>
                            )}
                            {djProfile && (
                                <Link to={`/djs/${djProfile.id}`} className="flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-blue-400 rounded-lg transition-colors text-sm font-medium border border-gray-700">
                                    <Disc className="w-4 h-4" />
                                    View DJ Profile
                                </Link>
                            )}
                        </div>
                    </div>

                    <div className="w-full md:w-2/3 space-y-6">
                        <div>
                            <div className="flex items-center gap-3 mb-2">
                                <h1 className="text-4xl font-bold text-white">{organiser.name}</h1>
                                {organiser.verified && (
                                    <CheckCircle className="w-6 h-6 text-blue-500" fill="currentColor" color="white" />
                                )}
                            </div>

                            <div className="flex flex-wrap gap-2 mb-4">
                                {organiser.category && (
                                    <span className="px-3 py-1 bg-yellow-500/10 text-yellow-500 rounded-full border border-yellow-500/20 text-sm">
                                        {organiser.category}
                                    </span>
                                )}
                                {organiser.teaching_styles?.map((style, i) => (
                                    <span key={i} className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full border border-gray-700 text-sm">
                                        {style}
                                    </span>
                                ))}
                            </div>

                            <div className="flex items-center text-gray-400 mb-6">
                                <MapPin className="w-5 h-5 mr-2 text-yellow-500" />
                                {organiser.city || 'Global'}
                            </div>

                            {/* Claim Button */}
                            {!organiser.user_id && (
                                <Link
                                    to={`/claim/organiser/${organiser.id}`}
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors text-sm font-medium mb-4"
                                >
                                    <Building2 className="w-4 h-4" />
                                    Claim This Profile
                                </Link>
                            )}
                        </div>

                        <div className="prose prose-invert max-w-none">
                            <h3 className="text-xl font-semibold text-white mb-2">About</h3>
                            <p className="text-gray-300 whitespace-pre-wrap">{organiser.bio || 'No description available.'}</p>
                        </div>

                        <div className="flex flex-wrap gap-4 pt-6 border-t border-gray-800">
                            {organiser.email && (
                                <a href={`mailto:${organiser.email}`} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                                    <Mail className="w-5 h-5" />
                                    Email
                                </a>
                            )}
                            {organiser.phone && (
                                <a href={`tel:${organiser.phone}`} className="flex items-center gap-2 text-gray-400 hover:text-green-500 transition-colors">
                                    <Phone className="w-5 h-5" />
                                    Call
                                </a>
                            )}
                            {organiser.instagram && (
                                <a href={organiser.instagram.startsWith('http') ? organiser.instagram : `https://instagram.com/${organiser.instagram.replace('@', '')}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-pink-500 transition-colors">
                                    <Instagram className="w-5 h-5" />
                                    Instagram
                                </a>
                            )}
                            {organiser.website && (
                                <a href={organiser.website} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-yellow-500 transition-colors">
                                    <Globe className="w-5 h-5" />
                                    Website
                                </a>
                            )}
                        </div>
                    </div>
                </div>

                {/* Promo Videos Section */}
                {organiser.promo_video_urls && organiser.promo_video_urls.length > 0 && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <Video className="w-6 h-6 text-red-500" />
                            Featured Videos
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {organiser.promo_video_urls.map((url, i) => {
                                let embedUrl = url;
                                if (url.includes('youtube.com') || url.includes('youtu.be')) {
                                    let vId = '';
                                    if (url.includes('v=')) vId = url.split('v=')[1]?.split('&')[0];
                                    else if (url.includes('youtu.be/')) vId = url.split('youtu.be/')[1]?.split('?')[0];
                                    if (vId) embedUrl = `https://www.youtube.com/embed/${vId}`;
                                }
                                return (
                                    <div key={i} className="aspect-video rounded-xl overflow-hidden bg-gray-900 shadow-lg border border-gray-800">
                                        <iframe
                                            src={embedUrl}
                                            title={`Promo Video ${i}`}
                                            className="w-full h-full"
                                            frameBorder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowFullScreen
                                        />
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Gallery Section */}
                {organiser.gallery_urls && organiser.gallery_urls.length > 0 && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <ImageIcon className="w-6 h-6 text-purple-500" />
                            Gallery
                        </h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {organiser.gallery_urls.map((url, i) => (
                                <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-800 transform hover:scale-105 transition-transform duration-300 cursor-pointer border border-gray-700">
                                    <img src={url} alt={`Gallery ${i}`} className="w-full h-full object-cover" />
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </Layout>
    );
};
