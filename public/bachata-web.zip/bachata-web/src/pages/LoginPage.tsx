import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { Loader2, LogIn } from 'lucide-react';

export const LoginPage = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const from = location.state?.from?.pathname || '/';

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const { error } = await supabase.auth.signInWithPassword({
                email,
                password,
            });

            if (error) throw error;

            // Redirect to where they came from (or home)
            navigate(from, { replace: true });
        } catch (err) {
            console.error('Login error:', err);
            setError((err as Error).message || 'Failed to login');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Layout>
            <div style={{
                minHeight: '60vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '1rem'
            }}>
                <div style={{
                    width: '100%',
                    maxWidth: '400px',
                    background: '#111', // Card background matching theme
                    border: '1px solid #333',
                    borderRadius: '12px',
                    padding: '2rem',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.5)'
                }}>
                    <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
                        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', color: '#fff' }}>
                            <LogIn size={24} color="#ff9500" />
                            Welcome Back
                        </h1>
                        <p style={{ color: '#888', fontSize: '0.9rem', marginTop: '0.5rem' }}>
                            Sign in to manage your profile and claims
                        </p>
                    </div>

                    <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        {error && (
                            <div style={{
                                background: 'rgba(239, 68, 68, 0.1)',
                                border: '1px solid #ef4444',
                                color: '#ef4444',
                                padding: '0.75rem',
                                borderRadius: '8px',
                                fontSize: '0.9rem',
                                textAlign: 'center'
                            }}>
                                {error}
                            </div>
                        )}

                        <div>
                            <label style={{ display: 'block', color: '#ccc', fontSize: '0.85rem', marginBottom: '0.4rem' }}>Email</label>
                            <input
                                type="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '0.75rem',
                                    borderRadius: '8px',
                                    background: '#222',
                                    border: '1px solid #444',
                                    color: 'white',
                                    fontSize: '1rem',
                                    outline: 'none'
                                }}
                                placeholder="you@example.com"
                            />
                        </div>

                        <div>
                            <label style={{ display: 'block', color: '#ccc', fontSize: '0.85rem', marginBottom: '0.4rem' }}>Password</label>
                            <input
                                type="password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '0.75rem',
                                    borderRadius: '8px',
                                    background: '#222',
                                    border: '1px solid #444',
                                    color: 'white',
                                    fontSize: '1rem',
                                    outline: 'none'
                                }}
                                placeholder="••••••••"
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            style={{
                                marginTop: '0.5rem',
                                background: '#ff9500',
                                color: 'black',
                                fontWeight: 'bold',
                                padding: '0.75rem',
                                borderRadius: '8px',
                                border: 'none',
                                cursor: loading ? 'not-allowed' : 'pointer',
                                opacity: loading ? 0.7 : 1,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px',
                                fontSize: '1rem'
                            }}
                        >
                            {loading && <Loader2 size={18} className="animate-spin" />}
                            {loading ? 'Signing in...' : 'Sign In'}
                        </button>
                    </form>
                </div>
            </div>
        </Layout>
    );
};
