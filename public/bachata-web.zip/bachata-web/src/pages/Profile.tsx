import { useState, useEffect, useRef } from 'react';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import {
  Loader2,
  Save,
  Upload,
  Instagram,
  Globe,
  CheckCircle,
  XCircle,
  Search,
  Minus,
  Plus,
  Building2,
  User,
  Link as LinkIcon,
  Mail,
} from 'lucide-react';
import type { Database } from '../lib/database.types';

type DancerRow = Database['public']['Tables']['dancers']['Row'];
type TeacherRow = Database['public']['Tables']['teacher_profiles']['Row'];
type OrganiserRow = Database['public']['Tables']['organisers']['Row'];

// Countries (sorted)
const COUNTRIES = [
  { code: 'AF', name: 'Afghanistan' },
  { code: 'AL', name: 'Albania' },
  { code: 'DZ', name: 'Algeria' },
  { code: 'AD', name: 'Andorra' },
  { code: 'AO', name: 'Angola' },
  { code: 'AR', name: 'Argentina' },
  { code: 'AM', name: 'Armenia' },
  { code: 'AU', name: 'Australia' },
  { code: 'AT', name: 'Austria' },
  { code: 'AZ', name: 'Azerbaijan' },
  { code: 'BS', name: 'Bahamas' },
  { code: 'BH', name: 'Bahrain' },
  { code: 'BD', name: 'Bangladesh' },
  { code: 'BB', name: 'Barbados' },
  { code: 'BY', name: 'Belarus' },
  { code: 'BE', name: 'Belgium' },
  { code: 'BZ', name: 'Belize' },
  { code: 'BJ', name: 'Benin' },
  { code: 'BO', name: 'Bolivia' },
  { code: 'BA', name: 'Bosnia and Herzegovina' },
  { code: 'BW', name: 'Botswana' },
  { code: 'BR', name: 'Brazil' },
  { code: 'BG', name: 'Bulgaria' },
  { code: 'KH', name: 'Cambodia' },
  { code: 'CM', name: 'Cameroon' },
  { code: 'CA', name: 'Canada' },
  { code: 'CL', name: 'Chile' },
  { code: 'CN', name: 'China' },
  { code: 'CO', name: 'Colombia' },
  { code: 'CR', name: 'Costa Rica' },
  { code: 'HR', name: 'Croatia' },
  { code: 'CU', name: 'Cuba' },
  { code: 'CY', name: 'Cyprus' },
  { code: 'CZ', name: 'Czech Republic' },
  { code: 'DK', name: 'Denmark' },
  { code: 'DO', name: 'Dominican Republic' },
  { code: 'EC', name: 'Ecuador' },
  { code: 'EG', name: 'Egypt' },
  { code: 'SV', name: 'El Salvador' },
  { code: 'EE', name: 'Estonia' },
  { code: 'ET', name: 'Ethiopia' },
  { code: 'FI', name: 'Finland' },
  { code: 'FR', name: 'France' },
  { code: 'DE', name: 'Germany' },
  { code: 'GH', name: 'Ghana' },
  { code: 'GR', name: 'Greece' },
  { code: 'GT', name: 'Guatemala' },
  { code: 'HT', name: 'Haiti' },
  { code: 'HN', name: 'Honduras' },
  { code: 'HU', name: 'Hungary' },
  { code: 'IS', name: 'Iceland' },
  { code: 'IN', name: 'India' },
  { code: 'ID', name: 'Indonesia' },
  { code: 'IR', name: 'Iran' },
  { code: 'IE', name: 'Ireland' },
  { code: 'IL', name: 'Israel' },
  { code: 'IT', name: 'Italy' },
  { code: 'JM', name: 'Jamaica' },
  { code: 'JP', name: 'Japan' },
  { code: 'JO', name: 'Jordan' },
  { code: 'KZ', name: 'Kazakhstan' },
  { code: 'KE', name: 'Kenya' },
  { code: 'KR', name: 'South Korea' },
  { code: 'KW', name: 'Kuwait' },
  { code: 'LV', name: 'Latvia' },
  { code: 'LB', name: 'Lebanon' },
  { code: 'LT', name: 'Lithuania' },
  { code: 'LU', name: 'Luxembourg' },
  { code: 'MY', name: 'Malaysia' },
  { code: 'MX', name: 'Mexico' },
  { code: 'MA', name: 'Morocco' },
  { code: 'NL', name: 'Netherlands' },
  { code: 'NZ', name: 'New Zealand' },
  { code: 'NI', name: 'Nicaragua' },
  { code: 'NG', name: 'Nigeria' },
  { code: 'NO', name: 'Norway' },
  { code: 'PK', name: 'Pakistan' },
  { code: 'PA', name: 'Panama' },
  { code: 'PY', name: 'Paraguay' },
  { code: 'PE', name: 'Peru' },
  { code: 'PH', name: 'Philippines' },
  { code: 'PL', name: 'Poland' },
  { code: 'PT', name: 'Portugal' },
  { code: 'QA', name: 'Qatar' },
  { code: 'RO', name: 'Romania' },
  { code: 'RU', name: 'Russia' },
  { code: 'SA', name: 'Saudi Arabia' },
  { code: 'RS', name: 'Serbia' },
  { code: 'SG', name: 'Singapore' },
  { code: 'SK', name: 'Slovakia' },
  { code: 'SI', name: 'Slovenia' },
  { code: 'ZA', name: 'South Africa' },
  { code: 'ES', name: 'Spain' },
  { code: 'LK', name: 'Sri Lanka' },
  { code: 'SE', name: 'Sweden' },
  { code: 'CH', name: 'Switzerland' },
  { code: 'TW', name: 'Taiwan' },
  { code: 'TH', name: 'Thailand' },
  { code: 'TN', name: 'Tunisia' },
  { code: 'TR', name: 'Turkey' },
  { code: 'UA', name: 'Ukraine' },
  { code: 'AE', name: 'United Arab Emirates' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'US', name: 'United States' },
  { code: 'UY', name: 'Uruguay' },
  { code: 'VE', name: 'Venezuela' },
  { code: 'VN', name: 'Vietnam' },
].sort((a, b) => a.name.localeCompare(b.name));

const DANCE_STYLE_GROUPS = {
  Bachata: ['Bachata Sensual', 'Bachata Dominican', 'Bachata Moderna'],
  Salsa: ['Salsa On1', 'Salsa On2', 'Cuban Salsa (Casino)', 'Rueda de Casino'],
  Kizomba: ['Kizomba', 'Urban Kiz', 'Semba'],
  Other: [
    'Zouk',
    'West Coast Swing',
    'Tango',
    'Cha Cha',
    'Merengue',
    'Reggaeton',
    'Hip Hop',
    'Ballroom',
    'Latin Hustle',
    'Afro House',
    'Contemporary',
    'Ballet',
    'Jazz',
  ],
} as const;

const DANCE_STYLES = [
  'Bachata Sensual',
  'Bachata Dominican',
  'Bachata Moderna',
  'Salsa On1',
  'Salsa On2',
  'Cuban Salsa (Casino)',
  'Rueda de Casino',
  'Kizomba',
  'Urban Kiz',
  'Semba',
  'Zouk',
  'West Coast Swing',
  'Tango',
  'Hip Hop',
  'Ballroom',
  'Latin Hustle',
  'Afro House',
  'Contemporary',
  'Ballet',
  'Jazz',
];

const AVAILABILITY_OPTIONS = [
  'Weekdays Daytime',
  'Weekdays Evening',
  'Weekends Daytime',
  'Weekends Evening',
  'Flexible',
  'Occasionally',
];

const PARTNER_GOALS_OPTIONS = [
  'Social Dancing',
  'Practice / Drilling',
  'Taking Classes / Workshops',
  'Competitions',
  'Performance / Shows',
  'Teaching',
  'Video Projects',
  'Improve technique',
  'Finding a long-term partner',
  'Preparing for festivals',
];

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '0.75rem',
  borderRadius: 'var(--radius-sm)',
  border: '1px solid #333',
  background: '#222',
  color: 'white',
  marginBottom: '1rem',
  transition: 'all 0.2s ease',
};

export const Profile = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [activeTab, setActiveTab] = useState<'dancer' | 'teacher' | 'organiser'>('dancer');

  const [showFlagModal, setShowFlagModal] = useState(false);
  const [flagSearch, setFlagSearch] = useState('');
  const [flagTarget, setFlagTarget] = useState<'dancer' | 'teacher' | null>('dancer');

  // Dancer state
  const [dancerData, setDancerData] = useState({
    full_name: '',
    photo_url: '',
    city: 'London',
    nationality: '',
    years_dancing: 0,
    favorite_styles: [] as string[],
    partner_role: 'Switch',
    instagram: '',
    facebook: '',
    phone: '',
    looking_for_partner: false,
    partner_goals: [] as string[],
    partner_availability: [] as string[],
    favorite_songs: ['', '', ''] as string[],
    achievements: ['', '', ''] as string[],
    festival_plans: Array(5).fill({ name: '', status: 'thinking' }) as {
      name: string;
      status: 'thinking' | 'going';
    }[],
  });

  // Teacher state
  const [teacherData, setTeacherData] = useState({
    full_name: '',
    photo_url: '',
    city: 'London',
    nationality: '',
    teaching_styles: [] as string[],
    bio: '',
    instagram: '',
    facebook: '',
    phone: '',
    email: '',
    website: '',
    years_teaching: 0,
    offers_private: false,
    offers_group: true,

    available_for_workshops: true,
    travel_willingness: 'UK & Europe',
  });

  // Organiser state (simple)
  const [organiserData, setOrganiserData] = useState({
    name: '',
    photo_url: '',
    bio: '',
    city: 'London',
    email: '',
    phone: '',
    website: '',
    instagram: '',
  });

  const dancerFileRef = useRef<HTMLInputElement | null>(null);
  const teacherFileRef = useRef<HTMLInputElement | null>(null);
  const organiserFileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    const { data } = await supabase.auth.getSession();
    const currentSession = data.session;

    if (!currentSession) {
      navigate('/login');
      return;
    }

    setSession(currentSession);

    const userId = currentSession.user.id;
    // Fire & forget; UI will fill in once loaded
    fetchDancerProfile(userId);
    fetchTeacherProfile(userId);
    fetchOrganiserProfile(userId);

    setLoading(false);
  };

  const fetchDancerProfile = async (userId: string) => {
    const { data } = await supabase
      .from('dancers')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (data) {
      const dancer = data as DancerRow;
      const songs = (dancer.favorite_songs || []).slice(0, 3);
      while (songs.length < 3) songs.push('');

      const details = dancer.partner_details as any;

      let avail: string[] = [];
      if (details?.availability) {
        avail = Array.isArray(details.availability)
          ? details.availability
          : [details.availability];
      }

      let goals: string[] = [];
      if (details?.goals) {
        goals = Array.isArray(details.goals) ? details.goals : [details.goals];
      }

      const achievements = (dancer.achievements as string[]) || [];
      const paddedAchievements = achievements.slice(0, 3);
      while (paddedAchievements.length < 3) paddedAchievements.push('');

      const festivalPlans = (dancer.festival_plans as any[]) || [];
      const paddedFestivals = festivalPlans.slice(0, 5);
      while (paddedFestivals.length < 5) {
        paddedFestivals.push({ name: '', status: 'thinking' });
      }

      setDancerData({
        full_name: dancer.full_name || '',
        photo_url: dancer.photo_url || '',
        city: dancer.city || 'London',
        nationality: dancer.nationality || '',
        years_dancing: dancer.years_dancing || 0,
        favorite_styles: dancer.favorite_styles || [],
        partner_role: dancer.partner_role || 'Switch',
        instagram: dancer.instagram || '',
        facebook: dancer.facebook || '',
        phone: dancer.phone || '',
        looking_for_partner: dancer.looking_for_partner || false,
        partner_goals: goals,
        partner_availability: avail,
        favorite_songs: songs as string[],
        achievements: paddedAchievements,
        festival_plans: paddedFestivals,
      });
    }
  };

  const fetchTeacherProfile = async (userId: string) => {
    const { data } = await supabase
      .from('teacher_profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (data) {
      const t = data as TeacherRow;
      setTeacherData({
        full_name: t.full_name || '',
        photo_url: t.photo_url || '',
        city: t.city || 'London',
        nationality: t.nationality || '',
        teaching_styles: t.teaching_styles || [],
        bio: t.bio || '',
        instagram: t.instagram || '',
        facebook: t.facebook || '',
        phone: t.phone || '',
        email: t.email || '',
        website: t.website || '',
        years_teaching: t.years_teaching || 0,
        offers_private: t.offers_private ?? false,
        offers_group: t.offers_group ?? true,

        travel_willingness: t.travel_willingness || 'UK & Europe',
      });
    }
  };

  const fetchOrganiserProfile = async (userId: string) => {
    const { data } = await supabase
      .from('organisers')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (data) {
      const org = data as OrganiserRow;
      setOrganiserData({
        name: org.name || '',
        photo_url: org.photo_url || '',
        bio: org.bio || '',
        city: org.city || 'London',
        email: org.email || '',
        phone: org.phone || '',
        website: org.website || '',
        instagram: org.instagram || '',
      });
    }
  };

  // -------------------
  // Handlers
  // -------------------

  const handleDancerChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
  ) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      setDancerData(prev => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked,
      }));
    } else {
      setDancerData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleTeacherChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
  ) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      setTeacherData(prev => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked,
      }));
    } else {
      setTeacherData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleOrganiserChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
  ) => {
    const { name, value } = e.target;
    setOrganiserData(prev => ({ ...prev, [name]: value }));
  };

  const handleStyleToggle = (style: string) => {
    setDancerData(prev => {
      const current = prev.favorite_styles;
      const newStyles = current.includes(style)
        ? current.filter(s => s !== style)
        : [...current, style];
      return { ...prev, favorite_styles: newStyles };
    });
  };

  const handleTeacherStyleToggle = (style: string) => {
    setTeacherData(prev => {
      const current = prev.teaching_styles;
      const newStyles = current.includes(style)
        ? current.filter(s => s !== style)
        : [...current, style];
      return { ...prev, teaching_styles: newStyles };
    });
  };

  const handleAvailabilityToggle = (option: string) => {
    setDancerData(prev => {
      const current = prev.partner_availability;
      const newAvail = current.includes(option)
        ? current.filter(o => o !== option)
        : [...current, option];
      return { ...prev, partner_availability: newAvail };
    });
  };

  const handleGoalToggle = (option: string) => {
    setDancerData(prev => {
      const current = prev.partner_goals;
      const newGoals = current.includes(option)
        ? current.filter(o => o !== option)
        : [...current, option];
      return { ...prev, partner_goals: newGoals };
    });
  };

  const handleSongChange = (index: number, value: string) => {
    const newSongs = [...dancerData.favorite_songs];
    newSongs[index] = value;
    setDancerData(prev => ({ ...prev, favorite_songs: newSongs }));
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
    type: 'dancer' | 'teacher' | 'organiser',
  ) => {
    if (!event.target.files || event.target.files.length === 0) return;
    if (!session) {
      alert('You must be logged in to upload.');
      return;
    }

    setUploading(true);
    try {
      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${session.user.id}-${type}-${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const {
        data: { publicUrl },
      } = supabase.storage.from('avatars').getPublicUrl(filePath);

      if (type === 'dancer') {
        setDancerData(prev => ({ ...prev, photo_url: publicUrl }));
      } else if (type === 'teacher') {
        setTeacherData(prev => ({ ...prev, photo_url: publicUrl }));
      } else {
        setOrganiserData(prev => ({ ...prev, photo_url: publicUrl }));
      }
    } catch (error: any) {
      alert('Error uploading image: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDancerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setSaving(true);
    try {
      const achievementsArray = dancerData.achievements
        .map(s => s.trim())
        .filter(Boolean);
      const validSongs = dancerData.favorite_songs
        .map(s => s.trim())
        .filter(Boolean);
      const festivalPlansArray = dancerData.festival_plans
        .map(f => ({ name: f.name.trim(), status: f.status || 'thinking' }))
        .filter(f => f.name.length > 0);

      const { data: existing } = await supabase
        .from('dancers')
        .select('id')
        .eq('user_id', session.user.id)
        .single();

      const payload: Partial<DancerRow> & { user_id: string } = {
        user_id: session.user.id,
        full_name: dancerData.full_name,
        photo_url: dancerData.photo_url,
        city: dancerData.city,
        nationality: dancerData.nationality,
        years_dancing: Number(dancerData.years_dancing),
        favorite_styles: dancerData.favorite_styles,
        partner_role: dancerData.partner_role,
        instagram: dancerData.instagram,
        facebook: dancerData.facebook,
        phone: dancerData.phone,
        looking_for_partner: dancerData.looking_for_partner,
        partner_details: {
          goals: dancerData.partner_goals,
          availability: dancerData.partner_availability,
        },
        achievements: achievementsArray,
        festival_plans: festivalPlansArray,
      };


      if (existing) {
        (payload as any).id = existing.id;
      }

      const { error } = await supabase.from('dancers').upsert(payload);
      if (error) throw error;
      alert('Dancer Profile Saved! 💃');
    } catch (err: any) {
      alert('Error saving dancer profile: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleTeacherSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setSaving(true);
    try {
      const { data: existing } = await supabase
        .from('teacher_profiles')
        .select('id')
        .eq('user_id', session.user.id)
        .single();

      const payload: Partial<TeacherRow> & { user_id: string } = {
        user_id: session.user.id,
        full_name: teacherData.full_name,
        photo_url: teacherData.photo_url,
        city: teacherData.city,
        nationality: teacherData.nationality,
        teaching_styles: teacherData.teaching_styles,
        bio: teacherData.bio,
        instagram: teacherData.instagram,
        facebook: teacherData.facebook,
        phone: teacherData.phone,
        email: teacherData.email,
        website: teacherData.website,
        years_teaching: Number(teacherData.years_teaching),
        offers_private: teacherData.offers_private,
        offers_group: teacherData.offers_group,

        travel_willingness: teacherData.travel_willingness,
      };

      if (existing) {
        (payload as any).id = existing.id;
      }

      const { error } = await supabase.from('teacher_profiles').upsert(payload);
      if (error) throw error;
      alert('Teacher Profile Saved! 🎓');
    } catch (err: any) {
      alert('Error saving teacher profile: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleOrganiserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setSaving(true);
    try {
      const { data: existing } = await supabase
        .from('organisers')
        .select('id')
        .eq('user_id', session.user.id)
        .single();

      const payload: Partial<OrganiserRow> & { user_id: string } = {
        user_id: session.user.id,
        name: organiserData.name,
        photo_url: organiserData.photo_url,
        bio: organiserData.bio,
        city: organiserData.city,
        email: organiserData.email,
        phone: organiserData.phone,
        website: organiserData.website,
        instagram: organiserData.instagram,
      };

      if (existing) {
        (payload as any).id = existing.id;
      }

      const { error } = await supabase.from('organisers').upsert(payload);
      if (error) throw error;
      alert('Organiser Profile Saved! 🗓️');
    } catch (err: any) {
      alert('Error saving organiser profile: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const isInstagramValid = (handle: string) => {
    if (!handle) return false;
    return handle.startsWith('@') || handle.includes('instagram.com');
  };

  const filteredCountries = COUNTRIES.filter(c =>
    c.name.toLowerCase().includes(flagSearch.toLowerCase()),
  );

  if (loading) {
    return (
      <Layout>
        <div style={{ textAlign: 'center', padding: '4rem' }}>
          <Loader2 className="animate-spin" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div
        className="profile-container animate-fade-in"
        style={{
          maxWidth: '900px',
          margin: '0 auto',
          background: 'var(--color-surface)',
          padding: '2.5rem',
          borderRadius: 'var(--radius-lg)',
          position: 'relative',
        }}
      >
        {/* Tabs */}
        <div
          style={{
            display: 'flex',
            gap: '1rem',
            marginBottom: '2rem',
            borderBottom: '1px solid #333',
          }}
        >
          <button
            onClick={() => setActiveTab('dancer')}
            className="hover-text-glow clickable"
            style={{
              flex: 1,
              padding: '1rem',
              background: 'none',
              border: 'none',
              borderBottom:
                activeTab === 'dancer'
                  ? '2px solid var(--color-primary)'
                  : '2px solid transparent',
              color: activeTab === 'dancer' ? 'white' : '#888',
              fontSize: '1.1rem',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
            }}
          >
            <User size={20} /> Dancer
          </button>

          <button
            onClick={() => setActiveTab('teacher')}
            className="hover-text-glow clickable"
            style={{
              flex: 1,
              padding: '1rem',
              background: 'none',
              border: 'none',
              borderBottom:
                activeTab === 'teacher'
                  ? '2px solid var(--color-primary)'
                  : '2px solid transparent',
              color: activeTab === 'teacher' ? 'white' : '#888',
              fontSize: '1.1rem',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
            }}
          >
            🎓 Teacher
          </button>

          <button
            onClick={() => setActiveTab('organiser')}
            className="hover-text-glow clickable"
            style={{
              flex: 1,
              padding: '1rem',
              background: 'none',
              border: 'none',
              borderBottom:
                activeTab === 'organiser'
                  ? '2px solid var(--color-primary)'
                  : '2px solid transparent',
              color: activeTab === 'organiser' ? 'white' : '#888',
              fontSize: '1.1rem',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
            }}
          >
            <Building2 size={20} /> Organiser
          </button>
        </div>

        {/* DANCER TAB */}
        {activeTab === 'dancer' && (
          <form onSubmit={handleDancerSubmit} className="animate-fade-in">
            <div
              className="grid"
              style={{
                gridTemplateColumns: '1fr 1fr',
                gap: '1.5rem',
                marginBottom: '1.5rem',
              }}
            >
              <div>
                <div
                  className="photo-upload-zone"
                  style={{ textAlign: 'center', marginBottom: '1rem' }}
                >
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      margin: '0 auto 1rem',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      border: '3px solid var(--color-primary)',
                      background: '#111',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      position: 'relative',
                    }}
                    onClick={() => dancerFileRef.current?.click()}
                    className="hover-scale clickable"
                  >
                    {dancerData.photo_url ? (
                      <img
                        src={dancerData.photo_url}
                        alt="Profile"
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                    ) : (
                      <Upload size={32} color="#666" />
                    )}
                    {uploading && (
                      <div
                        style={{
                          position: 'absolute',
                          inset: 0,
                          background: 'rgba(0,0,0,0.5)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Loader2 className="animate-spin" />
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={dancerFileRef}
                    onChange={e => handleFileUpload(e, 'dancer')}
                    accept="image/*"
                    style={{ display: 'none' }}
                  />
                  <button
                    type="button"
                    onClick={() => dancerFileRef.current?.click()}
                    className="clickable hover-scale"
                    style={{
                      background: 'none',
                      border: '1px solid #444',
                      color: '#ccc',
                      borderRadius: '4px',
                      padding: '4px 12px',
                      fontSize: '0.8rem',
                    }}
                  >
                    {uploading ? 'Uploading...' : 'Upload Photo'}
                  </button>
                </div>
              </div>

              <div
                className="animate-slide-right delay-100"
                style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
              >
                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Full Name *
                </label>
                <input
                  name="full_name"
                  value={dancerData.full_name}
                  onChange={handleDancerChange}
                  required
                  style={inputStyle}
                  placeholder="Your Name"
                  className="hover-glow"
                />

                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Currently based in:
                </label>
                <input
                  name="city"
                  value={dancerData.city}
                  onChange={handleDancerChange}
                  style={inputStyle}
                  placeholder="e.g. London"
                  className="hover-glow"
                />

                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Nationality
                </label>
                <div
                  onClick={() => {
                    setFlagTarget('dancer');
                    setShowFlagModal(true);
                  }}
                  style={{
                    ...inputStyle,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: 0,
                  }}
                  className="clickable hover-glow"
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {dancerData.nationality && (
                      <img
                        src={`https://flagsapi.com/${COUNTRIES.find(c => c.name === dancerData.nationality)?.code
                          }/flat/32.png`}
                        width={24}
                        alt="flag"
                        onError={e => {
                          (e.currentTarget as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    )}
                    <span>{dancerData.nationality || 'Select Nationality'}</span>
                  </div>
                  <Globe size={16} color="#888" />
                </div>
              </div>
            </div>

            {/* Dance stats */}
            <div
              className="stats-box animate-scale-in delay-200"
              style={{
                background:
                  'linear-gradient(145deg, rgba(255,165,0,0.1), rgba(0,0,0,0.4))',
                padding: '1.5rem',
                borderRadius: '12px',
                marginBottom: '2rem',
                border: '1px solid rgba(255,165,0,0.2)',
              }}
            >
              <h4
                className="hover-text-glow"
                style={{
                  marginTop: 0,
                  color: 'var(--color-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                }}
              >
                ⚡ Dance Stats
              </h4>

              <div
                className="grid"
                style={{
                  gridTemplateColumns: '1fr 1fr',
                  gap: '1rem',
                  marginTop: '1rem',
                }}
              >
                <div>
                  <label style={{ fontSize: '0.85rem', color: '#aaa' }}>Role</label>
                  <select
                    name="partner_role"
                    value={dancerData.partner_role}
                    onChange={handleDancerChange}
                    style={{ ...inputStyle, marginBottom: 0 }}
                    className="hover-glow"
                  >
                    <option>Lead</option>
                    <option>Follow</option>
                    <option>Switch</option>
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.85rem', color: '#aaa' }}>
                    Years Dancing
                  </label>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <button
                      type="button"
                      onClick={() =>
                        setDancerData(prev => ({
                          ...prev,
                          years_dancing: Math.max(0, prev.years_dancing - 1),
                        }))
                      }
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '50%',
                        border: '1px solid #444',
                        background: '#222',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                      className="clickable hover-scale"
                    >
                      <Minus size={16} />
                    </button>

                    <span
                      className="animate-pulse"
                      key={dancerData.years_dancing}
                      style={{
                        fontSize: '1.2rem',
                        fontWeight: 'bold',
                        width: '30px',
                        textAlign: 'center',
                      }}
                    >
                      {dancerData.years_dancing}
                    </span>

                    <button
                      type="button"
                      onClick={() =>
                        setDancerData(prev => ({
                          ...prev,
                          years_dancing: prev.years_dancing + 1,
                        }))
                      }
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '50%',
                        border: '1px solid #444',
                        background: '#222',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                      className="clickable hover-scale"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Styles */}
            <div className="animate-slide-up delay-300" style={{ marginBottom: '2rem' }}>
              <label
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontSize: '1rem',
                  fontWeight: 600,
                }}
              >
                💃 Favorite Styles
              </label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {Object.entries(DANCE_STYLE_GROUPS).map(([groupName, styles]) => (
                  <div key={groupName}>
                    <h5
                      style={{
                        margin: '0 0 0.5rem 0',
                        color: '#888',
                        fontSize: '0.9rem',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px',
                      }}
                    >
                      {groupName}
                    </h5>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                      {styles.map(style => (
                        <button
                          key={style}
                          type="button"
                          onClick={() => handleStyleToggle(style)}
                          className="hover-scale clickable"
                          style={{
                            padding: '0.5rem 1rem',
                            borderRadius: '20px',
                            border: dancerData.favorite_styles.includes(style)
                              ? '1px solid var(--color-primary)'
                              : '1px solid #444',
                            background: dancerData.favorite_styles.includes(style)
                              ? 'rgba(255,165,0,0.2)'
                              : '#222',
                            color: dancerData.favorite_styles.includes(style)
                              ? 'white'
                              : '#aaa',
                            transition: 'all 0.2s',
                          }}
                        >
                          {style}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Partner section */}
            <div
              className="animate-slide-up delay-400"
              style={{
                marginBottom: '2rem',
                padding: '1rem',
                background: '#1a1a1a',
                borderRadius: '12px',
                border: dancerData.looking_for_partner
                  ? '1px solid var(--color-primary)'
                  : '1px solid #333',
                transition: 'all 0.3s ease',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '12px',
                  marginBottom: '1rem',
                }}
              >
                <div
                  className="clickable hover-scale"
                  onClick={() =>
                    setDancerData(prev => ({
                      ...prev,
                      looking_for_partner: !prev.looking_for_partner,
                    }))
                  }
                  style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '4px',
                    border: '2px solid var(--color-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: dancerData.looking_for_partner
                      ? 'var(--color-primary)'
                      : 'transparent',
                    transition: 'all 0.2s',
                    marginTop: '0.25rem',
                  }}
                >
                  {dancerData.looking_for_partner && (
                    <CheckCircle size={16} color="white" className="animate-scale-in" />
                  )}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ margin: 0, marginBottom: '0.75rem', color: '#ddd' }}>
                    Looking for a regular dance partner:
                    <strong> Instagram + phone recommended</strong>.
                  </p>
                  <div style={{ marginBottom: '0.75rem', position: 'relative' }}>
                    <label
                      style={{
                        display: 'block',
                        marginBottom: '0.35rem',
                        fontSize: '0.85rem',
                      }}
                    >
                      Instagram
                    </label>
                    <input
                      name="instagram"
                      value={dancerData.instagram}
                      onChange={handleDancerChange}
                      placeholder="@username or link"
                      className="hover-glow"
                      style={{
                        ...inputStyle,
                        paddingRight: '40px',
                        marginBottom: 0,
                        borderColor: isInstagramValid(dancerData.instagram)
                          ? '#4ade80'
                          : dancerData.instagram
                            ? '#f87171'
                            : '#333',
                      }}
                    />
                    {dancerData.instagram && (
                      <div style={{ position: 'absolute', right: '10px', top: '32px' }}>
                        {isInstagramValid(dancerData.instagram) ? (
                          <CheckCircle
                            size={18}
                            color="#4ade80"
                            className="animate-scale-in"
                          />
                        ) : (
                          <XCircle
                            size={18}
                            color="#f87171"
                            className="animate-scale-in"
                          />
                        )}
                      </div>
                    )}
                  </div>
                  <div style={{ marginTop: '0.75rem' }}>
                    <label
                      style={{
                        display: 'block',
                        marginBottom: '0.35rem',
                        fontSize: '0.85rem',
                      }}
                    >
                      Phone
                    </label>
                    <input
                      name="phone"
                      value={dancerData.phone}
                      onChange={handleDancerChange}
                      placeholder="+44..."
                      className="hover-glow"
                      style={{ ...inputStyle, marginBottom: 0 }}
                    />
                  </div>
                </div>
              </div>

              <div style={{ marginTop: '1rem' }}>
                <label
                  style={{
                    display: 'block',
                    marginBottom: '0.35rem',
                    fontSize: '0.85rem',
                    color: '#ccc',
                  }}
                >
                  Partner Goals
                </label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {PARTNER_GOALS_OPTIONS.map(option => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => handleGoalToggle(option)}
                      className="hover-scale clickable"
                      style={{
                        padding: '0.35rem 0.8rem',
                        borderRadius: '999px',
                        border: dancerData.partner_goals.includes(option)
                          ? '1px solid var(--color-primary)'
                          : '1px solid #444',
                        background: dancerData.partner_goals.includes(option)
                          ? 'rgba(255,165,0,0.2)'
                          : '#222',
                        color: dancerData.partner_goals.includes(option)
                          ? 'white'
                          : '#aaa',
                        fontSize: '0.8rem',
                      }}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ marginTop: '1rem' }}>
                <label
                  style={{
                    display: 'block',
                    marginBottom: '0.35rem',
                    fontSize: '0.85rem',
                    color: '#ccc',
                  }}
                >
                  Partner Availability
                </label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {AVAILABILITY_OPTIONS.map(option => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => handleAvailabilityToggle(option)}
                      className="hover-scale clickable"
                      style={{
                        padding: '0.35rem 0.8rem',
                        borderRadius: '999px',
                        border: dancerData.partner_availability.includes(option)
                          ? '1px solid var(--color-primary)'
                          : '1px solid #444',
                        background: dancerData.partner_availability.includes(option)
                          ? 'rgba(255,165,0,0.2)'
                          : '#222',
                        color: dancerData.partner_availability.includes(option)
                          ? 'white'
                          : '#aaa',
                        fontSize: '0.8rem',
                      }}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Favorite songs + achievements (simple) */}
            <div
              className="animate-slide-up delay-500"
              style={{ marginBottom: '2rem', display: 'grid', gap: '1.5rem' }}
            >
              <div>
                <label
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontSize: '0.9rem',
                  }}
                >
                  Favorite Songs / Tracks (links or titles)
                </label>
                {dancerData.favorite_songs.map((song, idx) => (
                  <input
                    key={idx}
                    value={song}
                    onChange={e => handleSongChange(idx, e.target.value)}
                    style={inputStyle}
                    className="hover-glow"
                    placeholder={`Song ${idx + 1}`}
                  />
                ))}
              </div>
              <div>
                <label
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontSize: '0.9rem',
                  }}
                >
                  Achievements / Highlights
                </label>
                {dancerData.achievements.map((ach, idx) => (
                  <input
                    key={idx}
                    value={ach}
                    onChange={e => {
                      const newAch = [...dancerData.achievements];
                      newAch[idx] = e.target.value;
                      setDancerData(prev => ({ ...prev, achievements: newAch }));
                    }}
                    style={inputStyle}
                    className="hover-glow"
                    placeholder={`Achievement ${idx + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* Future Festivals */}
            <div
              className="animate-slide-up delay-600"
              style={{
                marginBottom: '2rem',
                padding: '1.5rem',
                background: '#1a1a1a',
                borderRadius: '12px',
                border: '1px solid #333',
              }}
            >
              <h4
                style={{
                  marginTop: 0,
                  marginBottom: '1rem',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                }}
              >
                🌍 Future Festivals
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {dancerData.festival_plans.map((plan, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'minmax(200px, 2fr) 1fr',
                      gap: '1rem',
                    }}
                  >
                    <input
                      value={plan.name}
                      onChange={e => {
                        const newPlans = [...dancerData.festival_plans];
                        newPlans[idx] = { ...newPlans[idx], name: e.target.value };
                        setDancerData(prev => ({ ...prev, festival_plans: newPlans }));
                      }}
                      placeholder="e.g. BachaKizz Festival, Amsterdam"
                      style={{ ...inputStyle, marginBottom: 0 }}
                      className="hover-glow"
                    />
                    <select
                      value={plan.status}
                      onChange={e => {
                        const newPlans = [...dancerData.festival_plans];
                        newPlans[idx] = {
                          ...newPlans[idx],
                          status: e.target.value as 'thinking' | 'going',
                        };
                        setDancerData(prev => ({ ...prev, festival_plans: newPlans }));
                      }}
                      style={{ ...inputStyle, marginBottom: 0 }}
                      className="hover-glow"
                    >
                      <option value="thinking">Thinking about it</option>
                      <option value="going">Going for sure 🚀</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="btn btn-primary hover-scale clickable animate-slide-up delay-600"
              style={{
                width: '100%',
                padding: '1rem',
                fontSize: '1.2rem',
                fontWeight: 'bold',
                borderRadius: '50px',
                boxShadow: '0 4px 15px rgba(255,165,0,0.3)',
              }}
            >
              {saving ? (
                <Loader2 className="animate-spin" />
              ) : (
                <>
                  <Save size={20} style={{ marginRight: '8px' }} /> Save Dancer Profile
                </>
              )}
            </button>
          </form>
        )}

        {/* TEACHER TAB */}
        {activeTab === 'teacher' && (
          <form onSubmit={handleTeacherSubmit} className="animate-fade-in">
            <div
              className="grid"
              style={{
                gridTemplateColumns: '1fr 1fr',
                gap: '1.5rem',
                marginBottom: '1.5rem',
              }}
            >
              <div>
                <div
                  className="photo-upload-zone"
                  style={{ textAlign: 'center', marginBottom: '1rem' }}
                >
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      margin: '0 auto 1rem',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      border: '3px solid var(--color-primary)',
                      background: '#111',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      position: 'relative',
                    }}
                    onClick={() => teacherFileRef.current?.click()}
                    className="hover-scale clickable"
                  >
                    {teacherData.photo_url ? (
                      <img
                        src={teacherData.photo_url}
                        alt="Teacher"
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                    ) : (
                      <Upload size={32} color="#666" />
                    )}
                    {uploading && (
                      <div
                        style={{
                          position: 'absolute',
                          inset: 0,
                          background: 'rgba(0,0,0,0.5)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Loader2 className="animate-spin" />
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={teacherFileRef}
                    onChange={e => handleFileUpload(e, 'teacher')}
                    accept="image/*"
                    style={{ display: 'none' }}
                  />
                  <button
                    type="button"
                    onClick={() => teacherFileRef.current?.click()}
                    className="clickable hover-scale"
                    style={{
                      background: 'none',
                      border: '1px solid #444',
                      color: '#ccc',
                      borderRadius: '4px',
                      padding: '4px 12px',
                      fontSize: '0.8rem',
                    }}
                  >
                    {uploading ? 'Uploading...' : 'Upload Photo'}
                  </button>
                </div>
              </div>

              <div
                className="animate-slide-right delay-100"
                style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
              >
                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Full Name *
                </label>
                <input
                  name="full_name"
                  value={teacherData.full_name}
                  onChange={handleTeacherChange}
                  required
                  style={inputStyle}
                  placeholder="Teacher Name"
                  className="hover-glow"
                />

                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Base City
                </label>
                <input
                  name="city"
                  value={teacherData.city}
                  onChange={handleTeacherChange}
                  style={inputStyle}
                  placeholder="e.g. London"
                  className="hover-glow"
                />

                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Nationality
                </label>
                <div
                  onClick={() => {
                    setFlagTarget('teacher');
                    setShowFlagModal(true);
                  }}
                  style={{
                    ...inputStyle,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: 0,
                  }}
                  className="clickable hover-glow"
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {teacherData.nationality && (
                      <img
                        src={`https://flagsapi.com/${COUNTRIES.find(c => c.name === teacherData.nationality)?.code
                          }/flat/32.png`}
                        width={24}
                        alt="flag"
                        onError={e => {
                          (e.currentTarget as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    )}
                    <span>{teacherData.nationality || 'Select Nationality'}</span>
                  </div>
                  <Globe size={16} color="#888" />
                </div>
              </div>
            </div>

            {/* Teaching styles + years */}
            <div
              className="animate-slide-up delay-200"
              style={{ marginBottom: '2rem' }}
            >
              <label
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontSize: '1rem',
                  fontWeight: 600,
                }}
              >
                🧑‍🏫 Teaching Styles
              </label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {DANCE_STYLES.map((style: string) => (
                  <button
                    key={style}
                    type="button"
                    onClick={() => handleTeacherStyleToggle(style)}
                    className="hover-scale clickable"
                    style={{
                      padding: '0.5rem 1rem',
                      borderRadius: '20px',
                      border: teacherData.teaching_styles.includes(style)
                        ? '1px solid var(--color-primary)'
                        : '1px solid #444',
                      background: teacherData.teaching_styles.includes(style)
                        ? 'rgba(255,165,0,0.2)'
                        : '#222',
                      color: teacherData.teaching_styles.includes(style)
                        ? 'white'
                        : '#aaa',
                      transition: 'all 0.2s',
                    }}
                  >
                    {style}
                  </button>
                ))}
              </div>

              <div style={{ marginTop: '1.5rem' }}>
                <label style={{ fontSize: '0.85rem', color: '#aaa' }}>
                  Years Teaching
                </label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <button
                    type="button"
                    onClick={() =>
                      setTeacherData(prev => ({
                        ...prev,
                        years_teaching: Math.max(0, prev.years_teaching - 1),
                      }))
                    }
                    style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      border: '1px solid #444',
                      background: '#222',
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    className="clickable hover-scale"
                  >
                    <Minus size={16} />
                  </button>

                  <span
                    className="animate-pulse"
                    key={teacherData.years_teaching}
                    style={{
                      fontSize: '1.2rem',
                      fontWeight: 'bold',
                      width: '30px',
                      textAlign: 'center',
                    }}
                  >
                    {teacherData.years_teaching}
                  </span>

                  <button
                    type="button"
                    onClick={() =>
                      setTeacherData(prev => ({
                        ...prev,
                        years_teaching: prev.years_teaching + 1,
                      }))
                    }
                    style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      border: '1px solid #444',
                      background: '#222',
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    className="clickable hover-scale"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* Bio */}
            <div className="animate-slide-up delay-300" style={{ marginBottom: '2rem' }}>
              <label
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontSize: '0.9rem',
                }}
              >
                Bio / Teaching Philosophy
              </label>
              <textarea
                name="bio"
                value={teacherData.bio}
                onChange={handleTeacherChange}
                rows={5}
                className="hover-glow"
                style={{ ...inputStyle, fontFamily: 'inherit' }}
                placeholder="Tell dancers what you focus on, your vibe, what people can expect in your classes..."
              />
            </div>

            {/* Offerings */}
            <div
              className="animate-slide-up delay-400"
              style={{ marginBottom: '2rem' }}
            >
              <h4 style={{ marginBottom: '0.75rem', color: '#ccc' }}>What you offer</h4>
              <div
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '1rem',
                  fontSize: '0.9rem',
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <input
                    type="checkbox"
                    name="offers_private"
                    checked={teacherData.offers_private}
                    onChange={handleTeacherChange}
                  />
                  Private Lessons
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <input
                    type="checkbox"
                    name="offers_group"
                    checked={teacherData.offers_group}
                    onChange={handleTeacherChange}
                  />
                  Group Classes
                </label>


              </div>

              <div style={{ marginTop: '1rem' }}>
                <label
                  style={{
                    display: 'block',
                    marginBottom: '0.35rem',
                    fontSize: '0.85rem',
                    color: '#ccc',
                  }}
                >
                  Travel willingness
                </label>
                <select
                  name="travel_willingness"
                  value={teacherData.travel_willingness}
                  onChange={handleTeacherChange}
                  className="hover-glow"
                  style={inputStyle}
                >
                  <option value="Local only">Local only</option>
                  <option value="UK & Europe">UK & Europe</option>
                  <option value="Worldwide">Worldwide</option>
                </select>
              </div>
            </div>

            {/* Contact & socials */}
            <div
              className="animate-slide-up delay-500"
              style={{ marginBottom: '2rem' }}
            >
              <h4
                style={{
                  marginBottom: '1rem',
                  color: '#ccc',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                }}
              >
                <LinkIcon size={16} /> Contact & Socials
              </h4>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Email
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Mail
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="email"
                  value={teacherData.email}
                  onChange={handleTeacherChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="contact@example.com"
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Website
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Globe
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="website"
                  value={teacherData.website}
                  onChange={handleTeacherChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="https://..."
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Instagram
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Instagram
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="instagram"
                  value={teacherData.instagram}
                  onChange={handleTeacherChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="@username"
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Phone / WhatsApp
              </label>
              <input
                name="phone"
                value={teacherData.phone}
                onChange={handleTeacherChange}
                style={inputStyle}
                placeholder="+44..."
                className="hover-glow"
              />

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Facebook
              </label>
              <input
                name="facebook"
                value={teacherData.facebook}
                onChange={handleTeacherChange}
                style={inputStyle}
                placeholder="Profile or page link"
                className="hover-glow"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="btn btn-primary hover-scale clickable animate-slide-up delay-600"
              style={{
                width: '100%',
                padding: '1rem',
                fontSize: '1.2rem',
                fontWeight: 'bold',
                borderRadius: '50px',
                boxShadow: '0 4px 15px rgba(255,165,0,0.3)',
              }}
            >
              {saving ? (
                <Loader2 className="animate-spin" />
              ) : (
                <>
                  <Save size={20} style={{ marginRight: '8px' }} /> Save Teacher Profile
                </>
              )}
            </button>
          </form>
        )}

        {/* ORGANISER TAB */}
        {activeTab === 'organiser' && (
          <form onSubmit={handleOrganiserSubmit} className="animate-fade-in">
            <div
              className="grid"
              style={{
                gridTemplateColumns: '1fr 1fr',
                gap: '1.5rem',
                marginBottom: '1.5rem',
              }}
            >
              <div>
                <div
                  className="photo-upload-zone"
                  style={{ textAlign: 'center', marginBottom: '1rem' }}
                >
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      margin: '0 auto 1rem',
                      borderRadius: '8px',
                      overflow: 'hidden',
                      border: '3px solid var(--color-primary)',
                      background: '#111',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      position: 'relative',
                    }}
                    onClick={() => organiserFileRef.current?.click()}
                    className="hover-scale clickable"
                  >
                    {organiserData.photo_url ? (
                      <img
                        src={organiserData.photo_url}
                        alt="Organiser"
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                    ) : (
                      <Building2 size={32} color="#666" />
                    )}
                    {uploading && (
                      <div
                        style={{
                          position: 'absolute',
                          inset: 0,
                          background: 'rgba(0,0,0,0.5)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Loader2 className="animate-spin" />
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={organiserFileRef}
                    onChange={e => handleFileUpload(e, 'organiser')}
                    accept="image/*"
                    style={{ display: 'none' }}
                  />
                  <button
                    type="button"
                    onClick={() => organiserFileRef.current?.click()}
                    className="clickable hover-scale"
                    style={{
                      background: 'none',
                      border: '1px solid #444',
                      color: '#ccc',
                      borderRadius: '4px',
                      padding: '4px 12px',
                      fontSize: '0.8rem',
                    }}
                  >
                    {uploading ? 'Uploading...' : 'Upload Logo/Photo'}
                  </button>
                </div>
              </div>

              <div className="animate-slide-right delay-100">
                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Organiser Name *
                </label>
                <input
                  name="name"
                  value={organiserData.name}
                  onChange={handleOrganiserChange}
                  required
                  style={inputStyle}
                  placeholder="e.g. Bachata Community"
                  className="hover-glow"
                />

                <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  Base City
                </label>
                <input
                  name="city"
                  value={organiserData.city}
                  onChange={handleOrganiserChange}
                  style={inputStyle}
                  placeholder="e.g. London"
                  className="hover-glow"
                />
              </div>
            </div>

            <div className="animate-slide-up delay-200" style={{ marginBottom: '2rem' }}>
              <label
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontSize: '0.9rem',
                }}
              >
                Bio / Description
              </label>
              <textarea
                name="bio"
                value={organiserData.bio}
                onChange={handleOrganiserChange}
                rows={4}
                placeholder="Tell dancers about your brand, events, and vibe..."
                className="hover-glow"
                style={{ ...inputStyle, fontFamily: 'inherit', borderColor: '#444' }}
              />
            </div>

            <div className="animate-slide-up delay-300" style={{ marginBottom: '2rem' }}>
              <h4
                style={{
                  marginBottom: '1rem',
                  color: '#ccc',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                }}
              >
                <LinkIcon size={16} /> Contact & Socials
              </h4>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Email
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Mail
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="email"
                  value={organiserData.email}
                  onChange={handleOrganiserChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="contact@example.com"
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Website
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Globe
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="website"
                  value={organiserData.website}
                  onChange={handleOrganiserChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="https://..."
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Instagram
              </label>
              <div style={{ position: 'relative', marginBottom: '1rem' }}>
                <Instagram
                  size={16}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  name="instagram"
                  value={organiserData.instagram}
                  onChange={handleOrganiserChange}
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                  placeholder="@username"
                  className="hover-glow"
                />
              </div>

              <label
                style={{
                  display: 'block',
                  marginBottom: '0.35rem',
                  fontSize: '0.9rem',
                }}
              >
                Phone / WhatsApp
              </label>
              <input
                name="phone"
                value={organiserData.phone}
                onChange={handleOrganiserChange}
                style={inputStyle}
                placeholder="+44..."
                className="hover-glow"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="btn btn-primary hover-scale clickable animate-slide-up delay-400"
              style={{
                width: '100%',
                padding: '1rem',
                fontSize: '1.2rem',
                fontWeight: 'bold',
                borderRadius: '50px',
                boxShadow: '0 4px 15px rgba(255,165,0,0.3)',
              }}
            >
              {saving ? (
                <Loader2 className="animate-spin" />
              ) : (
                <>
                  <Save size={20} style={{ marginRight: '8px' }} /> Save Organiser Profile
                </>
              )}
            </button>
          </form>
        )}

        {/* Flag Modal */}
        {showFlagModal && (
          <div
            className="modal-overlay overlay-enter"
            style={{
              position: 'fixed',
              inset: 0,
              background: 'rgba(0,0,0,0.85)',
              zIndex: 1000,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '1rem',
            }}
            onClick={() => setShowFlagModal(false)}
          >
            <div
              className="modal-enter"
              style={{
                background: '#1a1a1a',
                padding: '2rem',
                borderRadius: '16px',
                maxWidth: '600px',
                width: '100%',
                maxHeight: '80vh',
                overflowY: 'auto',
                position: 'relative',
                border: '1px solid #333',
              }}
              onClick={e => e.stopPropagation()}
            >
              <h3
                style={{
                  marginTop: 0,
                  textAlign: 'center',
                  marginBottom: '1.5rem',
                }}
              >
                Select Nationality 🌍
              </h3>

              <div style={{ position: 'relative', marginBottom: '1.5rem' }}>
                <Search
                  size={18}
                  style={{
                    position: 'absolute',
                    left: '12px',
                    top: '12px',
                    color: '#666',
                  }}
                />
                <input
                  autoFocus
                  placeholder="Search country..."
                  value={flagSearch}
                  onChange={e => setFlagSearch(e.target.value)}
                  className="hover-glow"
                  style={{ ...inputStyle, paddingLeft: '40px', marginBottom: 0 }}
                />
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
                  gap: '1rem',
                }}
              >
                {filteredCountries.map(c => (
                  <button
                    key={c.code}
                    onClick={() => {
                      if (flagTarget === 'dancer') {
                        setDancerData(prev => ({ ...prev, nationality: c.name }));
                      } else if (flagTarget === 'teacher') {
                        setTeacherData(prev => ({ ...prev, nationality: c.name }));
                      }
                      setShowFlagModal(false);
                    }}
                    className="clickable hover-scale"
                    style={{
                      background: '#222',
                      border: '1px solid #333',
                      borderRadius: '8px',
                      padding: '1rem',
                      textAlign: 'center',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLButtonElement).style.background = '#333';
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLButtonElement).style.background = '#222';
                    }}
                  >
                    <img
                      src={`https://flagsapi.com/${c.code}/flat/64.png`}
                      width={48}
                      alt={c.name}
                      loading="lazy"
                    />
                    <span style={{ fontSize: '0.9rem', color: '#eee' }}>{c.name}</span>
                  </button>
                ))}
                {filteredCountries.length === 0 && (
                  <p
                    style={{
                      textAlign: 'center',
                      gridColumn: '1/-1',
                      color: '#666',
                    }}
                  >
                    No country found 😕
                  </p>
                )}
              </div>

              <button
                onClick={() => setShowFlagModal(false)}
                className="clickable hover-scale"
                style={{
                  position: 'absolute',
                  top: '1rem',
                  right: '1rem',
                  background: 'none',
                  border: 'none',
                  color: '#666',
                }}
              >
                <XCircle size={24} />
              </button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};
