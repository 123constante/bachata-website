export default function AdminCreateTeacher() {
  return (
    <div style={{ padding: 40, color: "white" }}>
      <h1>Create Teacher (Admin Only)</h1>
    </div>
  );
}
