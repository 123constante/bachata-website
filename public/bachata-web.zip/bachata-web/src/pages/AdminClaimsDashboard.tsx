
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Layout } from '../components/Layout';
import {
    Loader2, CheckCircle, XCircle, AlertTriangle, Shield,
    LayoutDashboard, History, Inbox, RotateCcw,
    User, Mail, Phone, ExternalLink, Calendar
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Claim {
    id: string;
    user_id: string;
    profile_id: string;
    profile_type: 'teacher' | 'organiser' | 'dj';
    status: 'pending' | 'approved' | 'rejected';
    claim_name: string;
    claim_email: string;
    claim_phone: string;
    admin_notes?: string;
    created_at: string;
    updated_at: string;
}

type Tab = 'overview' | 'pending' | 'history';

export const AdminClaimsDashboard = () => {
    // State
    const [claims, setClaims] = useState<Claim[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<Tab>('pending');
    const [actionLoading, setActionLoading] = useState<string | null>(null);
    const [isAdmin, setIsAdmin] = useState(false);

    // Notes state for rejection
    const [rejectNote, setRejectNote] = useState<string>('');
    const [showRejectModal, setShowRejectModal] = useState<string | null>(null);

    useEffect(() => {
        checkAdmin();
        fetchClaims();
    }, []);

    const checkAdmin = async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data } = await supabase
            .from('profiles')
            .select('is_admin')
            .eq('id', user.id)
            .single();

        if (data?.is_admin) setIsAdmin(true);
    };

    const fetchClaims = async () => {
        const { data, error } = await supabase
            .from('profile_claims')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(100);

        if (!error && data) setClaims(data as Claim[]);
        setLoading(false);
    };

    // --- Actions ---

    const handleApprove = async (claim: Claim) => {
        if (!confirm('Verify: Grant edit access to this user?')) return;
        setActionLoading(claim.id);

        try {
            // 1. Update Target Profile Table
            let tableName = '';
            if (claim.profile_type === 'teacher') tableName = 'teacher_profiles';
            else if (claim.profile_type === 'organiser') tableName = 'organisers';
            else if (claim.profile_type === 'dj') tableName = 'dj_profiles';

            const { error: updateError } = await supabase
                .from(tableName)
                .update({ user_id: claim.user_id })
                .eq('id', claim.profile_id);

            if (updateError) throw updateError;

            // 2. Update Claim Status
            const { error: claimError } = await supabase
                .from('profile_claims')
                .update({
                    status: 'approved',
                    updated_at: new Date().toISOString()
                })
                .eq('id', claim.id);

            if (claimError) throw claimError;

            fetchClaims(); // Refresh
        } catch (error: any) {
            alert('Error: ' + error.message);
        } finally {
            setActionLoading(null);
        }
    };

    const handleReject = async (claimId: string) => {
        setActionLoading(claimId);
        try {
            const { error } = await supabase
                .from('profile_claims')
                .update({
                    status: 'rejected',
                    admin_notes: rejectNote,
                    updated_at: new Date().toISOString()
                })
                .eq('id', claimId);

            if (error) throw error;

            setShowRejectModal(null);
            setRejectNote('');
            fetchClaims();
        } catch (error: any) {
            alert('Error: ' + error.message);
        } finally {
            setActionLoading(null);
        }
    };

    const handleRevert = async (claim: Claim) => {
        if (!confirm('Revert this decision? This will undo the approval/rejection.')) return;
        setActionLoading(claim.id);

        try {
            // If it was APPROVED, we must remove access from the profile
            if (claim.status === 'approved') {
                let tableName = '';
                if (claim.profile_type === 'teacher') tableName = 'teacher_profiles';
                else if (claim.profile_type === 'organiser') tableName = 'organisers';
                else if (claim.profile_type === 'dj') tableName = 'dj_profiles';

                // Safety: Only remove if it's STILL the same user
                const { error: revertError } = await supabase
                    .from(tableName)
                    .update({ user_id: null })
                    .eq('id', claim.profile_id)
                    .eq('user_id', claim.user_id);

                if (revertError) throw revertError;
            }

            // Set back to pending
            const { error } = await supabase
                .from('profile_claims')
                .update({
                    status: 'pending',
                    admin_notes: null, // clear notes on revert
                    updated_at: new Date().toISOString()
                })
                .eq('id', claim.id);

            if (error) throw error;

            fetchClaims();
        } catch (error: any) {
            alert('Error reverting: ' + error.message);
        } finally {
            setActionLoading(null);
        }
    };


    // --- Derived Data ---
    const pendingClaims = claims.filter(c => c.status === 'pending');
    const historyClaims = claims.filter(c => c.status !== 'pending');

    // Stats
    const stats = {
        total: claims.length,
        pending: pendingClaims.length,
        approved: claims.filter(c => c.status === 'approved').length,
        rejected: claims.filter(c => c.status === 'rejected').length
    };


    // --- Render Helpers ---

    if (!isAdmin && !loading) return (
        <Layout>
            <div className="flex flex-col items-center justify-center h-[60vh] text-center px-4">
                <Shield className="w-16 h-16 text-gray-700 mb-4" />
                <h1 className="text-2xl font-bold text-white mb-2">AccessRestricted</h1>
                <p className="text-gray-400">This dashboard is for verified administrators only.</p>
            </div>
        </Layout>
    );

    return (
        <Layout>
            <div className="max-w-7xl mx-auto px-4 py-8 min-h-screen">

                {/* Header */}
                <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4 border-b border-gray-800 pb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-white bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
                            Admin Command Center
                        </h1>
                        <p className="text-gray-400 mt-1">Manage profile ownership and verification requests.</p>
                    </div>
                </div>

                {/* Tabs & Stats Combo */}
                <div className="grid lg:grid-cols-4 gap-6 mb-8">
                    {/* Navigation Sidebar / Tabs */}
                    <div className="lg:col-span-1 space-y-2">
                        <button
                            onClick={() => setActiveTab('overview')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'overview'
                                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/20'
                                    : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800'
                                }`}
                        >
                            <LayoutDashboard className="w-5 h-5" />
                            Overview
                        </button>
                        <button
                            onClick={() => setActiveTab('pending')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'pending'
                                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20'
                                    : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800'
                                }`}
                        >
                            <Inbox className="w-5 h-5" />
                            Pending Requests
                            {stats.pending > 0 && (
                                <span className="ml-auto bg-white/20 text-white text-xs px-2 py-0.5 rounded-full">
                                    {stats.pending}
                                </span>
                            )}
                        </button>
                        <button
                            onClick={() => setActiveTab('history')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'history'
                                    ? 'bg-gray-700 text-white shadow-lg'
                                    : 'bg-gray-900/50 text-gray-400 hover:bg-gray-800'
                                }`}
                        >
                            <History className="w-5 h-5" />
                            History Log
                        </button>
                    </div>

                    {/* Main Content Area */}
                    <div className="lg:col-span-3">
                        {loading ? (
                            <div className="flex justify-center py-20">
                                <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
                            </div>
                        ) : (
                            <div className="animate-fade-in">

                                {/* OVERVIEW TAB */}
                                {activeTab === 'overview' && (
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <StatCard
                                            label="Pending Review"
                                            value={stats.pending}
                                            color="blue"
                                            icon={<Inbox className="w-6 h-6 text-blue-400" />}
                                        />
                                        <StatCard
                                            label="Total Approved"
                                            value={stats.approved}
                                            color="green"
                                            icon={<CheckCircle className="w-6 h-6 text-green-400" />}
                                        />
                                        <StatCard
                                            label="Rejected"
                                            value={stats.rejected}
                                            color="red"
                                            icon={<XCircle className="w-6 h-6 text-red-400" />}
                                        />
                                        <div className="md:col-span-3 bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mt-4">
                                            <h3 className="text-lg font-semibold text-white mb-2">Instructions</h3>
                                            <ul className="space-y-2 text-gray-400 text-sm">
                                                <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> <b>Approve:</b> Grants the user full editing rights to the profile.</li>
                                                <li className="flex gap-2"><XCircle className="w-4 h-4 text-red-500" /> <b>Reject:</b> Denies access. You can leave a note explaining why.</li>
                                                <li className="flex gap-2"><RotateCcw className="w-4 h-4 text-gray-500" /> <b>Revert:</b> Made a mistake? Undo an approval or rejection in the History tab.</li>
                                            </ul>
                                        </div>
                                    </div>
                                )}

                                {/* PENDING TAB */}
                                {activeTab === 'pending' && (
                                    <div className="space-y-4">
                                        {pendingClaims.length === 0 ? (
                                            <div className="text-center py-20 bg-gray-900/30 rounded-2xl border border-gray-800/50 border-dashed">
                                                <CheckCircle className="w-12 h-12 text-gray-700 mx-auto mb-4" />
                                                <h3 className="text-white font-medium">All caught up!</h3>
                                                <p className="text-gray-500">No pending claims to review.</p>
                                            </div>
                                        ) : (
                                            pendingClaims.map(claim => (
                                                <ClaimCard
                                                    key={claim.id}
                                                    claim={claim}
                                                    onApprove={() => handleApprove(claim)}
                                                    onReject={() => setShowRejectModal(claim.id)} // Open modal
                                                    actionLoading={actionLoading}
                                                />
                                            ))
                                        )}
                                    </div>
                                )}

                                {/* HISTORY TAB */}
                                {activeTab === 'history' && (
                                    <div className="space-y-4">
                                        {historyClaims.length === 0 ? (
                                            <div className="text-center py-20 text-gray-500">No history available yet.</div>
                                        ) : (
                                            historyClaims.map(claim => (
                                                <ClaimCard
                                                    key={claim.id}
                                                    claim={claim}
                                                    isHistory
                                                    onRevert={() => handleRevert(claim)}
                                                    actionLoading={actionLoading}
                                                />
                                            ))
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

                {/* Reject Modal */}
                {showRejectModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 w-full max-w-md animate-fade-in-up">
                            <h3 className="text-xl font-bold text-white mb-2">Reject Claim</h3>
                            <p className="text-gray-400 text-sm mb-4">Please provide a reason for rejection (visible to admins only for now).</p>

                            <textarea
                                value={rejectNote}
                                onChange={e => setRejectNote(e.target.value)}
                                placeholder="E.g., Identity could not be verified..."
                                className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 text-white focus:ring-2 focus:ring-red-500 outline-none mb-4 h-32 resize-none"
                            />

                            <div className="flex gap-3">
                                <button
                                    onClick={() => { setShowRejectModal(null); setRejectNote(''); }}
                                    className="flex-1 px-4 py-2 rounded-lg bg-gray-800 text-white hover:bg-gray-700 font-medium"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={() => handleReject(showRejectModal)}
                                    disabled={!rejectNote.trim() || !!actionLoading}
                                    className="flex-1 px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 font-medium disabled:opacity-50"
                                >
                                    {actionLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Confirm Reject'}
                                </button>
                            </div>
                        </div>
                    </div>
                )}

            </div>
        </Layout>
    );
};

// --- Sub-Components ---

const StatCard = ({ label, value, color, icon }: { label: string, value: number, color: string, icon: React.ReactNode }) => (
    <div className={`bg-gray-900 border border-gray-800 rounded-2xl p-5 relative overflow-hidden group hover:border-${color}-500/50 transition-colors`}>
        <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity`}>
            {icon}
        </div>
        <p className="text-gray-400 text-sm font-medium mb-1">{label}</p>
        <p className="text-3xl font-bold text-white">{value}</p>
    </div>
);

const ClaimCard = ({
    claim,
    onApprove,
    onReject,
    onRevert,
    isHistory = false,
    actionLoading
}: {
    claim: Claim,
    onApprove?: () => void,
    onReject?: () => void,
    onRevert?: () => void,
    isHistory?: boolean,
    actionLoading: string | null
}) => {

    // Helper to get correct route
    const getProfileLink = () => {
        const type = claim.profile_type === 'organiser' ? 'organisers' : `${claim.profile_type}s`; // Pluralize
        return `/${type}/${claim.profile_id}`;
    };

    return (
        <div className={`bg-gray-900 border ${isHistory ? 'border-gray-800 opacity-75 hover:opacity-100' : 'border-gray-700 shadow-lg'} rounded-xl p-5 transition-all`}>

            {/* Header / Status Badge */}
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider
                        ${claim.profile_type === 'teacher' ? 'bg-purple-900/30 text-purple-300 border border-purple-800' :
                            claim.profile_type === 'dj' ? 'bg-blue-900/30 text-blue-300 border border-blue-800' :
                                'bg-orange-900/30 text-orange-300 border border-orange-800'}`}>
                        {claim.profile_type}
                    </span>
                    <span className="text-gray-500 text-xs">
                        • {new Date(claim.created_at).toLocaleDateString()} at {new Date(claim.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                </div>
                {isHistory && (
                    <span className={`px-3 py-1 rounded-full text-xs font-bold capitalize flex items-center gap-1
                        ${claim.status === 'approved' ? 'bg-green-900/20 text-green-400' : 'bg-red-900/20 text-red-400'}`}>
                        {claim.status === 'approved' ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                        {claim.status}
                    </span>
                )}
            </div>

            {/* Content Grid */}
            <div className="grid md:grid-cols-2 gap-6 mb-4">
                {/* Claimant Info */}
                <div className="bg-black/20 rounded-lg p-3">
                    <h4 className="text-xs font-bold text-gray-500 uppercase mb-2 flex items-center gap-1">
                        <User className="w-3 h-3" /> Claimant Identity
                    </h4>
                    <div className="space-y-1">
                        <p className="text-white font-medium text-lg">{claim.claim_name}</p>
                        <a href={`mailto:${claim.claim_email}`} className="text-sm text-blue-400 hover:underline flex items-center gap-2">
                            <Mail className="w-3 h-3" /> {claim.claim_email}
                        </a>
                        <a href={`tel:${claim.claim_phone}`} className="text-sm text-gray-400 hover:text-white flex items-center gap-2">
                            <Phone className="w-3 h-3" /> {claim.claim_phone}
                        </a>
                    </div>
                </div>

                {/* Target Profile Info */}
                <div className="bg-black/20 rounded-lg p-3 relative group">
                    <h4 className="text-xs font-bold text-gray-500 uppercase mb-2 flex items-center gap-1">
                        <Shield className="w-3 h-3" /> Target Profile
                    </h4>
                    <p className="text-gray-300 text-sm mb-1">Requesting ownership of:</p>
                    <div className="flex justify-between items-center">
                        <span className="text-white font-mono text-xs bg-gray-800 px-2 py-1 rounded select-all">
                            ID: {claim.profile_id}
                        </span>
                        <Link
                            to={getProfileLink()}
                            target="_blank"
                            className="text-xs bg-gray-800 hover:bg-gray-700 text-white px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
                        >
                            View Profile <ExternalLink className="w-3 h-3" />
                        </Link>
                    </div>
                </div>
            </div>

            {/* Admin Notes (if Rejected/History) */}
            {claim.admin_notes && (
                <div className="mb-4 bg-red-900/10 border border-red-900/30 p-3 rounded-lg text-sm text-red-200">
                    <span className="font-bold block text-xs text-red-400 uppercase mb-1">Admin Reason:</span>
                    {claim.admin_notes}
                </div>
            )}

            {/* Actions Toolbar */}
            <div className="border-t border-gray-800 pt-3 flex justify-end gap-3">
                {!isHistory ? (
                    <>
                        <button
                            onClick={onReject}
                            disabled={actionLoading === claim.id}
                            className="px-4 py-2 rounded-lg bg-red-900/20 text-red-400 hover:bg-red-900/40 border border-red-900/30 text-sm font-medium transition-colors flex items-center gap-2"
                        >
                            <XCircle className="w-4 h-4" /> Reject
                        </button>
                        <button
                            onClick={onApprove}
                            disabled={actionLoading === claim.id}
                            className="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 shadow-lg shadow-green-900/20 text-sm font-medium transition-colors flex items-center gap-2"
                        >
                            {actionLoading === claim.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                            Approve Access
                        </button>
                    </>
                ) : (
                    <button
                        onClick={onRevert}
                        disabled={actionLoading === claim.id}
                        className="px-4 py-2 rounded-lg bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700 text-sm font-medium transition-colors flex items-center gap-2"
                    >
                        {actionLoading === claim.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                        Revert Decision
                    </button>
                )}
            </div>
        </div>
    );
};
