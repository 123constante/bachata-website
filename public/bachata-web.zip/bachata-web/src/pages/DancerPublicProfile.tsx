import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import {
  Loader2,
  User,
  MapPin,
  Share2,
  Music,
  Trophy,
  Ticket
} from 'lucide-react';
import './styles/dancer-profile.css';

import type { Database } from '../lib/database.types';
import {
  getRelativeEventDate
} from '../lib/attendance';

type DancerRow = Database['public']['Tables']['dancers']['Row'];

// Extend the base row to include the joined data
interface DancerWithEvents extends DancerRow {
  event_attendees: {
    status: 'going' | 'interested' | null;
    events: Database['public']['Tables']['events']['Row'];
  }[];
}

const getFlagUrl = (nationality?: string | null) => {
  if (!nationality) return null;
  const map: Record<string, string> = {
    'United Kingdom': 'GB',
    UK: 'GB',
    England: 'GB',
    Spain: 'ES',
    Italy: 'IT',
    France: 'FR',
    Germany: 'DE',
    Australia: 'AU',
    Ecuador: 'EC',
    'United States': 'US',
    USA: 'US'
  };
  const code = map[nationality];
  return code ? `https://flagsapi.com/${code}/flat/32.png` : null;
};

interface UpcomingEvent {
  event_id: string;
  status: 'going' | 'interested' | null;
  event: Database['public']['Tables']['events']['Row'] & {
    slug: string;
    start_date: string; // mapped from 'date'
  };
}

interface PartnerDetails {
  goals?: string[];
  availability?: string[];
}

export const DancerPublicProfile = () => {
  const { id } = useParams<{ id: string }>();

  const [dancer, setDancer] = useState<DancerWithEvents | null>(null);
  const [upcomingEvents, setUpcomingEvents] = useState<UpcomingEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPartnerDetails, setShowPartnerDetails] = useState(false);

  useEffect(() => {
    const fetchDancer = async () => {
      try {
        // 1) Single query: get dancer + their event_attendees + the event details
        const { data, error } = await supabase
          .from('dancers')
          .select(`
          *,
          event_attendees (
            status,
            events (
              *
            )
          )
        `)
          .eq('id', id!)
          .single(); // The response type here won't automatically have event_attendees without complex generics

        if (error) throw error;

        if (data) {
          // Cast data to our extended type since Supabase types won't automatically infer the join structure 
          // without precise generic injection which is verbose.
          const fullDancer = data as unknown as DancerWithEvents;
          setDancer(fullDancer);

          // 2) Process events:
          //    - The query returns 'event_attendees' as an array of objects
          //    - Each object has { status, events: {...} }
          //    - We need to filter for future dates and map to our UI format
          if (fullDancer.event_attendees && Array.isArray(fullDancer.event_attendees)) {
            const now = new Date();
            now.setHours(0, 0, 0, 0); // Include events happening today

            const mappedEvents: UpcomingEvent[] = fullDancer.event_attendees
              .map((att) => {
                const evt = att.events;
                if (!evt) return null;

                return {
                  event_id: evt.id,
                  status: att.status,
                  event: {
                    ...evt,
                    slug: evt.name.toLowerCase().replace(/ /g, '-'),
                    start_date: evt.date
                  }
                };
              })
              .filter((item): item is UpcomingEvent => {
                if (!item) return false;
                // Filter future events
                return new Date(item.event.start_date) >= now;
              })
              .sort((a, b) => {
                return new Date(a.event.start_date).getTime() - new Date(b.event.start_date).getTime();
              });

            setUpcomingEvents(mappedEvents);
          }
        }
      } catch (err) {
        console.error('Error fetching dancer:', err);
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchDancer();
  }, [id]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    alert('Profile link copied');
  };

  if (loading) {
    return (
      <Layout>
        <div className="dp-loading">
          <Loader2 className="animate-spin" size={32} color="#d4af37" />
        </div>
      </Layout>
    );
  }

  if (!dancer) {
    return (
      <Layout>
        <div className="dp-not-found">
          <h2>Dancer not found</h2>
          <Link to="/dancers">Back to directory</Link>
        </div>
      </Layout>
    );
  }

  const flagUrl = getFlagUrl(dancer.nationality);
  const partnerDetails = dancer.partner_details as unknown as PartnerDetails;
  const goals = partnerDetails?.goals || [];
  const availability = partnerDetails?.availability || [];

  return (
    <Layout>
      <div className="dancer-profile-container">

        {/* HEADER */}
        <header className="dp-header">
          <div className="dp-avatar-frame">
            {dancer.photo_url ? (
              <img src={dancer.photo_url} alt={dancer.full_name} className="dp-avatar" />
            ) : (
              <div className="dp-avatar dp-avatar-empty">
                <User size={40} />
              </div>
            )}

            {flagUrl && (
              <img src={flagUrl} className="dp-flag-badge" alt="flag" />
            )}
          </div>

          <h1 className="dp-name">{dancer.full_name}</h1>

          <div className="dp-subtitle">
            <MapPin size={14} />
            <span>{dancer.city || 'Unknown location'}</span>
          </div>

          <div className="dp-header-underline" />
        </header>

        {/* UPCOMING EVENTS */}
        {upcomingEvents.length > 0 && (
          <section className="dp-section">
            <h3 className="dp-section-title">Upcoming events</h3>

            <div className="dp-events-grid">
              {upcomingEvents.map((item) => (
                <Link
                  key={item.event_id}
                  to={`/event/${item.event.slug}`}
                  className={`event-mini-card ${item.status === 'going' ? 'going' : 'interested'
                    }`}
                >
                  <div className="event-mini-name">
                    {item.event.name}
                  </div>
                  <div className="event-mini-date">
                    {getRelativeEventDate(item.event.start_date)}
                  </div>
                  <div className="event-mini-status">
                    {item.status === 'going' ? 'Going' : 'Interested'}
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* ABOUT */}
        <section className="dp-about-grid">
          <div className="dp-stat-box">
            <span className="dp-stat-value">{dancer.years_dancing || 0}</span>
            <span className="dp-stat-label">Years dancing</span>
          </div>
          <div className="dp-stat-box">
            <span className="dp-stat-value">{dancer.partner_role || 'Switch'}</span>
            <span className="dp-stat-label">Role</span>
          </div>
          <div className="dp-stat-box">
            <span className="dp-stat-value">{dancer.city || '—'}</span>
            <span className="dp-stat-label">Based in</span>
          </div>
        </section>

        {/* STYLES */}
        {(dancer.favorite_styles?.length ?? 0) > 0 && (
          <section className="dp-section">
            <h3 className="dp-section-title">Favourite styles</h3>
            <div className="dp-styles-row">
              {dancer.favorite_styles!.map((style) => (
                <span key={style} className="dp-pill">{style}</span>
              ))}
            </div>
          </section>
        )}

        {/* ACHIEVEMENTS */}
        {(dancer.achievements?.length ?? 0) > 0 && (
          <section className="dp-section">
            <h3 className="dp-section-title">
              <Trophy size={16} /> Achievements
            </h3>
            <ul style={{ paddingLeft: '1.2rem', color: '#e5e7eb' }}>
              {dancer.achievements!.map((ach, i) => (
                <li key={i} style={{ marginBottom: '0.4rem' }}>{ach}</li>
              ))}
            </ul>
          </section>
        )}

        {/* FESTIVAL PLANS */}
        {(dancer.festival_plans?.length ?? 0) > 0 && (
          <section className="dp-section">
            <h3 className="dp-section-title">
              <Ticket size={16} /> Festival plans
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {dancer.festival_plans!.map((plan, i) => (
                <div
                  key={i}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    background: '#111827',
                    padding: '0.5rem 0.8rem',
                    borderRadius: '0.5rem',
                    border: '1px solid rgba(255,255,255,0.1)'
                  }}
                >
                  <span style={{ fontWeight: 500 }}>{plan.name}</span>
                  <span
                    className="dp-pill"
                    style={{
                      borderColor: plan.status === 'going' ? '#22c55e' : 'rgba(212, 175, 55, 0.5)',
                      color: plan.status === 'going' ? '#22c55e' : 'inherit'
                    }}
                  >
                    {plan.status}
                  </span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* PARTNER */}
        {dancer.looking_for_partner && (
          <section className="dp-section">
            <button
              className="dp-partner-toggle"
              onClick={() => setShowPartnerDetails(!showPartnerDetails)}
            >
              Interested in dance practice
              <span>{showPartnerDetails ? '−' : '+'}</span>
            </button>

            {showPartnerDetails && (
              <div className="dp-partner-details">
                <div>
                  <small>Goals</small>
                  <div className="dp-partner-tags">
                    {goals.length
                      ? goals.map((g: string) => <span key={g}>{g}</span>)
                      : <span>Open</span>}
                  </div>
                </div>

                <div>
                  <small>Availability</small>
                  <div className="dp-partner-tags">
                    {availability.length
                      ? availability.map((a: string) => <span key={a}>{a}</span>)
                      : <span>Flexible</span>}
                  </div>
                </div>
              </div>
            )}
          </section>
        )}

        {/* SONGS (tiny) */}
        {(dancer.favorite_songs?.length ?? 0) > 0 && (
          <section className="dp-section">
            <h3 className="dp-section-title">
              <Music size={14} /> Top tracks
            </h3>
            <div className="dp-media-grid">
              {dancer.favorite_songs!.slice(0, 3).map((s, i) => (
                <a key={i} href={s} target="_blank" rel="noreferrer">
                  Track {i + 1}
                </a>
              ))}
            </div>
          </section>
        )}

        {/* FOOTER */}
        <footer className="dp-footer">
          <button onClick={handleShare} className="dp-share-btn">
            <Share2 size={16} /> Share profile
          </button>

          <div className="dp-contact-block">
            {dancer.instagram && (
              <div>
                Instagram: <a href={`https://instagram.com/${dancer.instagram.replace('@', '')}`} target="_blank">@{dancer.instagram.replace('@', '')}</a>
              </div>
            )}
            {dancer.facebook && (
              <div>
                Facebook: <a href={dancer.facebook} target="_blank">View</a>
              </div>
            )}
            {dancer.phone && (
              <div>
                Phone: <a href={`tel:${dancer.phone}`}>{dancer.phone}</a>
              </div>
            )}
          </div>
        </footer>

      </div>
    </Layout>
  );
};
