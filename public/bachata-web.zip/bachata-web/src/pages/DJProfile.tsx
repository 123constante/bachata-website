import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, Music, Instagram, Youtube, Mail, Phone, Play, Disc } from 'lucide-react';
import type { Database } from '../lib/database.types';

type DJRow = Database['public']['Tables']['dj_profiles']['Row'];

export const DJProfile = () => {
    const { id } = useParams<{ id: string }>();
    const [dj, setDj] = useState<DJRow | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (id) fetchDj();
    }, [id]);

    const fetchDj = async () => {
        const { data, error } = await supabase
            .from('dj_profiles')
            .select('*')
            .eq('id', id!)
            .single();

        if (!error) setDj(data);
        setLoading(false);
    };

    if (loading) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)]">
                <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            </div>
        </Layout>
    );

    if (!dj) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)] text-gray-400">
                DJ not found
            </div>
        </Layout>
    );

    return (
        <Layout>
            <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in">
                {/* Header */}
                <div className="flex flex-col md:flex-row gap-8 mb-12 items-center md:items-start">
                    <div className="w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden border-4 border-gray-800 shadow-2xl relative group">
                        {dj.photo_url ? (
                            <img src={dj.photo_url} alt={dj.dj_name} className="w-full h-full object-cover animate-spin-slow-hover" />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gray-800">
                                <Disc className="w-24 h-24 text-gray-600" />
                            </div>
                        )}
                        {/* Vinyl Shine Effect */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none rounded-full" />
                    </div>

                    <div className="flex-1 text-center md:text-left space-y-4">
                        <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">{dj.dj_name}</h1>
                        <div className="flex flex-wrap justify-center md:justify-start gap-2">
                            {dj.music_styles?.map((style, i) => (
                                <span key={i} className="px-3 py-1 bg-blue-500/10 text-blue-300 rounded-full border border-blue-500/20 text-sm">
                                    {style}
                                </span>
                            ))}
                        </div>

                        <div className="flex flex-wrap justify-center md:justify-start gap-6 pt-4">
                            {dj.instagram && (
                                <a href={dj.instagram} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-pink-500 transition-colors">
                                    <Instagram className="w-5 h-5" />
                                    Instagram
                                </a>
                            )}
                            {dj.mixcloud && (
                                <a href={dj.mixcloud} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-orange-500 transition-colors">
                                    <Music className="w-5 h-5" />
                                    Mixcloud
                                </a>
                            )}
                            {dj.youtube && (
                                <a href={dj.youtube} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-red-500 transition-colors">
                                    <Youtube className="w-5 h-5" />
                                    YouTube
                                </a>
                            )}
                        </div>

                        {/* Claim Button */}
                        {!dj.user_id && (
                            <div className="mt-6 md:mt-4">
                                <Link
                                    to={`/claim/dj/${dj.id}`}
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm font-medium"
                                >
                                    <Disc className="w-4 h-4" />
                                    Claim Profile
                                </Link>
                            </div>
                        )}
                    </div>
                </div>

                {/* About & Booking */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                    <div className="md:col-span-2 space-y-6">
                        <section className="bg-gray-900/50 rounded-2xl p-6 border border-gray-800">
                            <h2 className="text-xl font-bold text-white mb-4">About the Sound</h2>
                            <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">{dj.bio || 'No bio available.'}</p>
                        </section>

                        {/* Mixes */}
                        {dj.sample_mix_urls && dj.sample_mix_urls.length > 0 && (
                            <section>
                                <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                                    <Play className="w-5 h-5 text-blue-500" />
                                    Featured Mixes
                                </h2>
                                <div className="space-y-4">
                                    {dj.sample_mix_urls.map((url, i) => (
                                        <div key={i} className="bg-black/50 rounded-xl p-4 border border-gray-800 flex items-center justify-between group hover:border-blue-500/50 transition-colors cursor-pointer">
                                            <span className="text-gray-300 truncate flex-1">{url}</span>
                                            <a href={url} target="_blank" rel="noreferrer" className="p-2 bg-blue-500 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                                <Play className="w-4 h-4 fill-current" />
                                            </a>
                                        </div>
                                    ))}
                                </div>
                            </section>
                        )}
                    </div>

                    <div className="md:col-span-1">
                        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-gray-700 sticky top-24">
                            <h3 className="text-lg font-bold text-white mb-4">Booking Info</h3>
                            <div className="space-y-4">
                                {dj.booking_email && (
                                    <div className="flex items-center gap-3 text-gray-300">
                                        <div className="p-2 bg-gray-700 rounded-lg">
                                            <Mail className="w-4 h-4 text-blue-400" />
                                        </div>
                                        <a href={`mailto:${dj.booking_email}`} className="hover:text-white transition-colors text-sm break-all">
                                            {dj.booking_email}
                                        </a>
                                    </div>
                                )}
                                {dj.phone && (
                                    <div className="flex items-center gap-3 text-gray-300">
                                        <div className="p-2 bg-gray-700 rounded-lg">
                                            <Phone className="w-4 h-4 text-green-400" />
                                        </div>
                                        <span className="text-sm">{dj.phone}</span>
                                    </div>
                                )}

                                {dj.booking_email ? (
                                    <a
                                        href={`mailto:${dj.booking_email}`}
                                        className="block w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors mt-4 text-center"
                                    >
                                        Request Booking
                                    </a>
                                ) : (
                                    <button disabled className="w-full py-3 bg-gray-700 text-gray-400 rounded-xl font-medium mt-4 cursor-not-allowed">
                                        Booking Unavailable
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Gallery Section */}
                {dj.gallery_urls && dj.gallery_urls.length > 0 && (
                    <div className="mb-12 border-t border-gray-800 pt-8">
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <Disc className="w-6 h-6 text-blue-500" />
                            Gallery
                        </h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {dj.gallery_urls.map((url, i) => (
                                <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-800 transform hover:scale-105 transition-transform duration-300 cursor-pointer border border-gray-700">
                                    <img src={url} alt={`Gallery ${i}`} className="w-full h-full object-cover" />
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </Layout>
    );
};
