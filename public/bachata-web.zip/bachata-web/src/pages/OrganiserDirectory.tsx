import { useEffect, useState } from 'react';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, Building2, MapPin, Instagram, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Database } from '../lib/database.types';

type OrganiserRow = Database['public']['Tables']['organisers']['Row'];

export const OrganiserDirectory = () => {
    const [organisers, setOrganisers] = useState<OrganiserRow[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchOrganisers();
    }, []);

    const fetchOrganisers = async () => {
        const { data, error } = await supabase
            .from('organisers')
            .select('*')
            .order('name', { ascending: true });

        if (error) {
            console.error('Error fetching organisers:', error);
        } else {
            setOrganisers(data || []);
        }
        setLoading(false);
    };

    return (
        <Layout>
            <div className="container animate-fade-in" style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem' }}>
                <h1 style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span className="animate-scale-in">🏗️</span> Organiser Directory
                </h1>

                {loading ? (
                    <div style={{ textAlign: 'center', padding: '4rem' }}>
                        <Loader2 className="animate-spin" />
                    </div>
                ) : (
                    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
                        {organisers.map((org) => (
                            <Link to={`/organisers/${org.id}`} key={org.id} className="card hover-scale" style={{ background: '#1a1a1a', borderRadius: '12px', overflow: 'hidden', border: '1px solid #333', display: 'block', textDecoration: 'none' }}>
                                <div style={{ height: '200px', overflow: 'hidden', background: '#222', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    {org.photo_url ? (
                                        <img src={org.photo_url} alt={org.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                    ) : (
                                        <Building2 size={48} color="#444" />
                                    )}
                                </div>
                                <div style={{ padding: '1.5rem' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.5rem' }}>
                                        <h3 style={{ marginTop: 0, marginBottom: 0, fontSize: '1.1rem', lineHeight: '1.3', color: 'white' }}>{org.name}</h3>
                                        {org.category && (
                                            <span style={{
                                                background: '#333', color: '#ccc', fontSize: '0.7rem', padding: '2px 8px', borderRadius: '4px', whiteSpace: 'nowrap'
                                            }}>
                                                {org.category}
                                            </span>
                                        )}
                                    </div>

                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#888', marginBottom: '1rem', fontSize: '0.9rem' }}>
                                        <MapPin size={14} />
                                        <span>{org.city || 'Global'}</span>
                                    </div>

                                    <div style={{ display: 'flex', gap: '10px' }}>
                                        {org.instagram && (
                                            <div
                                                onClick={(e) => { e.preventDefault(); window.open(`https://instagram.com/${org.instagram!.replace('@', '')}`, '_blank'); }}
                                                style={{ color: '#ccc', cursor: 'pointer' }} className="hover-text-glow">
                                                <Instagram size={18} />
                                            </div>
                                        )}
                                        {org.website && (
                                            <div
                                                onClick={(e) => { e.preventDefault(); window.open(org.website!, '_blank'); }}
                                                style={{ color: '#ccc', cursor: 'pointer' }} className="hover-text-glow">
                                                <Globe size={18} />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </Link>
                        ))}
                        {organisers.length === 0 && (
                            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '4rem', color: '#666' }}>
                                <p>No organisers listed yet.</p>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </Layout>
    );
};
