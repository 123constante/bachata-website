import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, MapPin, Instagram, Globe, Image as ImageIcon, CheckCircle, GraduationCap, Disc, Building2 } from 'lucide-react';
import type { Database } from '../lib/database.types';



type TeacherRow = Database['public']['Tables']['teacher_profiles']['Row'];
interface ExtendedTeacherRow extends TeacherRow {
    years_teaching?: number;
    offers_private?: boolean;
    offers_group?: boolean;
    available_for_workshops?: boolean;
    travel_willingness?: string;
    email?: string;
    phone?: string;
    facebook?: string;
}

type OrganiserRow = Database['public']['Tables']['organisers']['Row'];
type DJRow = Database['public']['Tables']['dj_profiles']['Row'];

export const TeacherProfile = () => {
    const { id } = useParams<{ id: string }>();
    const [teacher, setTeacher] = useState<ExtendedTeacherRow | null>(null);
    const [organiserProfile, setOrganiserProfile] = useState<OrganiserRow | null>(null);
    const [djProfile, setDjProfile] = useState<DJRow | null>(null);
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        if (id) fetchProfile();
    }, [id]);

    const fetchProfile = async () => {
        try {
            // 1. Fetch Teacher Profile
            const { data: teacherData, error: teacherError } = await supabase
                .from('teacher_profiles')
                .select('*')
                .eq('id', id!)
                .single();

            if (teacherError) throw teacherError;
            const teacher = teacherData as ExtendedTeacherRow;
            setTeacher(teacher);

            // 2. Check for other roles if user_id exists
            if (teacher.user_id) {
                const [orgReq, djReq] = await Promise.all([
                    supabase.from('organisers').select('*').eq('user_id', teacher.user_id).single(),
                    supabase.from('dj_profiles').select('*').eq('user_id', teacher.user_id).single()
                ]) as any;

                if (orgReq.data) setOrganiserProfile(orgReq.data);
                if (djReq.data) setDjProfile(djReq.data);
            }
        } catch (error) {
            console.error('Error fetching profile:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)]">
                <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </div>
        </Layout>
    );

    if (!teacher) return (
        <Layout>
            <div className="flex justify-center items-center h-[calc(100vh-64px)] text-gray-400">
                Teacher not found
            </div>
        </Layout>
    );

    return (
        <Layout>
            <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in">
                {/* Header Section */}
                <div className="flex flex-col md:flex-row gap-8 mb-12">
                    <div className="w-full md:w-1/3">
                        <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-gray-800 shadow-xl border border-gray-700">
                            {teacher.photo_url ? (
                                <img src={teacher.photo_url} alt={teacher.full_name} className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                    <GraduationCap className="w-20 h-20 text-gray-600" />
                                </div>
                            )}
                        </div>

                        {/* Cross-Linking Buttons */}
                        <div className="mt-4 flex flex-col gap-2">
                            {organiserProfile && (
                                <Link to={`/organisers/${organiserProfile.id}`} className="flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-purple-400 rounded-lg transition-colors text-sm font-medium border border-gray-700">
                                    <Building2 className="w-4 h-4" />
                                    View Organiser Profile
                                </Link>
                            )}
                            {djProfile && (
                                <Link to={`/djs/${djProfile.id}`} className="flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-blue-400 rounded-lg transition-colors text-sm font-medium border border-gray-700">
                                    <Disc className="w-4 h-4" />
                                    View DJ Profile
                                </Link>
                            )}
                        </div>
                    </div>

                    <div className="w-full md:w-2/3 space-y-6">
                        <div>
                            <h1 className="text-4xl font-bold text-white mb-2">{teacher.full_name}</h1>
                            <div className="flex items-center text-gray-400 mb-4">
                                <MapPin className="w-5 h-5 mr-2 text-purple-500" />
                                {teacher.city || 'Global'}
                            </div>
                            <div className="flex flex-wrap gap-2 mb-6">
                                {teacher.teaching_styles?.map((style, i) => (
                                    <span key={i} className="px-3 py-1 bg-purple-500/10 text-purple-300 rounded-full border border-purple-500/20 text-sm">
                                        {style}
                                    </span>
                                ))}
                                {teacher.level && (
                                    <span className="px-3 py-1 bg-yellow-500/10 text-yellow-500 rounded-full border border-yellow-500/20 text-sm">
                                        {teacher.level}
                                    </span>
                                )}
                            </div>
                        </div>

                        {/* Bio & Journey */}
                        <div className="prose prose-invert max-w-none">
                            <h3 className="text-xl font-semibold text-white mb-2">About</h3>
                            <p className="text-gray-300 whitespace-pre-wrap">{teacher.bio || 'No bio available yet.'}</p>

                            {teacher.journey && (
                                <>
                                    <h3 className="text-xl font-semibold text-white mt-6 mb-2">Dance Journey</h3>
                                    <p className="text-gray-300 whitespace-pre-wrap">{teacher.journey}</p>
                                </>
                            )}
                        </div>

                        {/* Socials & Contact */}
                        <div className="flex flex-wrap gap-4 pt-6 border-t border-gray-800">
                            {teacher.instagram && (
                                <a href={teacher.instagram.startsWith('http') ? teacher.instagram : `https://instagram.com/${teacher.instagram.replace('@', '')}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-pink-500 transition-colors">
                                    <Instagram className="w-5 h-5" />
                                    Instagram
                                </a>
                            )}
                            {teacher.website && (
                                <a href={teacher.website} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-purple-500 transition-colors">
                                    <Globe className="w-5 h-5" />
                                    Website
                                </a>
                            )}
                            {teacher.email && (
                                <a href={`mailto:${teacher.email}`} className="flex items-center gap-2 text-gray-400 hover:text-blue-500 transition-colors">
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                                    Email
                                </a>
                            )}
                            {teacher.phone && (
                                <a href={`tel:${teacher.phone}`} className="flex items-center gap-2 text-gray-400 hover:text-green-500 transition-colors">
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                    Phone
                                </a>
                            )}
                            {teacher.facebook && (
                                <a href={teacher.facebook} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-gray-400 hover:text-blue-400 transition-colors">
                                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
                                    Facebook
                                </a>
                            )}
                        </div>

                        {/* Claim Profile box */}
                        {!teacher.user_id && (
                            <div className="mt-6 border border-gray-800 rounded-xl p-4 bg-gray-900/60 flex items-center justify-between">
                                <div>
                                    <h4 className="text-white font-medium text-sm">Is this you?</h4>
                                    <p className="text-gray-400 text-xs mt-1">Claim this profile to manage your info.</p>
                                </div>
                                <Link
                                    to={`/claim/teacher/${teacher.id}`}
                                    className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-sm font-medium transition-colors"
                                >
                                    Claim Profile
                                </Link>
                            </div>
                        )}


                        {/* Teaching Info */}
                        <div className="pt-6 border-t border-gray-800 space-y-4">
                            {teacher.years_teaching !== undefined && teacher.years_teaching > 0 && (
                                <div className="flex items-center gap-2 text-gray-300">
                                    <GraduationCap className="w-5 h-5 text-purple-500" />
                                    <span className="font-semibold">{teacher.years_teaching} years</span> teaching experience
                                </div>
                            )}

                            {(teacher.offers_private || teacher.offers_group || teacher.available_for_workshops) && (
                                <div>
                                    <h4 className="text-sm font-semibold text-gray-400 mb-2">Services Offered:</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {teacher.offers_private && (
                                            <span className="px-3 py-1 bg-green-500/10 text-green-400 rounded-full text-sm border border-green-500/20 flex items-center gap-1">
                                                <CheckCircle className="w-4 h-4" />
                                                Private Lessons
                                            </span>
                                        )}
                                        {teacher.offers_group && (
                                            <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm border border-blue-500/20 flex items-center gap-1">
                                                <CheckCircle className="w-4 h-4" />
                                                Group Classes
                                            </span>
                                        )}
                                        {teacher.available_for_workshops && (
                                            <span className="px-3 py-1 bg-purple-500/10 text-purple-400 rounded-full text-sm border border-purple-500/20 flex items-center gap-1">
                                                <CheckCircle className="w-4 h-4" />
                                                Workshops
                                            </span>
                                        )}
                                    </div>
                                </div>
                            )}

                            {teacher.travel_willingness && (
                                <div className="flex items-center gap-2 text-gray-300">
                                    <Globe className="w-5 h-5 text-blue-500" />
                                    <span className="text-sm">Travel: <span className="font-semibold">{teacher.travel_willingness}</span></span>
                                </div>
                            )}

                            {teacher.availability && (
                                <div className="flex items-center gap-2 text-gray-400">
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                    <span className="text-sm">{teacher.availability}</span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Promo Videos Section (Before FAQ) */}
                {teacher.promo_video_urls && teacher.promo_video_urls.length > 0 && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <Disc className="w-6 h-6 text-red-500" />
                            Promo Videos
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {teacher.promo_video_urls.map((url, i) => {
                                // Simple helper to get embed URL (extract ID)
                                let embedUrl = url;
                                if (url.includes('youtube.com') || url.includes('youtu.be')) {
                                    let vId = '';
                                    if (url.includes('v=')) vId = url.split('v=')[1]?.split('&')[0];
                                    else if (url.includes('youtu.be/')) vId = url.split('youtu.be/')[1]?.split('?')[0];
                                    if (vId) embedUrl = `https://www.youtube.com/embed/${vId}`;
                                }
                                return (
                                    <div key={i} className="aspect-video rounded-xl overflow-hidden bg-gray-900 shadow-lg border border-gray-800">
                                        <iframe
                                            src={embedUrl}
                                            title={`Promo Video ${i}`}
                                            className="w-full h-full"
                                            frameBorder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowFullScreen
                                        />
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* FAQ Section */}
                {teacher.faq && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white mb-6">Frequently Asked Questions</h2>
                        <div className="space-y-4">
                            {/* Assuming FAQ is stored as array of objects or simple text for now. Since schema is Json, let's treat it as potentially any */}
                            {Array.isArray(teacher.faq) ? teacher.faq.map((item: any, i: number) => (
                                <div key={i} className="bg-gray-900/50 rounded-xl p-6 border border-gray-800">
                                    <h4 className="font-semibold text-white mb-2">{item.question || 'Question'}</h4>
                                    <p className="text-gray-400">{item.answer || 'Answer'}</p>
                                </div>
                            )) : (
                                <p className="text-gray-400">{(teacher.faq as any).toString()}</p>
                            )}
                        </div>
                    </div>
                )}

                {/* Gallery Section */}
                {teacher.gallery_urls && teacher.gallery_urls.length > 0 && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <ImageIcon className="w-6 h-6 text-purple-500" />
                            Gallery
                        </h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {teacher.gallery_urls.map((url, i) => (
                                <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-800 transform hover:scale-105 transition-transform duration-300 cursor-pointer">
                                    <img src={url} alt={`Gallery ${i}`} className="w-full h-full object-cover" />
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </Layout>
    );
};
