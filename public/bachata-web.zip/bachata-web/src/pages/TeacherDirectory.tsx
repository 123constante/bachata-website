import { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { Loader2, MapPin, Instagram } from 'lucide-react';
import type { Database } from '../lib/database.types';
import { Link } from 'react-router-dom';

type TeacherRow = Database['public']['Tables']['teacher_profiles']['Row'];

const COUNTRIES = [
    { code: 'AF', name: 'Afghanistan' }, { code: 'AL', name: 'Albania' },
    { code: 'DZ', name: 'Algeria' }, { code: 'AD', name: 'Andorra' },
    { code: 'AO', name: 'Angola' }, { code: 'AR', name: 'Argentina' },
    { code: 'AM', name: 'Armenia' }, { code: 'AU', name: 'Australia' },
    { code: 'AT', name: 'Austria' }, { code: 'AZ', name: 'Azerbaijan' },
    { code: 'BS', name: 'Bahamas' }, { code: 'BH', name: 'Bahrain' },
    { code: 'BD', name: 'Bangladesh' }, { code: 'BB', name: 'Barbados' },
    { code: 'BY', name: 'Belarus' }, { code: 'BE', name: 'Belgium' },
    { code: 'BZ', name: 'Belize' }, { code: 'BJ', name: 'Benin' },
    { code: 'BO', name: 'Bolivia' }, { code: 'BA', name: 'Bosnia and Herzegovina' },
    { code: 'BW', name: 'Botswana' }, { code: 'BR', name: 'Brazil' },
    { code: 'BG', name: 'Bulgaria' }, { code: 'KH', name: 'Cambodia' },
    { code: 'CM', name: 'Cameroon' }, { code: 'CA', name: 'Canada' },
    { code: 'CL', name: 'Chile' }, { code: 'CN', name: 'China' },
    { code: 'CO', name: 'Colombia' }, { code: 'CR', name: 'Costa Rica' },
    { code: 'HR', name: 'Croatia' }, { code: 'CU', name: 'Cuba' },
    { code: 'CY', name: 'Cyprus' }, { code: 'CZ', name: 'Czech Republic' },
    { code: 'DK', name: 'Denmark' }, { code: 'DO', name: 'Dominican Republic' },
    { code: 'EC', name: 'Ecuador' }, { code: 'EG', name: 'Egypt' },
    { code: 'SV', name: 'El Salvador' }, { code: 'EE', name: 'Estonia' },
    { code: 'ET', name: 'Ethiopia' }, { code: 'FI', name: 'Finland' },
    { code: 'FR', name: 'France' }, { code: 'DE', name: 'Germany' },
    { code: 'GH', name: 'Ghana' }, { code: 'GR', name: 'Greece' },
    { code: 'GT', name: 'Guatemala' }, { code: 'HT', name: 'Haiti' },
    { code: 'HN', name: 'Honduras' }, { code: 'HU', name: 'Hungary' },
    { code: 'IS', name: 'Iceland' }, { code: 'IN', name: 'India' },
    { code: 'ID', name: 'Indonesia' }, { code: 'IR', name: 'Iran' },
    { code: 'IE', name: 'Ireland' }, { code: 'IL', name: 'Israel' },
    { code: 'IT', name: 'Italy' }, { code: 'JM', name: 'Jamaica' },
    { code: 'JP', name: 'Japan' }, { code: 'JO', name: 'Jordan' },
    { code: 'KZ', name: 'Kazakhstan' }, { code: 'KE', name: 'Kenya' },
    { code: 'KR', name: 'South Korea' }, { code: 'KW', name: 'Kuwait' },
    { code: 'LV', name: 'Latvia' }, { code: 'LB', name: 'Lebanon' },
    { code: 'LT', name: 'Lithuania' }, { code: 'LU', name: 'Luxembourg' },
    { code: 'MY', name: 'Malaysia' }, { code: 'MX', name: 'Mexico' },
    { code: 'MA', name: 'Morocco' }, { code: 'NL', name: 'Netherlands' },
    { code: 'NZ', name: 'New Zealand' }, { code: 'NI', name: 'Nicaragua' },
    { code: 'NG', name: 'Nigeria' }, { code: 'NO', name: 'Norway' },
    { code: 'PK', name: 'Pakistan' }, { code: 'PA', name: 'Panama' },
    { code: 'PY', name: 'Paraguay' }, { code: 'PE', name: 'Peru' },
    { code: 'PH', name: 'Philippines' }, { code: 'PL', name: 'Poland' },
    { code: 'PT', name: 'Portugal' }, { code: 'QA', name: 'Qatar' },
    { code: 'RO', name: 'Romania' }, { code: 'RU', name: 'Russia' },
    { code: 'SA', name: 'Saudi Arabia' }, { code: 'RS', name: 'Serbia' },
    { code: 'SG', name: 'Singapore' }, { code: 'SK', name: 'Slovakia' },
    { code: 'SI', name: 'Slovenia' }, { code: 'ZA', name: 'South Africa' },
    { code: 'ES', name: 'Spain' }, { code: 'LK', name: 'Sri Lanka' },
    { code: 'SE', name: 'Sweden' }, { code: 'CH', name: 'Switzerland' },
    { code: 'TW', name: 'Taiwan' }, { code: 'TH', name: 'Thailand' },
    { code: 'TN', name: 'Tunisia' }, { code: 'TR', name: 'Turkey' },
    { code: 'UA', name: 'Ukraine' }, { code: 'AE', name: 'United Arab Emirates' },
    { code: 'GB', name: 'United Kingdom' }, { code: 'US', name: 'United States' },
    { code: 'UY', name: 'Uruguay' }, { code: 'VE', name: 'Venezuela' },
    { code: 'VN', name: 'Vietnam' }
].sort((a, b) => a.name.localeCompare(b.name));

export const TeacherDirectory = () => {
    const [teachers, setTeachers] = useState<TeacherRow[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchTeachers();
    }, []);

    const fetchTeachers = async () => {
        const { data, error } = await supabase
            .from('teacher_profiles')
            .select('*')
            .order('full_name', { ascending: true });

        if (error) console.error('Error fetching teachers:', error);
        else setTeachers(data || []);

        setLoading(false);
    };

    return (
        <Layout>
            <div className="max-w-6xl mx-auto px-4 py-8 animate-fade-in">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                            Teachers Directory
                        </h1>
                        <p className="text-gray-400 mt-2">
                            Find the best instructors for your journey
                        </p>
                    </div>
                </div>

                {loading ? (
                    <div className="flex justify-center py-12">
                        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {teachers.map((teacher) => {
                            const countryCode = COUNTRIES.find(c => c.name === teacher.nationality)?.code;

                            return (
                                <Link
                                    key={teacher.id}
                                    to={`/teachers/${teacher.id}`}
                                    className="block group relative bg-gray-900/50 rounded-xl overflow-hidden border border-gray-800 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10"
                                >
                                    <div className="aspect-[4/3] relative overflow-hidden">
                                        <img
                                            src={teacher.photo_url || 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?w=800&q=80'}
                                            alt={teacher.full_name}
                                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                        />

                                        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/20 to-transparent" />

                                        <div className="absolute bottom-4 left-4 right-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <h3 className="text-xl font-bold text-white group-hover:text-purple-400 transition-colors">
                                                    {teacher.full_name}
                                                </h3>

                                                {countryCode && (
                                                    <img
                                                        src={`https://flagsapi.com/${countryCode}/flat/32.png`}
                                                        alt={teacher.nationality || 'Country'}
                                                        className="w-8 h-8 rounded-full bg-white/10"
                                                        title={teacher.nationality || undefined}
                                                    />
                                                )}
                                            </div>

                                            <div className="flex items-center text-sm text-gray-300 space-x-4">
                                                <div className="flex items-center">
                                                    <MapPin className="w-4 h-4 mr-1 text-purple-500" />
                                                    {teacher.city}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="px-4 py-3 border-t border-gray-800 flex justify-between items-center bg-gray-900/80 backdrop-blur-sm">
                                        <span className="text-sm text-purple-400 group-hover:underline font-medium">
                                            View Profile
                                        </span>

                                        {teacher.instagram && (
                                            <a
                                                href={teacher.instagram}
                                                target="_blank"
                                                rel="noreferrer"
                                                onClick={(e) => e.stopPropagation()}
                                                className="p-1.5 hover:bg-gray-800 rounded-full transition-colors text-gray-400 hover:text-pink-500"
                                            >
                                                <Instagram className="w-4 h-4" />
                                            </a>
                                        )}
                                    </div>
                                </Link>
                            );
                        })}
                    </div>
                )}
            </div>
        </Layout>
    );
};
