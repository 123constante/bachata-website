import { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { CalendarGrid } from '../components/CalendarGrid';
import { EventCard } from '../components/EventCard';
import { Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';
import { useNavigate } from 'react-router-dom';

// Derived types from Database definition
type EventRow = Database['public']['Tables']['events']['Row'];
type VenueRow = Database['public']['Tables']['venues']['Row'];

// Extended Event Interface with joined Venue
interface EventData extends EventRow {
    venues: VenueRow | null;
}

export const EventList = () => {
    const navigate = useNavigate();
    // Current viewed month
    const [viewDate, setViewDate] = useState(new Date());
    // Selected specific date
    const [selectedDate, setSelectedDate] = useState(new Date());

    const [filter, setFilter] = useState<'all' | 'classes' | 'socials'>('all');
    const [events, setEvents] = useState<EventData[]>([]);
    const [loading, setLoading] = useState(true);

    // Filter events for the list based on selected date
    const filteredEvents = events.filter(e => {
        // e.date is a string "YYYY-MM-DD"
        const eventDate = new Date(e.date);
        return eventDate.getDate() === selectedDate.getDate() &&
            eventDate.getMonth() === selectedDate.getMonth() &&
            eventDate.getFullYear() === selectedDate.getFullYear();
    });

    const [isModalOpen, setIsModalOpen] = useState(false);

    const onDateClick = (date: Date) => {
        setSelectedDate(date);
        setIsModalOpen(true);
    };

    useEffect(() => {
        fetchEvents();
    }, [filter]);

    const fetchEvents = async () => {
        setLoading(true);
        // Join with venues to get address/location info
        let query = supabase
            .from('events')
            .select(`
                *,
                venues (*)
            `)
            .order('date', { ascending: true });

        // Simple filter logic
        if (filter === 'classes') query = query.not('class_start', 'is', null);
        if (filter === 'socials') query = query.not('social_start', 'is', null);

        const { data, error } = await query;
        if (!error && data) {
            // calculated fields or type casting if needed
            setEvents(data as any as EventData[]);
        } else if (error) {
            console.error(error);
        }
        setLoading(false);
    };

    const handleSeedData = async () => {
        setLoading(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) {
                alert("Please log in to generate data!");
                setLoading(false);
                return;
            }

            // 1. Create a dummy venue
            const { data: venue, error: venueError } = await supabase.from('venues').insert({
                name: 'Salsa Temple',
                address: 'Victoria Embankment',
                city: 'London'
            }).select().single();

            if (venueError) throw venueError;

            // 2. Insert Events
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const dateStr = tomorrow.toISOString().split('T')[0];

            const { error: eventError } = await supabase.from('events').insert([
                {
                    name: 'Bachata Exchange Social',
                    description: 'The best Friday night social in London.',
                    date: dateStr,
                    class_start: '19:00:00',
                    class_end: '20:00:00',
                    social_start: '21:00:00',
                    social_end: '02:00:00',
                    venue_id: venue.id
                }
            ]);

            if (eventError) throw eventError;

            await fetchEvents();

        } catch (err: any) {
            alert("Error seeding data: " + err.message);
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    // Helper to format date
    const formatDate = (dateString: string) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
    };

    // Helper to format time strings (HH:MM:SS) -> HH:MM
    const formatTime = (timeStr?: string | null) => {
        if (!timeStr) return undefined;
        // Check if it's full ISO or just time
        if (timeStr.includes('T')) {
            return new Date(timeStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        return timeStr.slice(0, 5);
    };

    const formatTimeRange = (start?: string | null, end?: string | null) => {
        if (!start) return undefined;
        const s = formatTime(start);
        const e = formatTime(end);
        return e ? `${s} - ${e}` : s;
    };

    return (
        <Layout>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 'var(--spacing-md)' }}>
                {/* Tabs hidden for cleaner look as per request */}
            </div>

            <CalendarGrid
                currentDate={viewDate}
                onDateChange={setViewDate}
                selectedDate={selectedDate}
                onSelectDate={onDateClick}
                events={events.map(e => ({
                    ...e,
                    start_time: e.date + (e.class_start ? 'T' + e.class_start : 'T00:00:00') // Polyfill for CalendarGrid
                }))}
            />

            {/* Event Modal */}
            {isModalOpen && (
                <div className="modal-overlay animate-fade-in" style={{
                    position: 'fixed',
                    inset: 0,
                    backgroundColor: 'rgba(0,0,0,0.85)',
                    zIndex: 1000,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '1rem'
                }}
                    onClick={() => setIsModalOpen(false)}
                >
                    <div className="modal-content animate-scale-in" style={{
                        background: '#000000',
                        width: '100%',
                        maxWidth: '600px',
                        maxHeight: '90vh',
                        borderRadius: 'var(--radius-lg)',
                        padding: '2rem',
                        overflowY: 'auto',
                        position: 'relative',
                        border: '1px solid #333'
                    }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '2rem', borderBottom: '1px solid #333', paddingBottom: '1rem' }}>
                            <h3 style={{ margin: 0, color: 'var(--color-primary)', textTransform: 'uppercase', fontSize: '1.2rem' }}>
                                {selectedDate.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                            </h3>
                            <button
                                onClick={() => setIsModalOpen(false)}
                                style={{ background: 'transparent', border: 'none', color: 'var(--color-primary)', cursor: 'pointer', fontSize: '1.5rem', lineHeight: 1 }}
                            >
                                &times;
                            </button>
                        </div>

                        {filteredEvents.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--color-text-muted)' }}>
                                <p>No events found for this date.</p>
                                {events.length === 0 && (
                                    <button
                                        onClick={() => { handleSeedData(); setIsModalOpen(false); }}
                                        className="btn btn-primary"
                                        style={{ marginTop: '1rem' }}
                                    >
                                        Generate Sample Data
                                    </button>
                                )}
                            </div>
                        ) : (
                            <div className="grid">
                                {filteredEvents.map(event => (
                                    <EventCard
                                        key={event.id}
                                        dateDisplay={formatDate(event.date)}
                                        title={event.name}
                                        location={event.venues?.name || 'Unknown Venue'}
                                        address={event.venues?.city || ''}
                                        classTime={formatTimeRange(event.class_start, event.class_end)}
                                        socialTime={formatTimeRange(event.social_start, event.social_end)}
                                        onClick={() => navigate(`/event/${event.id}`)}
                                        imageUrl={event.cover_image_url || undefined}
                                    />
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {loading && (
                <div style={{ textAlign: 'center', padding: '4rem' }}>
                    <Loader2 className="animate-spin" size={32} />
                </div>
            )}
        </Layout>
    );
};
