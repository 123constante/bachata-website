import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Layout } from '../components/Layout';
import { supabase } from '../lib/supabase';
import { MapPin, Calendar, Clock, ArrowLeft, Loader2, User, CheckCircle, Star } from 'lucide-react';
import type { Database, EventSpecialGuestRow } from '../lib/database.types';
import './styles/event-detail.css';

type EventDetailData = Database['public']['Tables']['events']['Row'] & {
    venues: Database['public']['Tables']['venues']['Row'] | null;
    event_organisers: {
        organisers: Database['public']['Tables']['organisers']['Row'] | null;
    }[];
    event_teachers: {
        teacher_profiles: Database['public']['Tables']['teacher_profiles']['Row'] | null;
    }[];
    event_djs: {
        dj_profiles: Database['public']['Tables']['dj_profiles']['Row'] | null;
    }[];
};

export const EventDetail = () => {
    const { slug } = useParams(); // 'slug' param in router, but we treat as ID now
    const navigate = useNavigate();
    const [event, setEvent] = useState<EventDetailData | null>(null);
    const [loading, setLoading] = useState(true);
    const [attendanceStatus, setAttendanceStatus] = useState<'going' | 'interested' | null>(null);
    const [attendingLoading, setAttendingLoading] = useState(false);
    const [dancerId, setDancerId] = useState<string | null>(null);
    const [isAdmin, setIsAdmin] = useState(false);
    const [showAdminPanel, setShowAdminPanel] = useState(false);
    const [allTeachers, setAllTeachers] = useState<Database['public']['Tables']['teacher_profiles']['Row'][]>([]);
    const [allDJs, setAllDJs] = useState<Database['public']['Tables']['dj_profiles']['Row'][]>([]);
    const [specialGuests, setSpecialGuests] = useState<(EventSpecialGuestRow & { dancers?: Database['public']['Tables']['dancers']['Row'] | null })[]>([]);

    // Special guests admin state
    const [showGuestPanel, setShowGuestPanel] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Database['public']['Tables']['dancers']['Row'][]>([]);
    const [quickGuestForm, setQuickGuestForm] = useState({
        guest_name: '',
        guest_nationality: '',
        guest_photo_url: ''
    });
    const [uploadingGuest, setUploadingGuest] = useState(false);

    useEffect(() => {
        if (slug) fetchEvent(slug);
        checkAdminStatus();
    }, [slug]);

    const checkAdminStatus = async () => {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) return;

        // Check if admin
        const isAdminUser = session.user.email === 'rixz@ymail.com';

        // Check if has organiser profile
        const { data: organiser } = await supabase
            .from('organisers')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

        // Check if has teacher profile
        const { data: teacher } = await supabase
            .from('teacher_profiles')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

        // Set admin if any of these conditions are true
        if (isAdminUser || organiser || teacher) {
            setIsAdmin(true);
            // Fetch all teachers and DJs for admin dropdown
            const { data: teachers } = await supabase.from('teacher_profiles').select('*');
            const { data: djs } = await supabase.from('dj_profiles').select('*');
            if (teachers) setAllTeachers(teachers);
            if (djs) setAllDJs(djs);
        }
    };

    useEffect(() => {
        if (event) {
            checkAttendance();
        }
    }, [event]);

    const checkAttendance = async () => {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session || !event) return;

        // First, get the user's dancer profile
        const { data: dancer } = await supabase
            .from('dancers')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

        if (!dancer) {
            setDancerId(null);
            return;
        }

        setDancerId(dancer.id);

        // Check attendance using dancer_id
        const { data } = await supabase
            .from('event_attendees')
            .select('status')
            .eq('event_id', event.id)
            .eq('dancer_id', dancer.id)
            .single();

        if (data) {
            setAttendanceStatus(data.status);
        }
    };

    const [stats, setStats] = useState({ going: 0, interested: 0 });
    const [attendees, setAttendees] = useState<{
        going: any[],
        interested: any[]
    }>({ going: [], interested: [] });

    useEffect(() => {
        if (event) {
            fetchStats();
            fetchAttendees();
        }
    }, [event]);

    // Add Style for Hover
    useEffect(() => {
        const style = document.createElement('style');
        style.innerHTML = `
            .avatar-hover:hover { transform: scale(1.15); z-index: 10 !important; }
            .avatar-stack > div:first-child { margin-left: 0 !important; }
        `;
        document.head.appendChild(style);
        return () => { document.head.removeChild(style); }
    }, []);

    const fetchStats = async () => {
        if (!event) return;

        const { count: going } = await supabase
            .from('event_attendees')
            .select('*', { count: 'exact', head: true })
            .eq('event_id', event.id)
            .eq('status', 'going');

        const { count: interested } = await supabase
            .from('event_attendees')
            .select('*', { count: 'exact', head: true })
            .eq('event_id', event.id)
            .eq('status', 'interested');

        setStats({
            going: going || 0,
            interested: interested || 0
        });
    };


    const fetchAttendees = async () => {
        if (!event) return;

        // 1. Fetch Going (event_attendees -> dancers)
        const { data: goingData } = await supabase
            .from('event_attendees')
            .select(`
                dancer_id,
                dancers ( id, full_name, photo_url )
            `)
            .eq('event_id', event.id)
            .eq('status', 'going');

        // 2. Fetch Interested (event_attendees -> dancers)
        // Now that we unified the table, we can just query event_attendees with status='interested'
        const { data: interestedData } = await supabase
            .from('event_attendees')
            .select(`
                dancer_id,
                dancers ( id, full_name, photo_url )
            `)
            .eq('event_id', event.id)
            .eq('status', 'interested');

        setAttendees({
            going: goingData || [],
            interested: interestedData || []
        });
    };

    const handleAttendance = async (status: 'going' | 'interested') => {
        const { data: { session } } = await supabase.auth.getSession();

        // 1. Not Logged In Logic
        if (!session) {
            // Save intent and redirect
            localStorage.setItem("pending_attendance", JSON.stringify({
                eventId: event!.id,
                status
            }));

            navigate('/login');
            return;
        }

        // 2. Check Dancer Profile
        if (!dancerId) {
            alert("Please create a dancer profile first to RSVP!");
            navigate('/profile');
            return;
        }

        setAttendingLoading(true);

        try {
            // Toggle Logic
            if (attendanceStatus === status) {
                // If clicking same status -> Remove
                const { error } = await supabase
                    .from('event_attendees')
                    .delete()
                    .eq('event_id', event!.id)
                    .eq('dancer_id', dancerId);
                if (error) throw error;
                setAttendanceStatus(null);
            } else {
                // Upsert new status (Automatically overrides previous status since (event_id, dancer_id) is unique)
                const { error } = await supabase
                    .from('event_attendees')
                    .upsert({
                        event_id: event!.id,
                        dancer_id: dancerId,
                        status: status
                    });
                if (error) throw error;
                setAttendanceStatus(status);
            }
            fetchStats(); // Update counters
        } catch (err: any) {
            alert("Error: " + err.message);
        } finally {
            setAttendingLoading(false);
        }
    };

    const handleAddTeacher = async (teacherId: string) => {
        if (!event) return;
        try {
            const { error } = await supabase
                .from('event_teachers')
                .insert({ event_id: event.id, teacher_id: teacherId });
            if (error) throw error;
            // Refresh event data
            fetchEvent(event.id);
        } catch (err: any) {
            alert('Error adding teacher: ' + err.message);
        }
    };

    const handleRemoveTeacher = async (teacherId: string) => {
        if (!event) return;
        try {
            const { error } = await supabase
                .from('event_teachers')
                .delete()
                .eq('event_id', event.id)
                .eq('teacher_id', teacherId);
            if (error) throw error;
            fetchEvent(event.id);
        } catch (err: any) {
            alert('Error removing teacher: ' + err.message);
        }
    };

    const handleAddDJ = async (djId: string) => {
        if (!event) return;
        try {
            const { error } = await supabase
                .from('event_djs')
                .insert({ event_id: event.id, dj_id: djId });
            if (error) throw error;
            fetchEvent(event.id);
        } catch (err: any) {
            alert('Error adding DJ: ' + err.message);
        }
    };

    const handleRemoveDJ = async (djId: string) => {
        if (!event) return;
        try {
            const { error } = await supabase
                .from('event_djs')
                .delete()
                .eq('event_id', event.id)
                .eq('dj_id', djId);
            if (error) throw error;
            fetchEvent(event.id);
        } catch (err: any) {
            alert('Error removing DJ: ' + err.message);
        }
    };

    const fetchEvent = async (eventId: string) => {
        setLoading(true);

        // Fetch Event + Venue + Organisers + Teachers + DJs (via many-to-many)
        const { data, error } = await supabase
            .from('events')
            .select(`
                *,
                venues (*),
                event_organisers (
                   organisers (*)
                ),
                event_teachers (
                   teacher_profiles (*)
                ),
                event_djs (
                   dj_profiles (*)
                )
            `)
            .eq('id', eventId)
            .single();

        if (error) {
            console.error("Error fetching event:", error);
        }

        if (data) {
            setEvent(data as any as EventDetailData);
            // Fetch special guests separately with dancer join
            fetchSpecialGuests(eventId);
        }
        setLoading(false);
    };

    const fetchSpecialGuests = async (eventId: string) => {
        const { data, error } = await supabase
            .from('event_special_guests')
            .select(`
                *,
                dancers (*)
            `)
            .eq('event_id', eventId)
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching special guests:', error);
        } else if (data) {
            setSpecialGuests(data as any);
        }
    };

    // Search dancers for special guests
    const handleSearchDancers = async (query: string) => {
        setSearchQuery(query);
        if (!query.trim()) {
            setSearchResults([]);
            return;
        }

        const { data, error } = await supabase
            .from('dancers')
            .select('*')
            .or(`full_name.ilike.%${query}%,nationality.ilike.%${query}%`)
            .limit(10);

        if (!error && data) {
            setSearchResults(data);
        }
    };

    // Add dancer as special guest
    const handleAddDancerAsGuest = async (dancer: Database['public']['Tables']['dancers']['Row']) => {
        if (!event) return;
        try {
            const { error } = await supabase
                .from('event_special_guests')
                .insert({
                    event_id: event.id,
                    dancer_id: dancer.id,
                    guest_name: dancer.full_name,
                    guest_nationality: dancer.nationality,
                    guest_photo_url: dancer.photo_url
                });

            if (error) throw error;
            fetchSpecialGuests(event.id);
            setSearchQuery('');
            setSearchResults([]);
            alert('Special guest added! ✨');
        } catch (err: any) {
            alert('Error adding guest: ' + err.message);
        }
    };

    // Handle quick guest photo upload
    const handleQuickGuestPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const { data: { session } } = await supabase.auth.getSession();
        if (!e.target.files || e.target.files.length === 0 || !session) return;
        setUploadingGuest(true);
        try {
            const file = e.target.files[0];
            const fileExt = file.name.split('.').pop();
            const fileName = `guest-${Date.now()}.${fileExt}`;
            const filePath = `${fileName}`;

            const { error: uploadError } = await supabase.storage
                .from('avatars')
                .upload(filePath, file);

            if (uploadError) throw uploadError;

            const { data: { publicUrl } } = supabase.storage
                .from('avatars')
                .getPublicUrl(filePath);

            setQuickGuestForm(prev => ({ ...prev, guest_photo_url: publicUrl }));
        } catch (err: any) {
            alert('Error uploading photo: ' + err.message);
        } finally {
            setUploadingGuest(false);
        }
    };

    // Create quick guest
    const handleCreateQuickGuest = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!event || !quickGuestForm.guest_name) return;

        try {
            const { error } = await supabase
                .from('event_special_guests')
                .insert({
                    event_id: event.id,
                    dancer_id: null,
                    guest_name: quickGuestForm.guest_name,
                    guest_nationality: quickGuestForm.guest_nationality || null,
                    guest_photo_url: quickGuestForm.guest_photo_url || null
                });

            if (error) throw error;
            fetchSpecialGuests(event.id);
            setQuickGuestForm({ guest_name: '', guest_nationality: '', guest_photo_url: '' });
            alert('Quick guest added! ✨');
        } catch (err: any) {
            alert('Error creating guest: ' + err.message);
        }
    };

    // Remove special guest
    const handleRemoveGuest = async (guestId: string) => {
        if (!confirm('Remove this special guest?')) return;

        try {
            const { error } = await supabase
                .from('event_special_guests')
                .delete()
                .eq('id', guestId);

            if (error) throw error;
            setSpecialGuests(prev => prev.filter(g => g.id !== guestId));
            alert('Guest removed');
        } catch (err: any) {
            alert('Error removing guest: ' + err.message);
        }
    };


    if (loading) {
        return (
            <Layout>
                <div style={{ textAlign: 'center', padding: '4rem', color: 'white' }}>
                    <Loader2 className="animate-spin" />
                </div>
            </Layout>
        );
    }

    if (!event) {
        return (
            <Layout>
                <div style={{ textAlign: 'center', padding: '4rem', color: 'white' }}>
                    <h2>Event not found</h2>
                    <button onClick={() => navigate('/')} className="btn btn-primary" style={{ marginTop: '1rem' }}>Back to Calendar</button>
                </div>
            </Layout>
        );
    }

    // Helper to format Date/Time
    const dateObj = new Date(event.date);
    const dateStr = dateObj.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

    const hasClass = !!event.class_start;
    const hasSocial = !!event.social_start;

    const totalPeople = stats.going + stats.interested;

    return (
        <Layout>
            <div className="container animate-fade-in" style={{ maxWidth: '800px', margin: '0 auto' }}>
                <button
                    onClick={() => navigate('/')}
                    className="hover-scale clickable"
                    style={{
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--color-text-muted)',
                        display: 'flex', alignItems: 'center', gap: '8px',
                        marginBottom: '1rem',
                        padding: 0
                    }}
                >
                    <ArrowLeft size={16} /> Back
                </button>

                {/* Main Content Card */}
                <div style={{
                    background: 'var(--color-surface)',
                    borderRadius: 'var(--radius-lg)',
                    overflow: 'hidden',
                    border: '1px solid #333'
                }}>
                    {/* Cover Image */}
                    {event.cover_image_url && (
                        <div style={{ height: '300px', overflow: 'hidden' }}>
                            <img src={event.cover_image_url} alt={event.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        </div>
                    )}

                    <div style={{ padding: '2rem' }}>
                        <h1 style={{ marginBottom: '1rem', color: 'var(--color-primary)' }}>{event.name}</h1>

                        <div className="grid" style={{ gap: '1rem', marginBottom: '2rem' }}>
                            {/* Date */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#ccc' }}>
                                <Calendar size={20} style={{ color: 'var(--color-primary)' }} />
                                <span>{dateStr}</span>
                            </div>

                            {/* Time */}
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#ccc' }}>
                                <Clock size={20} style={{ color: 'var(--color-primary)' }} />
                                <div>
                                    {hasClass && <div>Class: {event.class_start?.slice(0, 5)} - {event.class_end?.slice(0, 5)}</div>}
                                    {hasSocial && <div>Social: {event.social_start?.slice(0, 5)} - {event.social_end?.slice(0, 5)}</div>}
                                </div>
                            </div>

                            {/* Location (Venue) */}
                            {event.venues && (
                                <a
                                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(event.venues.address + ', ' + event.venues.city)}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="hover-text-glow"
                                    style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#ccc', textDecoration: 'none' }}
                                >
                                    <MapPin size={20} style={{ color: 'var(--color-primary)' }} />
                                    <span>
                                        <strong>{event.venues.name}</strong> • {event.venues.address}, {event.venues.city}
                                    </span>
                                </a>
                            )}
                        </div>

                        {/* ATTENDANCE SECTION */}
                    </div>
                    <div style={{ padding: '0 2rem 2rem' }}>

                        {/* 2) NEW ATTENDANCE UI */}
                        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.2rem' }}>
                            {/* GOING BUTTON */}
                            <button
                                onClick={() => handleAttendance('going')}
                                disabled={attendingLoading}
                                className={`btn-attendance-going ${attendanceStatus === 'going' ? 'active' : ''}`}
                            >
                                <CheckCircle size={18} />
                                {attendanceStatus === 'going' ? 'Going' : "I'm Going"}
                            </button>

                            {/* INTERESTED BUTTON */}
                            <button
                                onClick={() => handleAttendance('interested')}
                                disabled={attendingLoading}
                                className={`btn-attendance-interested ${attendanceStatus === 'interested' ? 'active' : ''}`}
                            >
                                <Star size={18} fill={attendanceStatus === 'interested' ? "black" : "none"} />
                                Interested
                            </button>
                        </div>

                        {/* 3) COUNTER CARD */}
                        <div className="event-status-card">
                            <span className="esc-going">🔥 {stats.going} Going</span>
                            <span className="esc-divider"></span>
                            <span className="esc-interested">⭐ {stats.interested} Interested</span>
                        </div>

                        {/* 4) MINI AVATAR ROW */}
                        {(attendees.going.length > 0 || attendees.interested.length > 0) && (
                            <div className="mini-avatar-row">
                                {/* GOING AVATARS */}
                                {attendees.going.map((p) => (
                                    <div
                                        key={`going-${p.dancer_id}`}
                                        className="mini-avatar-item"
                                        onClick={() => navigate(`/dancers/${p.dancer_id}`)}
                                        title={p.dancers?.full_name || 'Dancer'}
                                    >
                                        {p.dancers?.photo_url ? (
                                            <img src={p.dancers.photo_url} alt="" className="mini-avatar-img going-border" />
                                        ) : (
                                            <div className="mini-avatar-fallback going-bg">
                                                {p.dancers?.full_name?.[0] || 'D'}
                                            </div>
                                        )}
                                    </div>
                                ))}

                                {/* INTERESTED AVATARS */}
                                {attendees.interested.map((p) => {
                                    // p might not have dancer info if we couldn't resolve it, but we filtered earlier
                                    if (!p.dancers) return null;
                                    return (
                                        <div
                                            key={`int-${p.user_id}`}
                                            className="mini-avatar-item"
                                            onClick={() => navigate(`/dancers/${p.dancers.id}`)}
                                            title={p.dancers?.full_name || 'User'}
                                        >
                                            {p.dancers?.photo_url ? (
                                                <img src={p.dancers.photo_url} alt="" className="mini-avatar-img interested-border" />
                                            ) : (
                                                <div className="mini-avatar-fallback interested-bg">
                                                    {p.dancers?.full_name?.[0] || 'U'}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>


                    {/* Special Guest Dancers */}
                    {specialGuests && specialGuests.length > 0 && (
                        <div style={{ marginBottom: '2rem', padding: '1.5rem', background: '#0a0a0a', borderRadius: '12px', border: '1px solid #222' }}>
                            <h3 style={{ marginTop: 0, marginBottom: '1.5rem', color: 'var(--color-primary)', fontSize: '1.3rem' }}>✨ Special Guest Dancers</h3>
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
                                gap: '1rem',
                                maxWidth: '100%'
                            }}>
                                {specialGuests.map((guest) => {
                                    const photoUrl = guest.guest_photo_url || guest.dancers?.photo_url;
                                    const guestName = guest.guest_name || guest.dancers?.full_name || 'Guest';
                                    const nationality = guest.guest_nationality || guest.dancers?.nationality;
                                    const isClickable = !!guest.dancer_id;

                                    const cardContent = (
                                        <>
                                            {/* Nationality flag in top corner */}
                                            {nationality && (
                                                <div style={{
                                                    position: 'absolute',
                                                    top: '8px',
                                                    right: '8px',
                                                    width: '20px',
                                                    height: '15px',
                                                    borderRadius: '2px',
                                                    overflow: 'hidden',
                                                    boxShadow: '0 1px 3px rgba(0,0,0,0.5)'
                                                }}>
                                                    <img
                                                        src={`https://flagcdn.com/w40/${nationality.toLowerCase().slice(0, 2)}.png`}
                                                        alt={nationality}
                                                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                        onError={(e) => {
                                                            e.currentTarget.style.display = 'none';
                                                        }}
                                                    />
                                                </div>
                                            )}

                                            {/* Photo */}
                                            <div style={{
                                                width: '80px',
                                                height: '80px',
                                                borderRadius: '50%',
                                                overflow: 'hidden',
                                                margin: '0 auto 0.75rem',
                                                border: '2px solid var(--color-primary)',
                                                background: '#222'
                                            }}>
                                                {photoUrl ? (
                                                    <img
                                                        src={photoUrl}
                                                        alt={guestName}
                                                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                    />
                                                ) : (
                                                    <div style={{
                                                        width: '100%',
                                                        height: '100%',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center'
                                                    }}>
                                                        <User size={32} color="#666" />
                                                    </div>
                                                )}
                                            </div>

                                            {/* Name */}
                                            <div style={{
                                                fontSize: '0.9rem',
                                                fontWeight: 600,
                                                color: 'white',
                                                textAlign: 'center',
                                                lineHeight: '1.3',
                                                wordBreak: 'break-word'
                                            }}>
                                                {guestName}
                                            </div>
                                        </>
                                    );

                                    return isClickable ? (
                                        <div
                                            key={guest.id}
                                            onClick={() => navigate(`/dancers/${guest.dancer_id}`)}
                                            className="hover-scale animate-fade-in"
                                            style={{
                                                position: 'relative',
                                                background: '#000',
                                                border: '1px solid #fff',
                                                borderRadius: '12px',
                                                padding: '1rem 0.75rem',
                                                cursor: 'pointer',
                                                transition: 'all 0.3s ease'
                                            }}
                                        >
                                            {cardContent}
                                        </div>
                                    ) : (
                                        <div
                                            key={guest.id}
                                            className="animate-fade-in"
                                            style={{
                                                position: 'relative',
                                                background: '#000',
                                                border: '1px solid #fff',
                                                borderRadius: '12px',
                                                padding: '1rem 0.75rem'
                                            }}
                                        >
                                            {cardContent}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    {/* Organisers */}
                    {event.event_organisers && event.event_organisers.length > 0 && (
                        <div style={{ marginBottom: '2rem', padding: '1rem', background: '#111', borderRadius: '8px' }}>
                            <h4 style={{ marginTop: 0, marginBottom: '0.5rem', color: '#888' }}>Organised by</h4>
                            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                                {event.event_organisers.map(({ organisers: org }) => (
                                    org && (
                                        <div key={org.id} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                            {org.photo_url && <img src={org.photo_url} alt={org.name} style={{ width: '30px', height: '30px', borderRadius: '50%' }} />}
                                            <span style={{ fontWeight: 600 }}>{org.name}</span>
                                        </div>
                                    )
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Teachers */}
                    {event.event_teachers && event.event_teachers.length > 0 && (
                        <div style={{ marginBottom: '2rem', padding: '1rem', background: '#111', borderRadius: '8px' }}>
                            <h4 style={{ marginTop: 0, marginBottom: '0.5rem', color: '#888' }}>Teachers</h4>
                            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                                {event.event_teachers.map(({ teacher_profiles: teacher }) => (
                                    teacher && (
                                        <div key={teacher.id} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                            {teacher.photo_url && <img src={teacher.photo_url} alt={teacher.full_name} style={{ width: '30px', height: '30px', borderRadius: '50%', objectFit: 'cover' }} />}
                                            <span style={{ fontWeight: 600 }}>{teacher.full_name}</span>
                                        </div>
                                    )
                                ))}
                            </div>
                        </div>
                    )}

                    {/* DJs */}
                    {event.event_djs && event.event_djs.length > 0 && (
                        <div style={{ marginBottom: '2rem', padding: '1rem', background: '#111', borderRadius: '8px' }}>
                            <h4 style={{ marginTop: 0, marginBottom: '0.5rem', color: '#888' }}>DJs</h4>
                            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                                {event.event_djs.map(({ dj_profiles: dj }) => (
                                    dj && (
                                        <div key={dj.id} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                            {dj.photo_url && <img src={dj.photo_url} alt={dj.dj_name} style={{ width: '30px', height: '30px', borderRadius: '50%', objectFit: 'cover' }} />}
                                            <span style={{ fontWeight: 600 }}>{dj.dj_name}</span>
                                        </div>
                                    )
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Admin Panel */}
                    {isAdmin && (
                        <div style={{ marginTop: '2rem', padding: '1.5rem', background: '#1a0a0a', border: '1px solid #ff6b6b', borderRadius: '8px' }}>
                            <div
                                onClick={() => setShowAdminPanel(!showAdminPanel)}
                                style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: showAdminPanel ? '1rem' : 0 }}
                            >
                                <h4 style={{ margin: 0, color: '#ff6b6b' }}>🛡️ Admin Controls</h4>
                                <span style={{ color: '#ff6b6b' }}>{showAdminPanel ? '▼' : '▶'}</span>
                            </div>

                            {showAdminPanel && (
                                <div style={{ marginTop: '1rem' }}>
                                    {/* Manage Teachers */}
                                    <div style={{ marginBottom: '1.5rem' }}>
                                        <h5 style={{ color: '#ccc', marginBottom: '0.5rem' }}>Manage Teachers</h5>
                                        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                                            {event.event_teachers.map(({ teacher_profiles: teacher }) => (
                                                teacher && (
                                                    <button
                                                        key={teacher.id}
                                                        onClick={() => handleRemoveTeacher(teacher.id)}
                                                        style={{
                                                            padding: '0.4rem 0.8rem',
                                                            background: '#333',
                                                            border: '1px solid #555',
                                                            borderRadius: '6px',
                                                            color: 'white',
                                                            cursor: 'pointer',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '6px'
                                                        }}
                                                    >
                                                        {teacher.full_name} <span style={{ color: '#ff6b6b' }}>✕</span>
                                                    </button>
                                                )
                                            ))}
                                        </div>
                                        <select
                                            onChange={(e) => e.target.value && handleAddTeacher(e.target.value)}
                                            value=""
                                            style={{
                                                padding: '0.5rem',
                                                background: '#222',
                                                border: '1px solid #444',
                                                borderRadius: '6px',
                                                color: 'white',
                                                width: '100%'
                                            }}
                                        >
                                            <option value="">+ Add Teacher</option>
                                            {allTeachers
                                                .filter(t => !event.event_teachers.some(et => et.teacher_profiles?.id === t.id))
                                                .map(teacher => (
                                                    <option key={teacher.id} value={teacher.id}>
                                                        {teacher.full_name}
                                                    </option>
                                                ))}
                                        </select>
                                    </div>

                                    {/* Manage DJs */}
                                    <div>
                                        <h5 style={{ color: '#ccc', marginBottom: '0.5rem' }}>Manage DJs</h5>
                                        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                                            {event.event_djs.map(({ dj_profiles: dj }) => (
                                                dj && (
                                                    <button
                                                        key={dj.id}
                                                        onClick={() => handleRemoveDJ(dj.id)}
                                                        style={{
                                                            padding: '0.4rem 0.8rem',
                                                            background: '#333',
                                                            border: '1px solid #555',
                                                            borderRadius: '6px',
                                                            color: 'white',
                                                            cursor: 'pointer',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '6px'
                                                        }}
                                                    >
                                                        {dj.dj_name} <span style={{ color: '#ff6b6b' }}>✕</span>
                                                    </button>
                                                )
                                            ))}
                                        </div>
                                        <select
                                            onChange={(e) => e.target.value && handleAddDJ(e.target.value)}
                                            value=""
                                            style={{
                                                padding: '0.5rem',
                                                background: '#222',
                                                border: '1px solid #444',
                                                borderRadius: '6px',
                                                color: 'white',
                                                width: '100%'
                                            }}
                                        >
                                            <option value="">+ Add DJ</option>
                                            {allDJs
                                                .filter(d => !event.event_djs.some(ed => ed.dj_profiles?.id === d.id))
                                                .map(dj => (
                                                    <option key={dj.id} value={dj.id}>
                                                        {dj.dj_name}
                                                    </option>
                                                ))}
                                        </select>
                                    </div>

                                    {/* Manage Special Guests */}
                                    <div style={{ marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid #444' }}>
                                        <h5 style={{ color: '#ccc', marginBottom: '1rem' }}>Manage Special Guest Dancers</h5>

                                        {/* Search Dancers */}
                                        <div style={{ marginBottom: '1rem' }}>
                                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem', color: '#aaa' }}>
                                                Add from existing dancer profile
                                            </label>
                                            <input
                                                type="text"
                                                value={searchQuery}
                                                onChange={(e) => handleSearchDancers(e.target.value)}
                                                placeholder="Search dancer by name or nationality"
                                                style={{
                                                    width: '100%',
                                                    padding: '0.5rem',
                                                    background: '#222',
                                                    border: '1px solid #444',
                                                    borderRadius: '6px',
                                                    color: 'white'
                                                }}
                                            />

                                            {/* Search Results */}
                                            {searchResults.length > 0 && (
                                                <div style={{
                                                    marginTop: '0.5rem',
                                                    background: '#1a1a1a',
                                                    border: '1px solid #444',
                                                    borderRadius: '6px',
                                                    maxHeight: '200px',
                                                    overflowY: 'auto'
                                                }}>
                                                    {searchResults.map(dancer => (
                                                        <div
                                                            key={dancer.id}
                                                            style={{
                                                                padding: '0.75rem',
                                                                borderBottom: '1px solid #333',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'space-between',
                                                                gap: '1rem'
                                                            }}
                                                        >
                                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                                                {dancer.photo_url && (
                                                                    <img
                                                                        src={dancer.photo_url}
                                                                        alt={dancer.full_name}
                                                                        style={{
                                                                            width: '32px',
                                                                            height: '32px',
                                                                            borderRadius: '50%',
                                                                            objectFit: 'cover'
                                                                        }}
                                                                    />
                                                                )}
                                                                <div>
                                                                    <div style={{ fontWeight: 600 }}>{dancer.full_name}</div>
                                                                    <div style={{ fontSize: '0.8rem', color: '#888' }}>
                                                                        {dancer.nationality}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <button
                                                                onClick={() => handleAddDancerAsGuest(dancer)}
                                                                style={{
                                                                    padding: '0.4rem 0.8rem',
                                                                    background: '#4ade80',
                                                                    border: 'none',
                                                                    borderRadius: '4px',
                                                                    color: '#000',
                                                                    cursor: 'pointer',
                                                                    fontSize: '0.85rem',
                                                                    fontWeight: 600
                                                                }}
                                                            >
                                                                Add as Guest
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>

                                        {/* Quick Guest Form */}
                                        <div style={{ marginBottom: '1rem', padding: '1rem', background: '#1a1a1a', borderRadius: '6px', border: '1px solid #444' }}>
                                            <h6 style={{ margin: '0 0 0.75rem 0', color: '#ccc', fontSize: '0.9rem' }}>Quick Guest (no profile)</h6>
                                            <form onSubmit={handleCreateQuickGuest}>
                                                <input
                                                    type="text"
                                                    value={quickGuestForm.guest_name}
                                                    onChange={(e) => setQuickGuestForm(prev => ({ ...prev, guest_name: e.target.value }))}
                                                    placeholder="Guest name *"
                                                    required
                                                    style={{
                                                        width: '100%',
                                                        padding: '0.5rem',
                                                        background: '#222',
                                                        border: '1px solid #444',
                                                        borderRadius: '6px',
                                                        color: 'white',
                                                        marginBottom: '0.5rem'
                                                    }}
                                                />
                                                <input
                                                    type="text"
                                                    value={quickGuestForm.guest_nationality}
                                                    onChange={(e) => setQuickGuestForm(prev => ({ ...prev, guest_nationality: e.target.value }))}
                                                    placeholder="Nationality (optional)"
                                                    style={{
                                                        width: '100%',
                                                        padding: '0.5rem',
                                                        background: '#222',
                                                        border: '1px solid #444',
                                                        borderRadius: '6px',
                                                        color: 'white',
                                                        marginBottom: '0.5rem'
                                                    }}
                                                />
                                                <div style={{ marginBottom: '0.5rem' }}>
                                                    <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.85rem', color: '#aaa' }}>
                                                        Photo (optional)
                                                    </label>
                                                    <input
                                                        type="file"
                                                        accept="image/*"
                                                        onChange={handleQuickGuestPhotoUpload}
                                                        style={{
                                                            width: '100%',
                                                            padding: '0.5rem',
                                                            background: '#222',
                                                            border: '1px solid #444',
                                                            borderRadius: '6px',
                                                            color: 'white'
                                                        }}
                                                    />
                                                    {uploadingGuest && <div style={{ fontSize: '0.8rem', color: '#888', marginTop: '0.25rem' }}>Uploading...</div>}
                                                </div>
                                                <button
                                                    type="submit"
                                                    style={{
                                                        width: '100%',
                                                        padding: '0.5rem',
                                                        background: '#3b82f6',
                                                        border: 'none',
                                                        borderRadius: '6px',
                                                        color: 'white',
                                                        cursor: 'pointer',
                                                        fontWeight: 600
                                                    }}
                                                >
                                                    Create Quick Guest
                                                </button>
                                            </form>
                                        </div>

                                        {/* Current Guests List */}
                                        {specialGuests.length > 0 && (
                                            <div>
                                                <h6 style={{ margin: '0 0 0.5rem 0', color: '#ccc', fontSize: '0.9rem' }}>
                                                    Current Special Guests ({specialGuests.length})
                                                </h6>
                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                                    {specialGuests.map(guest => (
                                                        <div
                                                            key={guest.id}
                                                            style={{
                                                                padding: '0.75rem',
                                                                background: '#1a1a1a',
                                                                border: '1px solid #333',
                                                                borderRadius: '6px',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'space-between',
                                                                gap: '1rem'
                                                            }}
                                                        >
                                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                                                {(guest.guest_photo_url || guest.dancers?.photo_url) && (
                                                                    <img
                                                                        src={guest.guest_photo_url || guest.dancers?.photo_url || ''}
                                                                        alt={guest.guest_name}
                                                                        style={{
                                                                            width: '32px',
                                                                            height: '32px',
                                                                            borderRadius: '50%',
                                                                            objectFit: 'cover'
                                                                        }}
                                                                    />
                                                                )}
                                                                <div>
                                                                    <div style={{ fontWeight: 600 }}>{guest.guest_name}</div>
                                                                    <div style={{ fontSize: '0.8rem', color: '#888' }}>
                                                                        {guest.guest_nationality || guest.dancers?.nationality || 'No nationality'}
                                                                        {guest.dancer_id && ' • Linked to profile'}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <button
                                                                onClick={() => handleRemoveGuest(guest.id)}
                                                                style={{
                                                                    padding: '0.4rem 0.8rem',
                                                                    background: 'transparent',
                                                                    border: '1px solid #ff6b6b',
                                                                    borderRadius: '4px',
                                                                    color: '#ff6b6b',
                                                                    cursor: 'pointer',
                                                                    fontSize: '0.85rem'
                                                                }}
                                                            >
                                                                Remove
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                </div>
            </div>
        </Layout >
    );
};
