export type Json =
    | string
    | number
    | boolean
    | null
    | { [key: string]: Json | undefined }
    | Json[]

export interface Database {
    public: {
        Tables: {
            venues: {
                Row: {
                    id: string
                    name: string
                    photo_url: string | null
                    address: string
                    google_maps_url: string | null
                    capacity: number | null
                    city: string | null
                    contact: string | null
                    rules: string | null
                    parking: string | null
                    closest_transport: string | null
                    gallery_urls: string[] | null
                    opening_hours: string | null
                    created_at: string
                }
                Insert: {
                    id?: string
                    name: string
                    photo_url?: string | null
                    address: string
                    google_maps_url?: string | null
                    capacity?: number | null
                    city?: string | null
                    contact?: string | null
                    rules?: string | null
                    parking?: string | null
                    closest_transport?: string | null
                    gallery_urls?: string[] | null
                    opening_hours?: string | null
                    created_at?: string
                }
                Update: {
                    id?: string
                    name?: string
                    photo_url?: string | null
                    address?: string
                    google_maps_url?: string | null
                    capacity?: number | null
                    city?: string | null
                    contact?: string | null
                    rules?: string | null
                    parking?: string | null
                    closest_transport?: string | null
                    gallery_urls?: string[] | null
                    opening_hours?: string | null
                    created_at?: string
                }
            }
            events: {
                Row: {
                    id: string
                    name: string
                    description: string | null
                    date: string
                    class_start: string | null
                    class_end: string | null
                    social_start: string | null
                    social_end: string | null
                    venue_id: string | null
                    cover_image_url: string | null
                    is_published: boolean
                    created_at: string
                }
                Insert: {
                    id?: string
                    name: string
                    description?: string | null
                    date: string
                    class_start?: string | null
                    class_end?: string | null
                    social_start?: string | null
                    social_end?: string | null
                    venue_id?: string | null
                    cover_image_url?: string | null
                    is_published?: boolean
                    created_at?: string
                }
                Update: {
                    id?: string
                    name?: string
                    description?: string | null
                    date?: string
                    class_start?: string | null
                    class_end?: string | null
                    social_start?: string | null
                    social_end?: string | null
                    venue_id?: string | null
                    cover_image_url?: string | null
                    is_published?: boolean
                    created_at?: string
                }
            }
            organisers: {
                Row: {
                    id: string
                    user_id: string | null
                    name: string
                    photo_url: string | null
                    bio: string | null
                    category: string | null
                    email: string | null
                    phone: string | null
                    city: string | null
                    instagram: string | null
                    website: string | null
                    teaching_styles: string[] | null
                    verified: boolean
                    gallery_urls: string[] | null
                    promo_video_urls: string[] | null
                    created_at: string
                }
                Insert: {
                    id?: string
                    user_id?: string | null
                    name: string
                    photo_url?: string | null
                    bio?: string | null
                    category?: string | null
                    email?: string | null
                    phone?: string | null
                    city?: string | null
                    instagram?: string | null
                    website?: string | null
                    teaching_styles?: string[] | null
                    verified?: boolean
                    gallery_urls?: string[] | null
                    promo_video_urls?: string[] | null
                    created_at?: string
                }
                Update: {
                    id?: string
                    user_id?: string | null
                    name?: string
                    photo_url?: string | null
                    bio?: string | null
                    category?: string | null
                    email?: string | null
                    phone?: string | null
                    city?: string | null
                    instagram?: string | null
                    website?: string | null
                    teaching_styles?: string[] | null
                    verified?: boolean
                    gallery_urls?: string[] | null
                    promo_video_urls?: string[] | null
                    created_at?: string
                }
            }
            dancers: {
                Row: {
                    id: string
                    user_id: string | null
                    full_name: string
                    photo_url: string | null
                    city: string | null
                    nationality: string | null
                    years_dancing: number | null
                    favorite_styles: string[] | null
                    favorite_songs: string[] | null
                    achievements: string[] | null
                    festival_plans: { name: string; status: 'thinking' | 'going' }[] | null
                    partner_role: string | null
                    partner_details: Json | null
                    instagram: string | null
                    facebook: string | null
                    phone: string | null
                    looking_for_partner: boolean
                    created_at: string
                }
                Insert: {
                    id?: string
                    user_id?: string | null
                    full_name: string
                    photo_url?: string | null
                    city?: string | null
                    nationality?: string | null
                    years_dancing?: number | null
                    favorite_styles?: string[] | null
                    favorite_songs?: string[] | null
                    achievements?: string[] | null
                    festival_plans?: { name: string; status: 'thinking' | 'going' }[] | null
                    partner_role?: string | null
                    partner_details?: Json | null
                    instagram?: string | null
                    facebook?: string | null
                    phone?: string | null
                    looking_for_partner?: boolean
                    created_at?: string
                }
                Update: {
                    id?: string
                    user_id?: string | null
                    full_name?: string
                    photo_url?: string | null
                    city?: string | null
                    nationality?: string | null
                    years_dancing?: number | null
                    favorite_styles?: string[] | null
                    favorite_songs?: string[] | null
                    achievements?: string[] | null
                    partner_role?: string | null
                    partner_details?: Json | null
                    instagram?: string | null
                    facebook?: string | null
                    phone?: string | null
                    looking_for_partner?: boolean
                    created_at?: string
                }
            }
            event_organisers: {
                Row: {
                    event_id: string
                    organiser_id: string
                }
                Insert: {
                    event_id: string
                    organiser_id: string
                }
                Update: {
                    event_id?: string
                    organiser_id?: string
                }
            }
            event_attendees: {
                Row: {
                    event_id: string
                    dancer_id: string
                    status: 'going' | 'interested' | null
                }
                Insert: {
                    event_id: string
                    dancer_id: string
                    status?: 'going' | 'interested' | null
                }
                Update: {
                    event_id?: string
                    dancer_id?: string
                    status?: 'going' | 'interested' | null
                }
            }
            event_special_guests: {
                Row: {
                    id: string
                    event_id: string
                    dancer_id: string | null
                    guest_name: string
                    guest_nationality: string | null
                    guest_photo_url: string | null
                    is_highlighted: boolean
                    created_at: string
                }
                Insert: {
                    id?: string
                    event_id: string
                    dancer_id?: string | null
                    guest_name: string
                    guest_nationality?: string | null
                    guest_photo_url?: string | null
                    is_highlighted?: boolean
                    created_at?: string
                }
                Update: {
                    id?: string
                    event_id?: string
                    dancer_id?: string | null
                    guest_name?: string
                    guest_nationality?: string | null
                    guest_photo_url?: string | null
                    is_highlighted?: boolean
                    created_at?: string
                }
            }
            event_teachers: {
                Row: {
                    event_id: string
                    teacher_id: string
                    created_at: string
                }
                Insert: {
                    event_id: string
                    teacher_id: string
                    created_at?: string
                }
                Update: {
                    event_id?: string
                    teacher_id?: string
                    created_at?: string
                }
            }
            event_djs: {
                Row: {
                    event_id: string
                    dj_id: string
                    created_at: string
                }
                Insert: {
                    event_id: string
                    dj_id: string
                    created_at?: string
                }
                Update: {
                    event_id?: string
                    dj_id?: string
                    created_at?: string
                }
            }
            teacher_profiles: {
                Row: {
                    id: string
                    user_id: string | null
                    full_name: string
                    photo_url: string | null
                    city: string | null
                    teaching_styles: string[] | null
                    level: string | null
                    bio: string | null
                    journey: string | null
                    faq: Json | null
                    services_offered: string[] | null
                    availability: string | null
                    gallery_urls: string[] | null
                    promo_video_urls: string[] | null
                    instagram: string | null
                    website: string | null
                    nationality: string | null
                    created_at: string
                }
                Insert: {
                    id?: string
                    user_id?: string | null
                    full_name: string
                    photo_url?: string | null
                    city?: string | null
                    teaching_styles?: string[] | null
                    level?: string | null
                    bio?: string | null
                    journey?: string | null
                    faq?: Json | null
                    services_offered?: string[] | null
                    availability?: string | null
                    gallery_urls?: string[] | null
                    promo_video_urls?: string[] | null
                    instagram?: string | null
                    website?: string | null
                    nationality?: string | null
                    created_at?: string
                }
                Update: {
                    id?: string
                    user_id?: string | null
                    full_name?: string
                    photo_url?: string | null
                    city?: string | null
                    teaching_styles?: string[] | null
                    level?: string | null
                    bio?: string | null
                    journey?: string | null
                    faq?: Json | null
                    services_offered?: string[] | null
                    availability?: string | null
                    gallery_urls?: string[] | null
                    promo_video_urls?: string[] | null
                    instagram?: string | null
                    website?: string | null
                    nationality?: string | null
                    created_at?: string
                }
            }
            dj_profiles: {
                Row: {
                    id: string
                    user_id: string | null
                    dj_name: string
                    photo_url: string | null
                    music_styles: string[] | null
                    bio: string | null
                    instagram: string | null
                    mixcloud: string | null
                    youtube: string | null
                    sample_mix_urls: string[] | null
                    booking_email: string | null
                    phone: string | null
                    gallery_urls: string[] | null
                    nationality: string | null
                    created_at: string
                }
                Insert: {
                    id?: string
                    user_id?: string | null
                    dj_name: string
                    photo_url?: string | null
                    music_styles?: string[] | null
                    bio?: string | null
                    instagram?: string | null
                    mixcloud?: string | null
                    youtube?: string | null
                    sample_mix_urls?: string[] | null
                    booking_email?: string | null
                    phone?: string | null
                    gallery_urls?: string[] | null
                    nationality?: string | null
                    created_at?: string
                }
                Update: {
                    id?: string
                    user_id?: string | null
                    dj_name?: string
                    photo_url?: string | null
                    music_styles?: string[] | null
                    bio?: string | null
                    instagram?: string | null
                    mixcloud?: string | null
                    youtube?: string | null
                    sample_mix_urls?: string[] | null
                    booking_email?: string | null
                    phone?: string | null
                    gallery_urls?: string[] | null
                    nationality?: string | null
                    created_at?: string
                }
            }
            profiles: {
                Row: {
                    id: string
                    updated_at: string | null
                    username: string | null
                    full_name: string | null
                    avatar_url: string | null
                    website: string | null
                    is_admin: boolean | null
                }
                Insert: {
                    id: string
                    updated_at?: string | null
                    username?: string | null
                    full_name?: string | null
                    avatar_url?: string | null
                    website?: string | null
                    is_admin?: boolean | null
                }
                Update: {
                    id?: string
                    updated_at?: string | null
                    username?: string | null
                    full_name?: string | null
                    avatar_url?: string | null
                    website?: string | null
                    is_admin?: boolean | null
                }
            }
            profile_claims: {
                Row: {
                    id: string
                    user_id: string
                    profile_id: string
                    profile_type: 'teacher' | 'organiser' | 'dj'
                    status: 'pending' | 'approved' | 'rejected'
                    claim_name: string
                    claim_email: string
                    claim_phone: string
                    admin_notes: string | null
                    created_at: string
                    updated_at: string
                }
                Insert: {
                    id?: string
                    user_id: string
                    profile_id: string
                    profile_type: 'teacher' | 'organiser' | 'dj'
                    status?: 'pending' | 'approved' | 'rejected'
                    claim_name: string
                    claim_email: string
                    claim_phone: string
                    admin_notes?: string | null
                    created_at?: string
                    updated_at?: string
                }
                Update: {
                    id?: string
                    user_id?: string
                    profile_id?: string
                    profile_type?: 'teacher' | 'organiser' | 'dj'
                    status?: 'pending' | 'approved' | 'rejected'
                    claim_name?: string
                    claim_email?: string
                    claim_phone?: string
                    admin_notes?: string | null
                    created_at?: string
                    updated_at?: string
                }
            }
        }
    }
}

// Type alias for special guests
export type EventSpecialGuestRow = Database['public']['Tables']['event_special_guests']['Row'];
