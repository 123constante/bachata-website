import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

// These should be environment variables in a real app
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

console.log('Supabase Config:', {
  url: supabaseUrl ? 'Set' : 'Missing',
  keyLength: supabaseKey ? supabaseKey.length : 0
});

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase Environment Variables!');
}

export const supabase = createClient<Database>(supabaseUrl || '', supabaseKey || '');
