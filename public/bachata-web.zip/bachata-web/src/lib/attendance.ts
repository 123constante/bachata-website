import { supabase } from './supabase';

/**
 * 1) saveAttendanceStatus(eventId: string, status: "going" | "interested")
 * 
 * Behaviour:
 * - If no user logged in → return { error: "not_logged_in" }
 * - Check if an attendance row already exists for (eventId, userId)
 * - If none → INSERT new row with that status
 * - If exists → UPDATE the row with the new status
 * - Return { success: true }
 */
export const saveAttendanceStatus = async (eventId: string, status: 'going' | 'interested') => {
    // Check if user logged in
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
        return { error: 'not_logged_in' };
    }

    try {
        // Get dancer ID for current user
        const { data: dancer } = await supabase
            .from('dancers')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

        if (!dancer) {
            return { error: 'no_dancer_profile' };
        }

        // Upsert attendance
        // Since (event_id, dancer_id) is likely unique, upsert works for both insert and update
        const { error } = await supabase
            .from('event_attendees')
            .upsert({
                event_id: eventId,
                dancer_id: dancer.id,
                status: status
            });

        if (error) throw error;
        return { success: true };

    } catch (err: any) {
        console.error('saveAttendanceStatus error:', err);
        return { error: err.message };
    }
};

/**
 * 2) removeAttendanceStatus(eventId: string)
 * 
 * Behaviour:
 * - If user not logged in → return error
 * - Find row for (eventId, userId)
 * - If exists → DELETE it
 * - Return { success: true }
 */
export const removeAttendanceStatus = async (eventId: string) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
        return { error: 'not_logged_in' };
    }

    try {
        // Get dancer ID for current user
        const { data: dancer } = await supabase
            .from('dancers')
            .select('id')
            .eq('user_id', session.user.id)
            .single();

        if (!dancer) {
            return { error: 'no_dancer_profile' };
        }

        const { error } = await supabase
            .from('event_attendees')
            .delete()
            .eq('event_id', eventId)
            .eq('dancer_id', dancer.id);

        if (error) throw error;
        return { success: true };

    } catch (err: any) {
        console.error('removeAttendanceStatus error:', err);
        return { error: err.message };
    }
};

/**
 * 3) getAttendanceForUser(userId: string)
 * 
 * Behaviour:
 * - Fetch ALL events where this user clicked going or interested
 * - Sort by event.start_date ASC
 * - Return array in specific format
 */
export const getAttendanceForUser = async (userId: string) => {
    try {
        // First get dancer_id from userId
        const { data: dancer } = await supabase
            .from('dancers')
            .select('id')
            .eq('user_id', userId)
            .single();

        if (!dancer) return [];

        // Fetch attendees + events
        const { data } = await supabase
            .from('event_attendees')
            .select(`
                status,
                events:events!inner (
                    id,
                    name,
                    date
                )
            `)
            .eq('dancer_id', dancer.id)
            .order('date', { foreignTable: 'events', ascending: true }); // Supabase supports foreign ordering

        if (!data) return [];

        // Map to required format
        return data.map((item: any) => ({
            event_id: item.events.id,
            status: item.status,
            event: {
                name: item.events.name,
                slug: item.events.name.toLowerCase().replace(/ /g, '-'),
                start_date: item.events.date
            }
        }));

    } catch (err) {
        console.error('getAttendanceForUser error:', err);
        return [];
    }
};

/**
 * 4) getUpcomingEventsForUser(userId: string, limit = 2)
 * 
 * Behaviour:
 * - Use getAttendanceForUser internally
 * - Filter for events with start_date >= today
 * - Sort by start_date
 * - Return ONLY next {limit} events
 * - If none → return empty array
 */
export const getUpcomingEventsForUser = async (userId: string, limit = 2) => {
    const allEvents = await getAttendanceForUser(userId);
    const now = new Date();
    // Reset time part to ensure we include events happening today
    now.setHours(0, 0, 0, 0);

    const upcoming = allEvents
        .filter(item => new Date(item.event.start_date) >= now)
        .sort((a, b) => new Date(a.event.start_date).getTime() - new Date(b.event.start_date).getTime())
        .slice(0, limit);

    return upcoming;
};

/**
 * 5) getRelativeEventDate(dateString: string)
 * 
 * Returns human-friendly text:
 * - “this Friday”
 * - “next Sunday”
 * - “in 5 days”
 * - “in 2 weeks”
 * - “in 3 months”
 */
export const getRelativeEventDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();

    // Normalize times for date diff calculation
    const dTime = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const nTime = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const diffTime = dTime.getTime() - nTime.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return 'recently';
    if (diffDays === 0) return 'today';
    if (diffDays === 1) return 'tomorrow';

    if (diffDays < 7) {
        return `this ${date.toLocaleDateString('en-US', { weekday: 'long' })}`;
    }

    if (diffDays < 30) {
        return `in ${diffDays} days`;
    }

    if (diffDays < 60) { // ~2 months
        const weeks = Math.round(diffDays / 7);
        return `in ${weeks} weeks`;
    }

    const months = Math.round(diffDays / 30);
    return `in ${months} months`;
};

// HELPER: Save Pending Attendance (for non-logged-in users)
export const savePendingAttendance = (eventId: string, status: 'going' | 'interested') => {
    localStorage.setItem('pending_attendance', JSON.stringify({ eventId, status }));
};

// HELPER: Execute Pending Attendance (after login)
export const executePendingAttendance = async () => {
    const pending = localStorage.getItem('pending_attendance');
    if (!pending) return;

    try {
        const { eventId, status } = JSON.parse(pending);
        if (eventId && status) {
            // Attempt to save (upsert)
            await saveAttendanceStatus(eventId, status as 'going' | 'interested');

            // Clear pending after success
            localStorage.removeItem('pending_attendance');

            // Optional: You could reload the page or trigger a state update here if needed
            // But usually the component will fetch fresh data on mount.
            window.location.reload(); // Force reload to reflect changes in UI
        }
    } catch (error) {
        console.error("Error executing pending attendance:", error);
        // Determine if we should clear it or retry? 
        // Safe to clear to avoid infinite loops
        localStorage.removeItem('pending_attendance');
    }
};
