import { supabase } from './supabase';

export type ProfileType = 'teacher' | 'dj' | 'organiser';

export async function submitProfileClaim(
  profileType: ProfileType,
  profileId: string,
  name: string,
  email: string,
  phone: string,
  targetName: string // Added for email context
) {
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    throw new Error('You must be logged in to claim a profile.');
  }

  const { error } = await supabase.from('profile_claims').insert({
    profile_type: profileType,
    profile_id: profileId,
    user_id: user.id,
    claim_name: name,
    claim_email: email,
    claim_phone: phone,
    status: 'pending',
  });

  if (error) {
    console.error('Error submitting claim:', error);
    throw error;
  }
}
