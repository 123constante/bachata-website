import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { EventList } from './pages/EventList';
// import { Auth } from './pages/Auth'; // Removed usage
import { EventDetail } from './pages/EventDetail';
import { Profile } from './pages/Profile';
import { DancerDirectory } from './pages/DancerDirectory';
import { OrganiserDirectory } from './pages/OrganiserDirectory';
import { TeacherDirectory } from './pages/TeacherDirectory';
import { TeacherProfile } from './pages/TeacherProfile';
import { DJDirectory } from './pages/DJDirectory';
import { DJProfile } from './pages/DJProfile';

import { OrganiserProfile } from './pages/OrganiserProfile';
import { DancerPublicProfile } from './pages/DancerPublicProfile';
import { ClaimPage } from './pages/ClaimPage';
import { AdminClaimsDashboard } from './pages/AdminClaimsDashboard';

import AdminDashboard from './admin/AdminDashboard';

import { AuthProvider } from './context/AuthContext';
import { LoginPage } from './admin/LoginPage';
import { Logout } from './admin/Logout';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<EventList />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/event/:slug" element={<EventDetail />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/dancers" element={<DancerDirectory />} />
          <Route path="/organisers" element={<OrganiserDirectory />} />
          <Route path="/organisers/:id" element={<OrganiserProfile />} />
          <Route path="/teachers" element={<TeacherDirectory />} />
          <Route path="/teachers/:id" element={<TeacherProfile />} />
          <Route path="/djs" element={<DJDirectory />} />
          <Route path="/djs/:id" element={<DJProfile />} />
          <Route path="/dancers/:id" element={<DancerPublicProfile />} />
          <Route path="/claim/:type/:id" element={<ClaimPage />} />
          <Route path="/admin/pending-claims" element={<AdminClaimsDashboard />} />
          {/* New Admin System */}
          <Route path="/admin/*" element={<AdminDashboard />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

export default App
