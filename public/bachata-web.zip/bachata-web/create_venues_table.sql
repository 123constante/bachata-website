-- Create Venues Table (V3)
create table if not exists venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  photo_url text,
  address text not null,
  google_maps_url text,
  capacity int,
  city text,
  contact text,
  rules text,
  parking text,
  closest_transport text,
  gallery_urls text[], -- Array of image URLs
  opening_hours text,
  created_at timestamp default now()
);

-- Enable Row Level Security
alter table venues enable row level security;

-- Policy: Everyone can view venues
create policy "Venues are viewable by everyone"
on venues for select
using ( true );

-- Policy: Only authenticated users can insert (or restrict to admins later)
create policy "Authenticated users can create venues"
on venues for insert
to authenticated
with check ( true );

-- Policy: Only authenticated users can update (or restrict to creators/admins)
create policy "Authenticated users can update venues"
on venues for update
to authenticated
using ( true );
