-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILES (Public data linked to auth.users)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  username text unique,
  full_name text,
  avatar_url text,
  country_code text,
  is_admin boolean default false, -- Added for admin role
  created_at timestamptz default now()
);

-- Enable RLS
alter table public.profiles enable row level security;

-- Policies for Profiles
create policy "Public profiles are viewable by everyone" 
  on profiles for select using (true);

create policy "Users can insert their own profile" 
  on profiles for insert with check (auth.uid() = id);

create policy "Users can update their own profile" 
  on profiles for update using (auth.uid() = id);

-- 2. ROLE: DANCERS
create table if not exists public.dancers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  full_name text not null,
  photo_url text,
  bio text,
  city text,
  nationality text,
  years_dancing int,
  favorite_styles text[],
  favorite_songs text[],
  achievements text[],
  partner_role text,
  partner_details jsonb,
  instagram text,
  phone text,
  looking_for_partner boolean default false,
  created_at timestamp default now()
);

-- Dancers RLS
alter table public.dancers enable row level security;
create policy "Dancers viewable by everyone" on dancers for select using (true);
create policy "Users manage their own dancer profile" on dancers for all using (auth.uid() = user_id);

-- 3. ROLE: TEACHERS
-- Changed: user_id is now nullable and not PK. Added uuid PK.
create table public.teachers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id), -- Nullable initially
  full_name text not null, -- Added for consistency
  stage_name text,
  bio text,
  city text, -- Added for consistency
  certifications text,
  teaching_styles text[], -- Added for consistency
  level text, -- Added for consistency
  is_verified boolean default false,
  
  -- Socials
  instagram text,
  website text,
  email text,
  phone text,
  facebook text,

  -- Services
  years_teaching int,
  offers_private boolean default false,
  offers_group boolean default false,
  available_for_workshops boolean default false,
  travel_willingness text,
  availability text,
  
  -- Media
  photo_url text,
  gallery_urls text[],
  promo_video_urls text[],
  faq jsonb,
  journey text,

  created_at timestamptz default now()
);
alter table public.teachers enable row level security;
create policy "Teachers viewable by everyone" on teachers for select using (true);
create policy "Admins can manage all teachers" on teachers for all using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);
create policy "Users manage their own teacher profile" on teachers for update using (auth.uid() = user_id);


-- 4. ROLE: ORGANISERS
create table if not exists public.organisers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id), -- Nullable initially
  name text not null,
  photo_url text,
  bio text,
  category text, -- teacher/promoter/studio
  email text,
  phone text,
  city text,
  instagram text,
  website text,
  teaching_styles text[],
  verified boolean default false,
  gallery_urls text[],
  promo_video_urls text[],
  created_at timestamp default now()
);
alter table public.organisers enable row level security;
create policy "Organisers viewable by everyone" on organisers for select using (true);
create policy "Admins can manage all organisers" on organisers for all using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);
-- IMPORTANT: Organisers CANNOT edit their own profile after claiming (per requirements), only Admin.
-- So no general update policy for user_id = auth.uid(). 


-- 5. ROLE: DJS (New)
create table public.djs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id), -- Nullable initially
  name text not null,
  photo_url text,
  bio text,
  city text,
  genres text[],
  instagram text,
  soundcloud text,
  mixcloud text,
  website text,
  is_verified boolean default false,
  created_at timestamptz default now()
);
alter table public.djs enable row level security;
create policy "DJs viewable by everyone" on djs for select using (true);
create policy "Admins can manage all djs" on djs for all using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);
create policy "Users manage their own dj profile" on djs for update using (auth.uid() = user_id);


-- 6. PROFILE CLAIMS (New)
create table public.profile_claims (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null, -- The claimer
  profile_id uuid not null, -- ID of the teacher/organiser/dj
  profile_type text not null check (profile_type in ('teacher', 'organiser', 'dj')),
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  
  -- Contact info provided during claim
  claim_name text not null,
  claim_email text not null,
  claim_phone text not null,
  
  admin_notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.profile_claims enable row level security;

-- Policies
create policy "Users can insert claims" on profile_claims for insert with check (auth.uid() = user_id);
create policy "Users can view their own claims" on profile_claims for select using (auth.uid() = user_id);
create policy "Admins can view all claims" on profile_claims for select using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);
create policy "Admins can update claims" on profile_claims for update using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);


-- 7. EVENTS
create table public.events (
  id uuid default uuid_generate_v4() primary key,
  organiser_id uuid references public.organisers(user_id), -- Keeps refererence to user_id for now, or should reference table id? 
  -- Ideally events reference the organiser TABLE id, not user_id, if organisers can exist without user_id.
  -- But existing schema referenced user_id. Let's start with referencing user_id but we might need to change this if events are created by admin for unclaimed organisers.
  -- For now, let's keep it but be aware that if organiser_id is NULL (unclaimed), event creation might be tricky if it relies on auth.uid.
  -- Actually, if we want admin to create events for unclaimed organisers, we need a better link.
  -- Let's stick to existing for now to avoid breaking too much, but noted.
  
  name text not null,
  description text,
  slug text unique,
  cover_image_url text,
  
  -- Timing
  start_time timestamptz not null,
  end_time timestamptz not null,
  
  -- Specifics
  has_class boolean default false,
  class_start timestamptz,
  class_end timestamptz,
  
  has_social boolean default false,
  social_start timestamptz,
  social_end timestamptz,
  
  -- Location
  address_full text,
  location_lat float,
  location_lng float,
  
  ticket_url text,
  is_published boolean default true,
  created_at timestamptz default now()
);
alter table public.events enable row level security;
create policy "Events viewable by everyone" on events for select using (true);
create policy "Organisers can insert events" on events for insert with check (
   -- Allow if user is an organiser
   exists (select 1 from organisers where user_id = auth.uid())
);
create policy "Organisers can update own events" on events for update using (
    exists (select 1 from organisers where user_id = auth.uid()) -- Simply check if they are an organiser? 
    -- Or check if they own THIS event? 
    -- The schema has organiser_id column. 
    -- If organiser_id references organisers.user_id:
    auth.uid() = organiser_id
);

-- 8. ATTENDEES (The "Recall" / "Going" feature)
create table public.attendees (
  event_id uuid references public.events(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  status text check (status in ('going', 'interested')),
  hide_identity boolean default false,
  created_at timestamptz default now(),
  primary key (event_id, user_id)
);
alter table public.attendees enable row level security;
create policy "Public attendees viewable" on attendees for select using (true); -- Logic in API to hide fields based on hide_identity
create policy "Users view their own attendance" on attendees for select using (auth.uid() = user_id);
create policy "Users can attend" on attendees for insert with check (auth.uid() = user_id);
create policy "Users can change attendance" on attendees for update using (auth.uid() = user_id);
create policy "Users can leave" on attendees for delete using (auth.uid() = user_id);
