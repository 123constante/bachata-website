-- Create Events Table (V3)
-- Relies on 'venues' table being created first

DROP TABLE IF EXISTS events CASCADE;

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  date date not null,
  class_start time,
  class_end time,
  social_start time,
  social_end time,
  venue_id uuid references venues(id) on delete set null,
  
  -- Additional useful fields
  cover_image_url text,
  is_published boolean default true,
  
  created_at timestamp default now()
);

-- Enable Row Level Security
alter table events enable row level security;

-- Policy: Everyone can view events
create policy "Events are viewable by everyone"
on events for select
using ( true );

-- Policy: Authenticated users can create events (Refine later for Organisers)
create policy "Authenticated users can create events"
on events for insert
to authenticated
with check ( true );

-- Policy: Authenticated users can update events
create policy "Authenticated users can update events"
on events for update
to authenticated
using ( true );
