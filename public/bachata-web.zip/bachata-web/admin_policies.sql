CREATE POLICY "Admin can read teacher_profiles" 
ON public.teacher_profiles 
FOR SELECT 
TO authenticated 
USING (
  exists (
    select 1
    from profiles
    where profiles.id = auth.uid()
    and profiles.is_admin = true
  )
);

CREATE POLICY "Admin can read dj_profiles" 
ON public.dj_profiles 
FOR SELECT 
TO authenticated 
USING (
  exists (
    select 1
    from profiles
    where profiles.id = auth.uid()
    and profiles.is_admin = true
  )
);

CREATE POLICY "Admin can read organisers" 
ON public.organisers 
FOR SELECT 
TO authenticated 
USING (
  exists (
    select 1
    from profiles
    where profiles.id = auth.uid()
    and profiles.is_admin = true
  )
);

CREATE POLICY "Admin can read dancers" 
ON public.dancers 
FOR SELECT 
TO authenticated 
USING (
  exists (
    select 1
    from profiles
    where profiles.id = auth.uid()
    and profiles.is_admin = true
  )
);

CREATE POLICY "Admin can read profile_claims" 
ON public.profile_claims 
FOR SELECT 
TO authenticated 
USING (
  exists (
    select 1
    from profiles
    where profiles.id = auth.uid()
    and profiles.is_admin = true
  )
);
