-- Add facebook column to dancers table
ALTER TABLE public.dancers 
ADD COLUMN IF NOT EXISTS facebook text;

-- Add nationality column to teacher_profiles table
ALTER TABLE public.teacher_profiles 
ADD COLUMN IF NOT EXISTS nationality text;

-- Add nationality column to dj_profiles table
ALTER TABLE public.dj_profiles 
ADD COLUMN IF NOT EXISTS nationality text;
