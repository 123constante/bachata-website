-- Migration V2: Update Dancers and Organisers Schema
-- RUN THIS SCRIPT IN THE SUPABASE SQL EDITOR

-- 1. Reset Dancers Table
DROP TABLE IF EXISTS public.dancers CASCADE;

create table public.dancers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  full_name text not null,
  photo_url text,
  bio text,
  city text,
  nationality text, -- Added
  years_dancing int,
  favorite_styles text[],
  favorite_songs text[], -- Array of URLs (Spotify/YouTube)
  achievements text[], -- Array of achievement strings
  partner_role text,
  partner_details jsonb, -- { goals: "...", availability: "..." }
  instagram text,
  phone text,
  looking_for_partner boolean default false,
  created_at timestamp default now()
);

-- Enable RLS for Dancers
alter table public.dancers enable row level security;
create policy "Dancers viewable by everyone" on dancers for select using (true);
create policy "Users manage their own dancer profile" on dancers for all using (auth.uid() = user_id);


-- 2. Reset Organisers Table
DROP TABLE IF EXISTS public.organisers CASCADE;

create table public.organisers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  name text not null,
  photo_url text,
  bio text,
  category text, -- teacher/promoter/studio
  email text,
  phone text,
  city text,
  instagram text,
  website text,
  teaching_styles text[],
  verified boolean default false,
  gallery_urls text[],
  promo_video_urls text[],
  created_at timestamp default now()
);

-- Enable RLS for Organisers
alter table public.organisers enable row level security;
create policy "Organisers viewable by everyone" on organisers for select using (true);
create policy "Users manage their own organiser profile" on organisers for all using (auth.uid() = user_id);

-- 3. Storage Setup (Avatars)
-- Attempt to create bucket (this might require Dashboard usage if SQL privileges are restricted)
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Storage Policies
create policy "Avatar images are publicly accessible"
  on storage.objects for select
  using ( bucket_id = 'avatars' );

create policy "Authenticated users can upload avatars"
  on storage.objects for insert
  with check ( bucket_id = 'avatars' and auth.role() = 'authenticated' );

create policy "Users can update their own avatars"
  on storage.objects for update
  using ( bucket_id = 'avatars' and auth.uid() = owner );