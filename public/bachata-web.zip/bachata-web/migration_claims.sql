-- 1. Add is_admin column to profiles (MUST BE FIRST)
do $$
begin
  if not exists (select 1 from information_schema.columns where table_name = 'profiles' and column_name = 'is_admin') then
    alter table public.profiles add column is_admin boolean default false;
  end if;
end $$;


-- 2. Create table DJS
create table if not exists public.djs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id), 
  name text not null,
  photo_url text,
  bio text,
  city text,
  genres text[],
  instagram text,
  soundcloud text,
  mixcloud text,
  website text,
  is_verified boolean default false,
  created_at timestamptz default now()
);

-- Enable RLS for DJs
alter table public.djs enable row level security;
create policy "DJs viewable by everyone" on djs for select using (true);

-- Drop existing policies if they exist to avoid errors on re-run
drop policy if exists "Admins can manage all djs" on djs;
create policy "Admins can manage all djs" on djs for all using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);

drop policy if exists "Users manage their own dj profile" on djs;
create policy "Users manage their own dj profile" on djs for update using (auth.uid() = user_id);


-- 3. Create table PROFILE_CLAIMS
create table if not exists public.profile_claims (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null,
  profile_id uuid not null,
  profile_type text not null check (profile_type in ('teacher', 'organiser', 'dj')),
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  claim_name text not null,
  claim_email text not null,
  claim_phone text not null,
  admin_notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Enable RLS for Profile Claims
alter table public.profile_claims enable row level security;

-- Drop existing policies to avoid errors on re-run
drop policy if exists "Users can insert claims" on profile_claims;
create policy "Users can insert claims" on profile_claims for insert with check (auth.uid() = user_id);

drop policy if exists "Users can view their own claims" on profile_claims;
create policy "Users can view their own claims" on profile_claims for select using (auth.uid() = user_id);

drop policy if exists "Admins can view all claims" on profile_claims;
create policy "Admins can view all claims" on profile_claims for select using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);

drop policy if exists "Admins can update claims" on profile_claims;
create policy "Admins can update claims" on profile_claims for update using (
  exists (select 1 from public.profiles where id = auth.uid() and is_admin = true)
);
