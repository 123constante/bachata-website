-- Seed Data for Testing

-- 1. Create a dummy organiser (we need a user first, but for simplicity we might have to skip FK enforcement or use the user's ID)
-- IMPORTANT: This script assumes you have at least one user in auth.users OR it inserts without checking FK if you disable triggers (not recommended).
-- BETTER STRATEGY: Insert events with NULL organiser_id for now if schema allows, or user must insert their own ID.

-- Our schema defined organiser_id as UUID REFERENCES organisers(user_id).
-- This is hard to seed via SQL without knowing a real User ID.

-- ALTERNATIVE: We will create a Public Function to seed events that uses the executing user's ID.

create or replace function public.seed_dummy_events()
returns void
language plpgsql
as $$
declare
  curr_user_id uuid;
begin
  -- Get current user
  curr_user_id := auth.uid();
  
  if curr_user_id is null then
    raise exception 'You must be logged in to run this seed function via API, or use SQL Editor with a hardcoded ID';
  end if;

  -- Ensure user is an expert/organiser? For now just insert.
  
  -- 1. Insert Organiser Profile if not exists
  insert into public.organisers (user_id, brand_name, bio)
  values (curr_user_id, 'Bachata Global', 'We organise the best parties!')
  on conflict (user_id) do nothing;

  -- 2. Insert Events
  insert into public.events (
    organiser_id, name, description, slug, 
    start_time, end_time, 
    has_class, class_start, class_end,
    has_social, social_start, social_end,
    address_full, location_lat, location_lng
  ) values 
  (
    curr_user_id,
    'Bachata Exchange Social',
    'The best Friday night social in London.',
    'bachata-exchange-social-' || floor(random() * 1000)::text,
    now() + interval '1 day' + interval '19 hours', -- Tomorrow 7pm
    now() + interval '1 day' + interval '27 hours', -- Tomorrow 3am
    true, 
    now() + interval '1 day' + interval '19 hours', -- Class 7pm
    now() + interval '1 day' + interval '22 hours', -- Class 10pm
    true,
    now() + interval '1 day' + interval '22 hours', -- Social 10pm
    now() + interval '1 day' + interval '27 hours', -- Social 3am
    'Corbet Place, Shoreditch, London',
    51.52, -0.07
  ),
  (
    curr_user_id,
    'Sensual Wednesday',
    'Mid-week madness.',
    'sensual-wednesday-' || floor(random() * 1000)::text,
    now() + interval '3 days' + interval '19 hours', 
    now() + interval '3 days' + interval '24 hours', 
    true, 
    now() + interval '3 days' + interval '19 hours',
    now() + interval '3 days' + interval '21 hours', 
    true,
    now() + interval '3 days' + interval '21 hours', 
    now() + interval '3 days' + interval '24 hours', 
    'Bar Salsa Temple, London',
    51.51, -0.11
  );

end;
$$;
