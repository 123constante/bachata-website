import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
const ADMIN_EMAIL = 'admin@bachatacommunity.com' // Replace with actual admin email if known, or env var

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
    // Handle CORS preflight requests
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders })
    }

    try {
        const { claimId, claimName, claimEmail, profileName, profileType } = await req.json()

        if (!RESEND_API_KEY) {
            console.error('RESEND_API_KEY is not set')
            // We return success to the client to not break the UX, but log the error
            return new Response(
                JSON.stringify({ message: 'Configuration error: Email service not set up.' }),
                {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                    status: 500,
                }
            )
        }

        const res = await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${RESEND_API_KEY}`,
            },
            body: JSON.stringify({
                from: 'Bachata App <onboarding@resend.dev>', // Default Resend testing domain
                to: ADMIN_EMAIL, // For testing, this must be YOUR verification email if using Resend free tier
                subject: `New ${profileType} Profile Claim: ${profileName}`,
                html: `
          <h1>New Profile Claim Request</h1>
          <p><strong>${claimName}</strong> (${claimEmail}) has requested to claim the profile:</p>
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin: 0;">${profileName}</h2>
            <p style="margin: 5px 0 0; color: #666;">${profileType}</p>
          </div>
          <p>Request ID: ${claimId}</p>
          <a href="https://your-app-url.com/admin/pending-claims" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Review in Dashboard</a>
        `,
            }),
        })

        const data = await res.json()

        return new Response(
            JSON.stringify(data),
            {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                status: 200,
            }
        )
    } catch (error) {
        return new Response(
            JSON.stringify({ error: error.message }),
            {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                status: 400,
            }
        )
    }
})
