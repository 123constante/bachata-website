-- Add festival_plans column to dancers table
ALTER TABLE public.dancers 
ADD COLUMN IF NOT EXISTS festival_plans jsonb DEFAULT '[]'::jsonb;
